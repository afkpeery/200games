import { dealTerms, money, openInvestment, pitchFor } from './economy.js'
import { adjustMeters, bankAccess, privateAccess } from './meters.js'
import { FINAL_DAY } from './rules.js'

const CONTACTS = {
  founder: { name: 'Mara Voss', role: 'Founder' },
  banker: { name: 'Ellis Vale', role: 'Banker' },
  shark: { name: 'Ivo Rook', role: 'Private Lender' },
  courier: { name: 'Pax Mercer', role: 'Market Courier' }
}

const assetOffers = {
  office: { id: 'office', name: 'Meridian Office', price: 2600, value: 2900, channel: 'Registered' },
  lockup: { id: 'lockup', name: 'Freightway Lockup', price: 1400, value: 1900, channel: 'Off-book' }
}

function needCash(state, cost) {
  return state.cash >= cost ? '' : 'Requires ' + money(cost) + ' in cash.'
}

function gig(state, { id, label, reward, reputation, heat, kind }) {
  const earned = state.day > 1 ? reward + (state.day - 1) * 25 : reward
  return {
    id,
    label,
    detail: money(earned) + ' payout · One paid gig per day',
    kind,
    reason: state.gigDay === state.day ? 'You already completed a paid gig today.' : '',
    apply(log) {
      state.cash += earned
      state.gigDay = state.day
      adjustMeters(state, reputation, heat)
      const detail = money(earned) + ' added to your cash.'
      log(label, detail, kind, kind === 'offbook')
      return detail
    }
  }
}

function dealAction(state, pitch, id, label, terms, kind) {
  return {
    id,
    label,
    detail: money(terms.cost) + ' for ' + terms.equity + '% equity · ' + duration(state.day + pitch.model.term),
    kind,
    reason: state.fundedDay === state.day ? 'This round is already signed.' : needCash(state, terms.cost),
    apply(log) {
      openInvestment(state, pitch, terms)
      const detail = money(terms.cost) + ' committed to ' + pitch.name + ' for ' + terms.equity + '% equity.'
      log(pitch.name + ' funded', detail + ' ' + terms.route + '.', kind, kind === 'offbook')
      return detail
    }
  }
}

function duration(term) {
  return 'Resolves Day ' + term
}

function founderActions(state, pitch) {
  const fair = dealTerms(pitch, 'fair')
  const hard = dealTerms(pitch, 'hard')
  const offbook = dealTerms(pitch, 'offbook')
  const actions = [
    gig(state, { id: 'consult', label: 'Consulting gig', reward: 725, reputation: 4, heat: 0, kind: 'legal' }),
    {
      id: 'diligence',
      label: 'Review the books',
      detail: money(100) + ' · Uncover risk and accounting flags',
      kind: 'service',
      reason: state.reviewedDay === state.day ? 'Review complete.' : needCash(state, 100),
      apply(log) {
        state.cash -= 100
        state.reviewedDay = state.day
        const detail = pitchFor(state).diligence
        log(pitch.name + ' reviewed', detail, 'service')
        return detail
      }
    },
    dealAction(state, pitch, 'deal-fair', 'Sign fair terms', fair, 'legal'),
    dealAction(state, pitch, 'deal-hard', 'Demand hard terms', hard, 'gray'),
    dealAction(state, pitch, 'deal-offbook', 'Sign off-book deal', offbook, 'offbook')
  ]
  if (state.quote?.day === state.day) {
    actions.push(dealAction(state, pitch, 'sign-quote', 'Accept negotiated offer', state.quote.terms, state.quote.kind))
  }
  return actions
}

function borrow(state, offer, gate) {
  const existing = state.debts.some((debt) => debt.id === offer.id)
  return {
    id: offer.action,
    label: offer.label,
    detail: money(offer.principal) + ' today · Repay ' + money(offer.balance) + ' on Day ' + (state.day + offer.duration),
    kind: 'credit',
    reason: gate || (existing ? 'Settle the outstanding loan to borrow again.' : '') ||
      (state.day + offer.duration > FINAL_DAY ? 'This loan would fall due after the final close.' : ''),
    apply(log) {
      state.cash += offer.principal
      state.debts.push({
        id: offer.id,
        lender: offer.lender,
        balance: offer.balance,
        dueDay: state.day + offer.duration,
        lateRate: offer.lateRate
      })
      adjustMeters(state, offer.reputation, offer.heat)
      const detail = money(offer.principal) + ' received. ' + money(offer.balance) + ' due on Day ' + (state.day + offer.duration) + '.'
      log(offer.label, detail, 'credit', offer.id === 'private')
      return detail
    }
  }
}

function repay(state, id) {
  const debt = state.debts.find((entry) => entry.id === id)
  return {
    id: id === 'bank' ? 'repay-bank' : 'repay-private',
    label: 'Repay outstanding loan',
    detail: debt ? money(debt.balance) + ' balance · Due Day ' + debt.dueDay : '',
    kind: 'credit',
    reason: debt ? needCash(state, debt.balance) : 'No outstanding loan.',
    apply(log) {
      state.cash -= debt.balance
      state.debts = state.debts.filter((entry) => entry !== debt)
      adjustMeters(state, id === 'bank' ? 3 : 0, id === 'private' ? -3 : 0)
      const detail = money(debt.balance) + ' paid in full.'
      log(debt.lender + ' loan settled', detail, 'credit')
      return detail
    }
  }
}

function buyProperty(state, asset, action, gate) {
  const offbook = asset.channel === 'Off-book'
  return {
    id: action,
    label: 'Buy ' + asset.name,
    detail: money(asset.price) + ' purchase · ' + money(asset.value) + ' estimated value',
    kind: offbook ? 'offbook' : 'property',
    reason: state.assets.some((entry) => entry.id === asset.id) ? 'Already purchased this run.' : gate || needCash(state, asset.price),
    apply(log) {
      state.cash -= asset.price
      state.assets.push({ ...asset, purchasedDay: state.day, status: 'owned' })
      adjustMeters(state, offbook ? -6 : 5, offbook ? 16 : 0)
      const detail = asset.name + ' is now in your holdings.'
      log('Property acquired', detail, 'property', offbook)
      return detail
    }
  }
}

function payService(state, service) {
  return {
    id: service.id,
    label: service.label,
    detail: money(service.price) + ' · ' + service.effect,
    kind: service.kind,
    reason: state.serviceDay[service.id] === state.day ? 'Already used today.' :
      state.heat < service.minimumHeat ? 'Requires at least ' + service.minimumHeat + ' heat.' :
      needCash(state, service.price),
    apply(log) {
      state.cash -= service.price
      state.serviceDay[service.id] = state.day
      const oldHeat = state.heat
      adjustMeters(state, service.reputation, service.heat)
      const detail = 'Heat reduced by ' + (oldHeat - state.heat) + '.'
      log(service.label, detail, service.kind, service.kind === 'offbook')
      return detail
    }
  }
}

function bankerActions(state) {
  const gate = bankAccess(state)
  return [
    gig(state, { id: 'bank-gig', label: 'Review a business plan', reward: 625, reputation: 7, heat: 0, kind: 'legal' }),
    borrow(state, {
      id: 'bank', label: 'Open a bank credit line', action: 'bank-loan', lender: 'Meridian Bank',
      principal: 2300, balance: 2530, duration: 4, lateRate: 0.07, reputation: 2, heat: 0
    }, gate),
    buyProperty(state, assetOffers.office, 'buy-office', gate),
    payService(state, {
      id: 'disclosure', label: 'File a compliance disclosure', price: 425, effect: 'Lower heat by 20',
      kind: 'legal', minimumHeat: 8, reputation: 8, heat: -20
    }),
    repay(state, 'bank')
  ].filter((action) => action.id !== 'repay-bank' || action.detail)
}

function sharkActions(state) {
  const gate = privateAccess(state)
  return [
    gig(state, { id: 'dock-gig', label: 'Run an off-book delivery', reward: 1150, reputation: -7, heat: 17, kind: 'offbook' }),
    borrow(state, {
      id: 'private', label: 'Take a private advance', action: 'private-loan', lender: 'Freightway Capital',
      principal: 2450, balance: 3310, duration: 3, lateRate: 0.16, reputation: -5, heat: 11
    }, gate),
    buyProperty(state, assetOffers.lockup, 'buy-lockup', gate),
    payService(state, {
      id: 'settle-heat', label: 'Pay for a quiet day', price: 750, effect: 'Lower heat by 31',
      kind: 'offbook', minimumHeat: 15, reputation: -3, heat: -31
    }),
    repay(state, 'private')
  ].filter((action) => action.id !== 'repay-private' || action.detail)
}

function founderLine(state, pitch) {
  if (state.fundedDay === state.day) return 'The round is signed. Come back after the market closes and I’ll have another company for you.'
  if (state.quote?.day === state.day) return state.quote.line
  const introduction = pitch.name + ' is raising ' + money(pitch.ask) + ' for a ' + pitch.industry + ' venture.'
  const reaction = state.reputation >= 72 ? 'Your name opened the door. ' :
    state.heat >= 45 ? 'Your name is getting around. Keep this conversation here. ' : ''
  return reaction + introduction + ' ' + pitch.founder.line
}

function bankerLine(state) {
  if (state.heat >= 45) return 'Compliance is watching the district. File a disclosure if you want to clear some heat.'
  if (state.record.length && !bankAccess(state)) return 'Your file still carries the old entries. Today, your standing is strong enough for us to lend.'
  if (!bankAccess(state)) return 'Your accounts qualify for credit. I can also offer a registered office, if you’re ready for a fixed address.'
  return 'Take a review assignment and establish a clean track record. Then we can talk about formal financing.'
}

function sharkLine(state) {
  if (state.heat >= 65) return 'The district is talking about you. A quiet day costs, but so does staying visible.'
  if (state.reputation <= 42) return 'I heard how you made your first money. I can put more in your hands before the day is over.'
  if (!privateAccess(state)) return 'I have cash and a place to put inventory. I work exactly one day at a time.'
  return 'A bankable name is worth keeping. If you want a delivery without paperwork, come back to the Night Window.'
}

function courierLine(state) {
  if (state.ending) return 'The last envelopes are sealed. Whatever number is on yours, you were here to write it.'
  if (state.heat >= 45) return 'The Bank Annex got a thick packet this morning. If your name is in it, Ellis Vale can tell you what a disclosure would cost. Take the lobby elevator to the Credit Office.'
  if (!state.gigDay) return 'I run term sheets between the Foundry and the Bank Annex. Need paid work? Take the Foundry stairs to Mara Voss in the Pitch Lab.'
  if (!state.portfolio.length) return 'Mara will let you review a founder’s books before you commit. I’ve delivered enough bad news to know why that matters.'
  return 'The day’s numbers don’t settle until the market closes. Check your phone for maturity dates before you plan around a payout.'
}

function infoFor(state, id) {
  if (id === 'founder') {
    const pitch = pitchFor(state)
    return { ...CONTACTS[id], line: founderLine(state, pitch), pitch, actions: founderActions(state, pitch) }
  }
  if (id === 'banker') return { ...CONTACTS[id], line: bankerLine(state), actions: bankerActions(state) }
  if (id === 'shark') return { ...CONTACTS[id], line: sharkLine(state), actions: sharkActions(state) }
  if (id === 'courier') return { ...CONTACTS[id], line: courierLine(state), actions: [] }
  return null
}

export function getNPC(state, id) {
  const contact = infoFor(state, id)
  if (!contact) return null
  const pitch = contact.pitch
  return {
    name: contact.name,
    role: contact.role,
    line: contact.line,
    pitch: pitch && {
      name: pitch.name,
      industry: pitch.industry,
      stage: pitch.stage,
      dealType: pitch.dealType,
      ask: pitch.ask,
      equity: pitch.equity,
      risk: pitch.risk,
      diligence: pitch.diligence,
      personality: pitch.founder.personality
    },
    actions: contact.actions.map(({ apply, ...action }) => ({
      ...action,
      disabled: Boolean(action.reason) || Boolean(state.ending)
    }))
  }
}

function negotiate(state, text, log) {
  if (state.fundedDay === state.day) return { ok: false, message: 'This round is already signed.' }
  if (typeof text !== 'string' || !text.trim()) {
    return { ok: false, message: 'Enter terms, such as “$650 for 20%” or “Can you match my budget?”' }
  }
  // Recognize currency, equity and deal language without a remote dialogue service.
  const phrase = text.slice(0, 180).trim().toLowerCase()
  const requestedCost = phrase.match(/\$\s*([\d,]+)|(?:offer|for|invest|cash)\s+(\d{3,5})\b/)
  const requestedEquity = phrase.match(/(\d{1,3})\s*(?:%|percent)/)
  const fairTone = /\b(fair|trust|clean|friendly|standard|transparent)\b/.test(phrase)
  const hardTone = /\b(hard|aggressive|squeeze|discount|lower|less|more equity)\b/.test(phrase)
  const offbookTone = /off[ -]?(?:the[ -]?)?books?|unregistered|without paperwork/.test(phrase)
  const budget = /\b(budget|afford|cash on hand)\b/.test(phrase)
  const diligence = /\b(risk|fraud|accounts|diligence|books)\b/.test(phrase) && !offbookTone
  if (diligence && !requestedCost && !requestedEquity) {
    const pitch = pitchFor(state)
    const answer = pitch.diligence || 'Review the books and I’ll make the records available. It costs ' + money(100) + '.'
    state.quote = null
    log('Asked about diligence', answer, 'service')
    return { ok: true, message: answer }
  }
  if (!requestedCost && !requestedEquity && !fairTone && !hardTone && !offbookTone && !budget) {
    return { ok: false, message: 'Mara is listening for a cash amount, an equity percentage, or a stance on the terms.' }
  }
  const pitch = pitchFor(state)
  const mode = offbookTone ? 'offbook' : hardTone || (requestedEquity && Number(requestedEquity[1]) > pitch.equity + 4) ? 'hard' : 'fair'
  const offer = dealTerms(pitch, mode)
  const proposedCost = requestedCost ? Number((requestedCost[1] || requestedCost[2]).replaceAll(',', '')) : budget ? state.cash : offer.cost
  const proposedEquity = requestedEquity ? Number(requestedEquity[1]) : offer.equity
  const minimumCost = Math.max(375, Math.floor(offer.cost * (fairTone ? 0.92 : 0.86) / 25) * 25)
  const negotiatedCost = Math.min(offer.cost, Math.max(minimumCost, proposedCost))
  const negotiatedEquity = Math.max(pitch.equity - 4, Math.min(offer.equity + 3, proposedEquity))
  const terms = { ...offer, cost: negotiatedCost, equity: negotiatedEquity }
  const counter = negotiatedCost !== proposedCost || negotiatedEquity !== proposedEquity
  const line = (counter ? 'I can meet you at ' : 'I can accept ') + money(terms.cost) + ' for ' + terms.equity +
    '% of ' + pitch.name + '. The offer is yours to sign today.'
  state.quote = { day: state.day, line, terms, kind: mode === 'fair' ? 'legal' : mode === 'hard' ? 'gray' : 'offbook' }
  log('Terms discussed with Mara', line, 'service')
  return { ok: true, message: line }
}

export function useContact(state, npc, action, log) {
  if (npc === 'founder' && action.id === 'negotiate') return negotiate(state, action.text, log)
  const offer = infoFor(state, npc)?.actions.find((entry) => entry.id === action.id)
  if (!offer) return { ok: false, message: 'That action is unavailable at this contact.' }
  if (offer.reason) return { ok: false, message: offer.reason }
  return { ok: true, message: offer.apply(log) }
}
