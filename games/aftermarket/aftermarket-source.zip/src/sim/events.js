import { money } from './economy.js'
import { adjustMeters } from './meters.js'
import { randomFor, shuffled } from './random.js'

const QUIET = { id: 'quiet', growth: 0, risk: 0, exit: 1 }

export const EVENTS = [
  { id: 'selloff', name: 'Night Selloff', description: 'Liquidity dries up across the district. Active valuations and exits take a hit.', growth: -0.27, risk: 0.12, exit: 0.75 },
  { id: 'ipo', name: 'Listing Fever', description: 'The exchange opens a fresh listing window. Active ventures gain value and exits command a premium.', growth: 0.28, risk: -0.08, exit: 1.28 },
  { id: 'audit', name: 'Regulatory Sweep', description: 'Enforcement pulls the district’s books. Heat and documented off-book activity affect the cost.', growth: -0.07, risk: 0.05, exit: 0.96 }
]

export function marketFor(state, log) {
  // Each twelve-day run sees all three events, in an order determined by its seed.
  const slot = [3, 6, 9].indexOf(state.day)
  const market = slot === -1 ? QUIET : shuffled(EVENTS, randomFor(state.seed, 'city-events'))[slot]
  state.event = market === QUIET ? null : {
    id: market.id,
    name: market.name,
    title: market.name,
    description: market.description,
    detail: market.description,
    day: state.day
  }
  if (market === QUIET) return market
  log(market.name, market.description, 'event')
  if (market.id === 'audit') audit(state, log)
  return market
}

function audit(state, log) {
  const flags = state.record.filter((entry) => entry.kind === 'offbook').length
  if (state.heat < 24 && flags < 3) {
    log('Books cleared', 'The sweep found no grounds to assess a fine.', 'event')
    return
  }
  const fine = Math.min(state.cash, 150 + 75 * flags + state.heat * 5)
  state.cash -= fine
  adjustMeters(state, -4, flags >= 3 ? 13 : 6)
  const riskyAsset = state.assets.find((asset) => asset.channel === 'Off-book' && asset.value > 0)
  if (riskyAsset && state.heat >= 55) {
    riskyAsset.value = 0
    riskyAsset.status = 'seized'
  }
  const detail = money(fine) + ' in penalties. ' +
    (riskyAsset?.status === 'seized' ? riskyAsset.name + ' was seized. ' : '') +
    'The finding was added to your permanent record.'
  state.record.unshift({ day: state.day, title: 'Audit finding', detail, kind: 'enforcement' })
  log('Audit finding', detail, 'loss')
}
