import * as THREE from 'three';
import { reflectionTexture, signTexture, surfaceBumpTexture, surfaceTexture } from './world-textures.js';

const bounds = { minX: -5.85, maxX: 5.85, minZ: -8.8, maxZ: 8.1 };
const landmarks = [
  { id: 'exchange-exit', label: 'Exchange Avenue', x: 0, z: 7.26, color: '#b4c7b8' },
  { id: 'exchange-wire', label: 'Market Wire', x: -3.46, z: -1.12, color: '#a5d6bd' },
  { id: 'exchange-lift', label: 'Private Lift', x: 0, z: -7.55, color: '#e4bc76' },
];

export function createExchange(scene, { reducedMotion = false } = {}) {
  scene.background = new THREE.Color(0x17221e);
  scene.fog = new THREE.Fog(0x17221e, 13, 30);
  scene.add(new THREE.HemisphereLight(0xd8e7d5, 0x67513b, 1.76));
  const mapFeatures = { blocks: [], roads: [[-1.54, -8.64, 1.54, 8.06]] };
  const cube = new THREE.BoxGeometry(1, 1, 1);
  const flat = (color, roughness = .68, metalness = .06) => new THREE.MeshStandardMaterial({ color, roughness, metalness });
  const surface = (name, x, y, color, roughness) => new THREE.MeshStandardMaterial({
    color, roughness, map: surfaceTexture(name, x, y), bumpMap: surfaceBumpTexture(name, x, y), bumpScale: .036,
  });
  const stone = surface('concrete', 1, 1, 0xcbd4c8, .74);
  const floor = surface('tile', 1.8, 2.1, 0xd3dfcf, .4);
  const dark = flat(0x273b35, .38, .35);
  const wood = flat(0x584335);
  const brass = flat(0x987651, .32, .68);
  const cloth = flat(0x323c33, .92);
  const lightPanel = new THREE.MeshBasicMaterial({ color: 0xffdf96, toneMapped: false });

  function box(x, y, z, width, height, depth, material) {
    const mesh = new THREE.Mesh(cube, material);
    mesh.position.set(x, y, z);
    mesh.scale.set(width, height, depth);
    scene.add(mesh);
    return mesh;
  }

  function solid(x, y, z, width, height, depth, material) {
    box(x, y, z, width, height, depth, material);
    mapFeatures.blocks.push([x - width / 2, z - depth / 2, x + width / 2, z + depth / 2]);
  }

  function plaque(text, detail, x, y, z, width, height, heading = 0) {
    const map = signTexture(text, detail, { panel: '#283631', trim: '#8d805b', text: '#e9debd', aux: '#aac4ad' });
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height), new THREE.MeshBasicMaterial({ map, toneMapped: false }));
    mesh.position.set(x, y, z);
    mesh.rotation.y = heading;
    scene.add(mesh);
  }

  box(0, -.11, -.35, 12.1, .2, 17.3, floor);
  box(0, 4.82, -.35, 12.05, .25, 17.4, stone);
  for (const x of [-5.95, 5.95]) {
    box(x, 2.4, -.35, .22, 4.8, 17.4, stone);
    box(x * .983, .29, -.35, .16, .58, 17.3, dark);
  }
  for (const z of [-8.87, 8.22]) {
    box(0, 2.4, z, 12.1, 4.8, .25, stone);
    box(0, 3.07, z * .98, 11.8, .09, .12, brass);
  }
  for (const x of [-1.55, 1.55]) {
    box(x, .001, -.36, .047, .014, 16.76, brass);
  }
  for (const z of [-5.75, -1.76, 2.25, 6.12]) {
    box(0, 4.17, z, 11.8, .34, .38, dark);
    box(0, 4.00, z, 5.6, .04, .13, lightPanel);
    for (const x of [-5.5, 5.5]) {
      solid(x, 2.1, z, .55, 4.2, .55, stone);
      box(x, 3.82, z, .68, .08, .68, brass);
    }
  }
  for (const x of [-4.95, 4.95]) {
    solid(x, .24, 2.8, .87, .48, 3.14, wood);
    box(x, .5, 2.8, .82, .07, 2.99, cloth);
    box(x, 2.72, -5.4, .21, .22, .21, lightPanel);
  }
  box(0, 1.4, -8.64, 2.6, 2.8, .21, dark);
  box(0, 1.32, -8.48, 1.97, 2.47, .08, brass);
  box(0, 1.28, -8.43, .024, 2.31, .038, dark);
  box(1.38, 1.32, -8.58, .19, .35, .08, dark);
  box(1.38, 1.4, -8.53, .055, .07, .02, lightPanel);
  plaque('PRIVATE LIFT', 'UPPER FLOORS', 0, 3.16, -8.53, 2.38, .54);
  box(0, 1.35, 8.03, 2.48, 2.7, .2, dark);
  box(0, 1.37, 7.90, .031, 2.57, .06, brass);
  plaque('EXCHANGE AVENUE', 'STREET EXIT', 0, 3.09, 7.88, 2.58, .54, Math.PI);
  plaque('MERIDIAN EXCHANGE', 'CLEARING & SETTLEMENT', 3.72, 2.79, -8.65, 3.04, .69);

  solid(-3.46, .55, -2.02, 2.48, 1.1, .76, wood);
  box(-3.46, 1.13, -2.02, 2.58, .08, .82, brass);
  box(-3.46, 1.72, -2.30, 2.12, 1.08, .11, dark);
  plaque('MARKET WIRE', 'PORTFOLIO · EVENTS · RECORD', -3.46, 1.71, -2.234, 2.06, .64);
  const indicator = box(-2.56, 2.09, -2.23, .032, .032, .03, lightPanel.clone());
  const reflection = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 8.5), new THREE.MeshBasicMaterial({
    map: reflectionTexture(), color: 0xe4c187, transparent: true, opacity: .23, depthWrite: false, blending: THREE.AdditiveBlending,
  }));
  reflection.rotation.x = -Math.PI / 2;
  reflection.position.set(0, .015, -4.05);
  scene.add(reflection);
  const pool = new THREE.PointLight(0xffdf9c, 20, 10, 2);
  pool.position.set(0, 3.8, -6);
  scene.add(pool);

  function update(elapsed) {
    indicator.material.color.setHex(reducedMotion || Math.sin(elapsed * 2.1) > -.36 ? 0xcde7ad : 0x667a59);
  }

  return {
    bounds, landmarks, mapFeatures, spawn: new THREE.Vector3(0, 1.68, 6.25), yaw: 0,
    elevatorArrival: { x: 0, z: -5.5, yaw: Math.PI },
    collides(x, z, radius = .3) {
      return x - radius < bounds.minX || x + radius > bounds.maxX || z - radius < bounds.minZ || z + radius > bounds.maxZ ||
        mapFeatures.blocks.some(([left, far, right, near]) => x + radius > left && x - radius < right && z + radius > far && z - radius < near);
    },
    update,
    setReducedMotion(enabled) { reducedMotion = enabled; update(0); },
  };
}
