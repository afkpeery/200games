import { CITY_EXPANSION_BLOCKS, CITY_EXPANSION_STREETS } from './district.js';

export function addCityExpansion({ box, barrier, floor, floorHaze, sign, planter, bench, surface, solid, luminous }) {
  const roadEdge = solid(0x67706b, 0.72);
  const curbShadow = solid(0x171e1e, 0.54, 0.15);
  const roadPaint = solid(0x9f9271, 0.81);
  const alloy = solid(0x293536, 0.58, 0.5);
  const drainChannel = solid(0x1a2725, 0.53, 0.19);
  const warmLamp = luminous(0xf0b77e, 1.12);
  const riverLamp = luminous(0x8bd4ca, 1.04);
  const sidewalk = surface('aggregate', 2, 39, { color: 0x828985, roughness: 0.71 });
  const ground = {
    avenue: [
      surface('street', 40, 3, { roughness: 0.39, metalness: 0.23 }),
      surface('street', 3, 65, { roughness: 0.39, metalness: 0.23 })
    ],
    alley: [
      surface('alley', 18, 2, { roughness: 0.43, metalness: 0.22 }),
      surface('alley', 2, 40, { roughness: 0.43, metalness: 0.22 })
    ],
    river: [surface('aggregate', 40, 2, { color: 0x87938b, roughness: 0.76 })]
  };

  for (const [index, [x, z, width, depth, family]] of CITY_EXPANSION_STREETS.entries()) {
    const vertical = depth > width;
    const thickness = vertical ? width : depth;
    const length = vertical ? depth : width;
    const pavementY = 0.034 + index * 0.0005;
    floor(x, z, width, depth, ground[family][Number(vertical)], pavementY);
    for (const side of [-1, 1]) {
      const offset = side * (thickness / 2 + 0.58);
      const px = vertical ? x + offset : x;
      const pz = vertical ? z : z + offset;
      floor(px, pz, vertical ? 1.16 : length, vertical ? length : 1.16, sidewalk, pavementY - 0.007);
      const seam = side * thickness / 2;
      box(vertical ? x + seam : x, pavementY + 0.015, vertical ? z : z + seam,
        vertical ? 0.105 : length, 0.045, vertical ? length : 0.105, roadEdge);
    }
    if (family === 'alley') {
      for (let along = -length / 2 + 4; along < length / 2 - 2; along += 13.5) {
        const px = vertical ? x + thickness * .39 : x + along;
        const pz = vertical ? z + along : z + thickness * .39;
        box(px, pavementY + .006, pz, vertical ? .22 : .79, .016, vertical ? .79 : .22, drainChannel);
        for (let slot = -.29; slot <= .3; slot += .095) {
          box(px + (vertical ? 0 : slot), pavementY + .017, pz + (vertical ? slot : 0),
            vertical ? .17 : .028, .013, vertical ? .028 : .17, alloy);
        }
        floorHaze(px - (vertical ? .34 : 0), pz - (vertical ? 0 : .34), 1.9, 2.8, 0x6c9186, .14, .087);
      }
    }
    if (family !== 'avenue') continue;
    for (let offset = -length / 2 + 3; offset < length / 2 - 2; offset += 6.4) {
      const px = vertical ? x : x + offset;
      const pz = vertical ? z + offset : z;
      const crossing = CITY_EXPANSION_STREETS.some(([sx, sz, sw, sd], i) =>
        index !== i && Math.abs(sx - px) < sw / 2 && Math.abs(sz - pz) < sd / 2);
      if (!crossing) box(px, pavementY + 0.006, pz, vertical ? 0.07 : 2.4, 0.009, vertical ? 2.4 : 0.07, roadPaint);
    }
  }

  const brick = surface('brick', 4, 3, { color: 0xc1a294, roughness: 0.79 }, 0.035);
  const sheet = surface('metal', 3, 2, { color: 0x778782, roughness: 0.55, metalness: 0.34 }, 0.04);
  const slate = surface('tile', 4, 3, { color: 0xabb6b2, roughness: 0.62, metalness: 0.08 }, 0.029);
  const recess = solid(0x213034, 0.49, 0.27);
  const wetGlass = [solid(0x223a3e, 0.29, 0.54), solid(0x334b4b, 0.24, 0.49),
    luminous(0xa18c67, 0.23), solid(0x4b5350, 0.34, 0.29), luminous(0x758b77, 0.2)];
  const stacks = {
    brick: { wall: brick, trim: solid(0x74685e, 0.72), base: solid(0x373b32, 0.74) },
    industry: { wall: sheet, trim: alloy, base: solid(0x3d4b47, 0.62) },
    slate: { wall: slate, trim: solid(0x71827b, 0.61), base: solid(0x3c524f, 0.64) }
  };

  for (const [index, [x, z, width, depth, height, family]] of CITY_EXPANSION_BLOCKS.entries()) {
    const { wall, trim, base } = stacks[family];
    barrier(x, height / 2, z, width, height, depth, wall);
    box(x, 0.43, z, width + 0.11, 0.86, depth + 0.11, base);
    box(x, 3.18, z, width + 0.18, 0.13, depth + 0.19, trim);
    box(x, height - 0.07, z, width + 0.31, 0.29, depth + 0.31, trim);
    box(x, height + 0.48, z - depth * 0.16, width * 0.58, 0.98, depth * 0.49, base);
    box(x, height + 0.98, z - depth * 0.16, width * 0.63, 0.11, depth * 0.53, trim);
    if (index % 4 === 0) {
      box(x + width * 0.24, height + 1.36, z, 0.27, 2.72, 0.28, alloy);
      box(x + width * 0.24, height + 2.72, z, 0.4, 0.09, 0.44, trim);
    }

    for (const axis of ['x', 'z']) {
      const span = axis === 'x' ? width : depth;
      const sideDepth = axis === 'x' ? depth : width;
      const bays = Math.max(2, Math.floor(span / (family === 'industry' ? 2.75 : 2.25)));
      const pitch = span / bays;
      for (const side of [-1, 1]) {
        const face = side * sideDepth / 2;
        const facet = (offset, h, advance, w, tall, deep, mat) => {
          const distance = face + side * advance;
          if (axis === 'x') box(x + offset, h, z + distance, w, tall, deep, mat);
          else box(x + distance, h, z + offset, deep, tall, w, mat);
        };
        for (let bay = 0; bay < bays; bay++) {
          const offset = -span / 2 + (bay + 0.5) * pitch;
          for (let y = 1.96, level = 0; y < height - 0.85; y += 2.87, level++) {
            const pane = wetGlass[(index * 3 + bay * 3 + level * 2 + side + wetGlass.length) % wetGlass.length];
            const paneWidth = pitch * (family === 'industry' ? 0.77 : 0.58);
            const paneHeight = level === 0 ? 1.55 : 1.23;
            facet(offset, y, 0.022, paneWidth + 0.12, paneHeight + 0.12, 0.08, recess);
            facet(offset, y, 0.075, paneWidth, paneHeight, 0.034, pane);
            facet(offset, y - paneHeight / 2, 0.105, paneWidth + 0.2, 0.075, 0.14, trim);
            if (family !== 'industry') facet(offset, y, 0.104, 0.043, paneHeight, 0.02, trim);
          }
        }
        const service = span * 0.37 * side;
        facet(service, 1.41, 0.105, 0.76, 2.36, 0.105, base);
        facet(service - 0.19, 1.43, 0.173, 0.042, 0.22, 0.037, trim);
        facet(service, 2.76, 0.20, 1.14, 0.068, 0.36, alloy);
        facet(service, 2.71, 0.34, 0.59, 0.036, 0.043, index % 3 === 0 ? riverLamp : warmLamp);
        facet(span * -0.42, 2.10, 0.125, 0.11, 3.12, 0.12, alloy);
      }
    }
  }

  function lamp(x, z, direction = 1, cool = false) {
    const glow = cool ? riverLamp : warmLamp;
    barrier(x, 0.25, z, 0.28, 0.50, 0.29, alloy);
    box(x, 2.19, z, 0.095, 4.18, 0.10, alloy);
    box(x + direction * 0.40, 4.17, z, 0.91, 0.094, 0.12, alloy);
    box(x + direction * 0.79, 4.17, z, 0.39, 0.105, 0.39, alloy);
    box(x + direction * 0.79, 4.12, z, 0.30, 0.046, 0.29, glow);
    floorHaze(x + direction * 1.45, z, 3.8, 6.6, cool ? 0x77caba : 0xc99764, 0.33, 0.091);
  }

  for (const [x, z, direction, cool] of [
    [-36.98, -77.4, 1], [-36.98, -56.3, 1], [-30.50, -26.7, -1], [-36.98, 8.5, 1], [-36.98, 36.7, 1],
    [30.37, -76.1, 1, true], [36.09, -54.9, -1, true], [36.21, -22.65, -1], [29.72, 18.5, -1], [29.73, 39.4, -1],
    [-18.1, 50.38, 1, true], [-2.45, 49.02, 1, true], [17.6, 50.40, -1, true], [39.15, 50.4, 1, true]
  ]) lamp(x, z, direction, cool);

  const signPalette = { text: '#eef3d8', aux: '#a5b8ad', trim: '#6e8e84', panel: '#233937' };
  const rustPalette = { text: '#f1c18d', aux: '#c09775', trim: '#9a7456', panel: '#382c26' };
  for (const [x, z, label, detail, heading, warm] of [
    [-30.8, -56.8, 'NORTH SERVICE', 'NIGHT WINDOW', Math.PI / 2, true],
    [39.2, -79.85, 'NORTH TERMINAL', 'FREIGHT YARDS  •  PIER 02', 0, false],
    [35.8, -24.3, 'FREIGHT YARDS', 'DISPATCH BUILDING', Math.PI / 2, true],
    [-30.4, 35.2, 'MERCHANT MILE', 'SOUTH RIVERWALK', Math.PI / 2, true],
    [28.2, 19, 'CROWNLINE', 'MERIDIAN EAST ANNEX', -Math.PI / 2, false],
    [-6.1, 52.3, 'SOUTH RIVERWALK', 'EXCHANGE CORE', 0, false],
    [-37.2, 5.9, 'AUCTION ROW', 'EXCHANGE AUCTION HOUSE', 0, true]
  ]) {
    for (const offset of [-0.9, 0.9]) {
      const px = x + Math.cos(heading) * offset;
      const pz = z - Math.sin(heading) * offset;
      box(px, 1.28, pz, 0.07, 2.56, 0.085, alloy);
    }
    sign(x, 2.78, z, 2.84, 0.52, label, detail, warm ? rustPalette : signPalette, heading);
  }

  const promenade = solid(0x344842, 0.77);
  const track = solid(0x645d4d, 0.52, 0.36);
  floor(0, 59.65, 106.7, 9, promenade, 0.015);
  for (const x of [-39, -29, -15, -6, 7, 20, 36, 46]) {
    planter(x, 56.4, 3.35, 1.4);
    bench(x + 1.62, 60.1);
  }
  for (const x of [-42, -13, 9, 27, 48]) {
    for (const offset of [-0.66, 0.66]) box(x, 0.02, -82.5 + offset, 14, 0.065, 0.076, track);
    for (let i = -6; i <= 6; i++) box(x + i, 0.012, -82.5, 0.13, 0.036, 1.71, curbShadow);
  }
}
