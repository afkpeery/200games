import * as THREE from 'three';
import { createMissionContact } from './world-contacts.js';
import { canvasTexture, seeded, signTexture, surfaceBumpTexture, surfaceTexture } from './world-textures.js';

const exitColor = '#9ec7bb';
const front = 7.8;
const back = -9.5;
const center = (front + back) / 2;
const width = 14.6;
const missionBuildings = {
  foundry: {
    title: 'Foundry Incubator', destination: 'Pitch Lab', connector: 'foundry-stairs',
    landing: 'foundry-lab', contact: 'founder', name: 'Mara Voss', role: 'Founder & operator',
    color: '#ffc17a', colors: [0x695145, 0x292a29, 0x8d6649, 0xeeb27d, 0x9ebfc1, 0x3e5d56],
    ground: 'Prototyping floor', upper: 'Venture pitches / Diligence', steps: 1
  },
  bank: {
    title: 'Meridian Bank Annex', destination: 'Credit Office', connector: 'bank-elevator',
    landing: 'bank-credit', contact: 'banker', name: 'Ellis Vale', role: 'Client banker',
    color: '#98e9cd', colors: [0x566b64, 0x253c38, 0x6c816f, 0xd7c38c, 0x9adbbf, 0x678478],
    ground: 'Banking hall', upper: 'Private banking / Credit', steps: 0
  },
  'night-window': {
    title: 'Night Window', destination: 'Private Office', connector: 'night-window-stairs',
    landing: 'night-window-office', contact: 'shark', name: 'Ivo Rook', role: 'Private lender',
    color: '#ff8d84', colors: [0x513a46, 0x242433, 0x765044, 0xf08b7d, 0x96b9d9, 0x563f54],
    ground: 'After-hours counter', upper: 'Off-book loans / Holdings', steps: -1
  },
  dispatch: {
    title: 'Freight Dispatch', destination: 'Dispatch Mezzanine', connector: 'dispatch-stairs',
    landing: 'dispatch-mezzanine', contact: 'courier', name: 'Pax Mercer', role: 'Market courier',
    color: '#f6b279', colors: [0x495f5d, 0x283638, 0x786649, 0xe9ad6e, 0x83c5c0, 0x577b73],
    ground: 'Receiving floor', upper: 'Market routes / Manifests', steps: 1
  }
};

const landings = Object.fromEntries(Object.entries(missionBuildings).map(([id, room]) => [room.landing, id]));

function instrumentTexture(type, active) {
  const random = seeded(type === 'dispatch' ? 211 : 401);
  return canvasTexture(640, 288, (ctx, w, h) => {
    ctx.fillStyle = '#172321';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = '#637b6d';
    ctx.strokeRect(11, 11, w - 22, h - 22);
    ctx.fillStyle = active;
    ctx.font = '700 21px monospace';
    ctx.fillText({ foundry: 'VENTURE INDEX', bank: 'MERIDIAN / CREDIT', 'night-window': 'INTERNAL LEDGER', dispatch: 'EXCHANGE ROUTE BOARD' }[type], 29, 48);
    ctx.fillRect(28, 66, w - 56, 1);
    ctx.fillStyle = '#6e897b';
    for (let x = 35; x < w - 24; x += 26) ctx.fillRect(x, 84, 1, 171);
    for (let y = 99; y < h - 24; y += 22) ctx.fillRect(26, y, w - 52, 1);
    ctx.strokeStyle = active;
    ctx.lineWidth = 3;
    for (let row = 0; row < 3; row++) {
      ctx.globalAlpha = .56 + row * .15;
      ctx.beginPath();
      for (let i = 0; i <= 20; i++) {
        const x = 33 + i * 28.5;
        const y = 119 + 52 * row - 12 * Math.sin(i * .48 + row) - 29 * random();
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  });
}

export function createMissionInterior(scene, id, { reducedMotion = false } = {}) {
  const upstairs = Object.hasOwn(landings, id);
  const building = upstairs ? landings[id] : id;
  if (!Object.hasOwn(missionBuildings, building)) return null;
  const room = missionBuildings[building];
  const [wallTone, darkTone, timberTone, lightTone, coolTone, clothTone] = room.colors;
  const height = upstairs ? 3.85 : 4.6;
  const side = width / 2;
  const depth = front - back;
  const block = new THREE.BoxGeometry(1, 1, 1);
  const plane = new THREE.PlaneGeometry(1, 1);
  const transform = new THREE.Object3D();
  const batches = new Map();
  const blocks = [];
  const pedestrian = Object.assign({ x: 0, z: -5.26, heading: 0 }, { id: room.contact, label: room.name, color: room.color });
  const landmarks = upstairs ? [
    { id: id + '-return', label: room.steps ? 'Return Stairs' : 'Return Elevator', x: 0, z: 7.04, color: exitColor },
    pedestrian
  ] : [
    { id: id + '-exit', label: 'Street Exit', x: 0, z: 7.04, color: exitColor },
    { id: room.connector, label: room.destination, x: 0, z: room.steps ? -5.68 : -8.45, color: room.color }
  ];

  function matte(color, roughness = .68, metalness = .04) {
    return new THREE.MeshStandardMaterial({ color, roughness, metalness });
  }

  function glow(color) {
    return new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 1.35 });
  }

  const wallSurface = { foundry: 'brick', bank: 'plaster', 'night-window': 'brick', dispatch: 'metal' }[building];
  const plaster = new THREE.MeshStandardMaterial({
    map: surfaceTexture(wallSurface, 2.7, 1.1),
    bumpMap: surfaceBumpTexture(wallSurface, 2.7, 1.1),
    bumpScale: wallSurface === 'brick' ? .047 : .026,
    color: new THREE.Color(wallTone).lerp(new THREE.Color(0xffffff), .43),
    roughness: wallSurface === 'metal' ? .52 : .78,
    metalness: wallSurface === 'metal' ? .30 : .03
  });
  const dark = matte(darkTone, .60);
  const steel = matte(0x263036, .39, .55);
  const wood = matte(timberTone, .58);
  const trim = matte(0x988061, .46, .35);
  const light = glow(lightTone);
  const cool = glow(coolTone);
  const fabric = matte(clothTone, .91);
  const paper = matte(0xc0ae8c);
  const floorSurface = building === 'bank' ? 'tile' : building === 'dispatch' ? 'aggregate' : 'concrete';
  const floor = new THREE.MeshStandardMaterial({
    map: surfaceTexture(floorSurface, 3, 4),
    bumpMap: surfaceBumpTexture(floorSurface, 3, 4), bumpScale: .04,
    color: building === 'night-window' ? 0x928990 : 0xc3b8a3,
    roughness: building === 'bank' ? .42 : .64,
    metalness: .16
  });

  function box(x, y, z, w, h, d, material, yaw = 0, pitch = 0) {
    if (!batches.has(material)) batches.set(material, []);
    batches.get(material).push([x, y, z, w, h, d, yaw, pitch]);
  }

  function obstruction(x, z, w, d) {
    blocks.push([x - w / 2, z - d / 2, x + w / 2, z + d / 2]);
  }

  function panel(x, y, z, w, h, texture, yaw = 0) {
    const surface = new THREE.Mesh(plane, new THREE.MeshBasicMaterial({ map: texture, toneMapped: false }));
    surface.position.set(x, y, z);
    surface.scale.set(w, h, 1);
    surface.rotation.y = yaw;
    scene.add(surface);
  }

  function plaque(title, subtitle, x, y, z, w, yaw = 0) {
    const texture = signTexture(title, subtitle, {
      panel: '#323932', trim: '#8d8165', text: '#e6d0a4', aux: room.color
    });
    panel(x, y, z, w, w * .224, texture, yaw);
  }

  function point(x, y, z, color, power, distance) {
    const source = new THREE.PointLight(color, power, distance, 2);
    source.position.set(x, y, z);
    scene.add(source);
    return source;
  }

  function fixture(x, z, w, material = light) {
    box(x, height - .16, z, w + .18, .24, .33, steel);
    box(x, height - .299, z, w, .065, .19, material);
  }

  function door(z, yaw, title, subtitle, elevator = false) {
    const inside = Math.cos(yaw);
    box(0, 1.35, z, 2.54, 2.7, .19, steel);
    for (const s of [-1, 1]) {
      box(s * .57, 1.27, z + inside * .123, 1.09, 2.53, .10, elevator ? dark : wood);
      box(s * 1.18, 1.40, z + inside * .212, .11, 2.8, .24, trim);
      box(s * .15, 1.13, z + inside * .19, .045, .25, .10, trim);
      if (!elevator) {
        box(s * .56, 1.81, z + inside * .17, .69, .92, .055, steel);
        box(s * .56, 1.81, z + inside * .215, .53, .73, .048, cool);
      }
    }
    box(0, 2.8, z + inside * .211, 2.46, .11, .26, trim);
    if (elevator) box(1.49, 1.27, z + inside * .22, .105, .22, .084, light);
    plaque(title, subtitle, 0, 3.17, z + inside * .25, 2.45, yaw);
  }

  function worktable(x, z, w, d, h = .88) {
    box(x, h, z, w, .095, d, wood);
    for (const xSign of [-1, 1]) {
      for (const zSign of [-1, 1]) {
        box(x + xSign * (w / 2 - .115), h / 2, z + zSign * (d / 2 - .108), .095, h, .095, steel);
      }
    }
    box(x, h + .076, z, .48, .035, d * .47, paper, .13);
    obstruction(x, z, w, d);
  }

  function screen(x, z, w, height, y, texture, withStand = false) {
    box(x, y, z, w + .16, height + .16, .10, steel);
    panel(x, y, z + .057, w, height, texture);
    if (withStand) box(x, y - height * .59, z, .082, .13, .081, steel);
  }

  function storage(x, z, w, levels, crate = false) {
    const d = .85;
    const h = 2.63;
    for (const s of [-1, 1]) {
      box(x + s * (w / 2 - .05), h / 2, z, .10, h, d, steel);
    }
    for (let i = 0; i <= levels; i++) {
      const shelfY = .1 + i * (h - .13) / levels;
      box(x, shelfY, z, w, .095, d, i % 2 ? dark : wood);
      if (i === levels) break;
      for (let j = 0; j < 3; j++) {
        const size = w / (4.4 + .55 * j);
        const shelfX = x + (j - 1) * w * .28;
        box(shelfX, shelfY + .27, z + .04, size, .42, d * .77, crate ? wood : j % 2 ? fabric : trim);
        box(shelfX, shelfY + .32, z + .375, size * .61, .115, .019, paper);
      }
    }
    obstruction(x, z, w, d);
  }

  function bench(x, z, w, withBack = true) {
    box(x, .25, z, w - .12, .45, .69, dark);
    box(x, .51, z, w, .14, .78, fabric);
    if (withBack) box(x, .73, z + .34, w, .41, .11, fabric);
    obstruction(x, z, w, .80);
  }

  scene.background = new THREE.Color(darkTone);
  scene.add(new THREE.HemisphereLight(coolTone, 0x655046, building === 'night-window' ? 1.55 : 2.12));
  const stairwell = building === 'night-window' && !upstairs;
  if (stairwell) {
    const lip = -6.46;
    const openingWidth = 2.42;
    box(0, -.14, (front + lip) / 2, width, .28, front - lip, floor);
    for (const sign of [-1, 1]) {
      box(sign * (side / 2 + openingWidth / 4), -.14, (back + lip) / 2,
        side - openingWidth / 2, .28, lip - back, floor);
      box(sign * 1.23, -.83, (back + lip) / 2, .12, 1.67, lip - back, dark);
    }
    box(0, -1.07, back + .05, 2.55, 2.15, .21, dark);
    point(0, .45, -7.80, lightTone, 4.6, 6);
  } else {
    box(0, -.14, center, width, .28, depth, floor);
  }
  box(0, height + .12, center, width + .5, .25, depth + .4, dark);
  for (const z of [front + .14, back - .14]) {
    box(0, height / 2, z, width + .52, height, .29, plaster);
  }
  for (const sign of [-1, 1]) {
    const x = sign * side;
    box(x + sign * .145, height / 2, center, .29, height, depth, plaster);
    box(x - sign * .07, .48, center, .14, .94, depth, dark);
    box(x - sign * .176, .96, center, .055, .048, depth, trim);
    box(x - sign * .14, height - .31, center, .22, .28, depth, dark);
    for (const z of [-6.7, -3.1, .5, 4.4]) {
      box(x - sign * .21, 1.57, z, .245, 3.09, .28, dark);
      box(x - sign * .36, 2.71, z, .15, .29, .38, sign < 0 ? light : cool);
      box(x - sign * .43, 2.71, z, .072, .371, .07, steel);
    }
  }
  fixture(0, 3.6, 5.1);
  fixture(0, -1.25, 4.6, cool);
  point(.5, height - .67, 3.9, lightTone, 24, 13);
  const accent = point(0, height - .1, -5.9, lightTone, 32, 12);

  const instrument = instrumentTexture(building, room.color);
  let character;
  if (!upstairs) {
    door(front - .17, Math.PI, 'EXIT', 'TO THE STREET');
    for (const sign of [-1, 1]) {
      box(sign * 1.36, .016, .1, .055, .035, 12.14, trim);
    }
    plaque(room.title.toUpperCase(), room.ground.toUpperCase(), 0, height - .78, back + .13, 6.7);
    if (room.steps) {
      const rising = room.steps > 0;
      const stepsZ = -6.51;
      box(0, 2.96, stepsZ, 2.5, .21, .25, trim);
      box(0, height - .61, stepsZ, 3.32, .15, .21, dark);
      for (const sign of [-1, 1]) {
        const x = sign * 1.24;
        box(x, 1.44, stepsZ, .115, 2.91, .25, trim);
        box(x, rising ? 1.56 : .43, -7.86, .064, .064, 3.10, light, 0, rising ? .53 : -.42);
        box(x, .56, -7.83, .075, 1.11, .074, steel);
      }
      for (let i = 0; i < 9; i++) {
        const stepTop = rising ? .15 + i * .155 : -.025 - i * .166;
        box(0, stepTop - .113, -6.65 - .294 * i, 2.29, .225, .297, i % 2 ? dark : wood);
        box(0, stepTop, -6.51 - .294 * i, 2.24, .025, .044, trim);
      }
      obstruction(0, -7.93, 2.48, 2.94);
      plaque(room.destination.toUpperCase(), rising ? 'STAIRS UP' : 'STAIRS DOWN', 0, 3.33, stepsZ + .1, 2.37);
    } else {
      door(back + .22, 0, 'ELEVATOR', '02  /  CREDIT OFFICE', true);
    }

    if (building === 'foundry') {
      for (const x of [-4.47, 4.47]) {
        worktable(x, -1.8, 2.6, 1.18);
        screen(x, -2.0, .79, .42, 1.22, instrument, true);
        bench(x, 3.83, 2.62, false);
        storage(x, -7.27, 2.9, 4);
      }
    } else if (building === 'bank') {
      for (const x of [-4.8, 4.8]) {
        box(x, .57, -4.59, 2.52, 1.14, 1.28, wood);
        box(x, 1.16, -4.59, 2.69, .1, 1.4, floor);
        screen(x, -4.88, .57, .29, 1.45, instrument, true);
        obstruction(x, -4.59, 2.69, 1.4);
        bench(x, 1.95, 2.91);
        bench(x, 4.11, 2.91);
      }
    } else if (building === 'night-window') {
      const serviceX = -4.75;
      box(serviceX, .64, -3.8, 3.18, 1.27, 1.53, steel);
      box(serviceX, 1.26, -3.8, 3.30, .11, 1.65, wood);
      box(serviceX, 2.53, -4.53, 3.34, .44, .22, dark);
      box(serviceX, 2.37, -4.27, 3.20, .07, .21, light);
      obstruction(serviceX, -3.8, 3.30, 1.65);
      plaque('NIGHT WINDOW', 'AFTER-HOURS SERVICE', serviceX, 2.72, -4.13, 3.08);
      storage(4.65, -6.82, 3.1, 4);
      for (const z of [1.65, 4.09]) bench(4.63, z, 2.98);
    } else {
      for (const x of [-4.76, 4.76]) {
        storage(x, -6.12, 3.15, 3, true);
        storage(x, -.98, 3.15, 3, true);
        box(x, .52, 3.09, 2.23, 1.04, 1.75, wood);
        box(x, .89, 3.985, 1.12, .21, .025, paper);
        obstruction(x, 3.09, 2.23, 1.75);
      }
      plaque('RECEIVING', 'KEEP CENTRAL AISLE CLEAR', 0, 3.1, front - .30, 3.75, Math.PI);
    }
  } else {
    const stairLabel = room.steps > 0 ? 'STAIRS DOWN' : 'STAIRS UP';
    door(front - .17, Math.PI, room.steps ? stairLabel : 'ELEVATOR', room.ground.toUpperCase(), !room.steps);
    plaque(room.destination.toUpperCase(), room.upper.toUpperCase(), 0, height - .57, back + .14, 5.8);
    box(0, .015, -.85, 4.49, .033, 8.35, fabric);
    for (const x of [-2.12, 2.12]) box(x, .036, -.85, .038, .013, 8.13, trim);
    screen(0, back + .18, 4.08, 1.83, 1.71, instrument);
    worktable(0, -4.24, building === 'dispatch' ? 3.95 : 3.25, 1.14, 1.01);
    box(0, .55, -3.66, 2.22, .43, .042, dark);
    plaque(room.name.toUpperCase(), room.role.toUpperCase(), 0, .58, -3.636, 1.72);
    for (const x of [-4.71, 4.71]) {
      storage(x, -7.58, building === 'dispatch' ? 3.12 : 2.72, building === 'bank' ? 4 : 3, building === 'dispatch');
      if (building === 'bank' || building === 'night-window') {
        bench(x, .64, 2.57);
        worktable(x, -1.27, 1.57, 1.04, .57);
      } else {
        worktable(x, -.08, 2.80, 1.2);
        screen(x, -.37, .88, .46, 1.32, instrument, true);
      }
    }
    if (building === 'foundry') {
      for (const [index, x] of [-5.61, -5.2, -4.81].entries()) {
        const h = .14 + index * .06;
        box(x, .95 + h / 2, .13, .30, h, .26, steel);
        box(x, .96 + h, .13, .19, .018, .163, index % 2 ? light : cool);
      }
      plaque('PROTOTYPES', 'PITCH LAB / TEST BENCH', -7.09, 2.07, -1.45, 2.55, Math.PI / 2);
    } else if (building === 'bank') {
      for (const x of [-2.49, 2.49]) {
        box(x, 1.14, back + .21, .24, 2.28, .25, floor);
        box(x, 2.25, back + .33, .33, .085, .29, trim);
      }
      plaque('ACCOUNTS', 'REGISTERED CLIENT OFFICE', -7.09, 2.07, -1.45, 2.55, Math.PI / 2);
    } else if (building === 'night-window') {
      box(5.45, .74, -3.42, 1.32, 1.48, .98, steel);
      box(5.45, .76, -2.914, 1.13, 1.30, .082, dark);
      for (const x of [4.99, 5.91]) box(x, .78, -2.862, .09, .38, .037, trim);
      box(5.44, .79, -2.862, .28, .035, .037, trim);
      obstruction(5.45, -3.42, 1.32, .98);
      point(-5.3, 2.4, -4.44, lightTone, 9.7, 9);
    } else {
      box(3.86, 1.61, back + .18, 2.1, 1.52, .12, dark);
      plaque('MARKET ROUTES', 'LOADING BAY / EXCHANGE AVE', 3.86, 1.91, back + .28, 1.94);
      for (const x of [-5.6, -5.21]) {
        box(x, .95, .24, .28, .055, .38, paper, -.15);
        box(x, .979, .23, .24, .021, .32, wood, -.15);
      }
    }
    character = createMissionContact(scene, pedestrian, { reducedMotion });
    obstruction(pedestrian.x, pedestrian.z, .65, .55);
    point(0, 2.98, -2.74, coolTone, 17, 10);
  }

  for (const entry of landmarks) {
    const ring = new THREE.Mesh(new THREE.RingGeometry(.29, .333, 36),
      new THREE.MeshBasicMaterial({ color: entry.color, transparent: true, opacity: .68, toneMapped: false }));
    ring.position.set(entry.x, .055, entry.z);
    ring.rotation.x = -Math.PI / 2;
    scene.add(ring);
  }

  for (const [material, values] of batches) {
    const mesh = new THREE.InstancedMesh(block, material, values.length);
    for (const [index, [x, y, z, w, h, d, yaw, pitch]] of values.entries()) {
      transform.position.set(x, y, z);
      transform.rotation.set(pitch, yaw, 0);
      transform.scale.set(w, h, d);
      transform.updateMatrix();
      mesh.setMatrixAt(index, transform.matrix);
    }
    mesh.computeBoundingSphere();
    scene.add(mesh);
  }

  const bounds = { minX: -side, maxX: side, minZ: back, maxZ: front };
  const brightness = accent.intensity;
  return {
    bounds, landmarks, yaw: 0,
    mapFeatures: { blocks },
    spawn: new THREE.Vector3(0, 1.68, 3.9),
    elevatorArrival: { x: 0, z: room.steps ? -3.04 : -5.81, yaw: Math.PI },
    collides(x, z, r = .3) {
      if (x - r < bounds.minX || x + r > bounds.maxX || z - r < bounds.minZ || z + r > bounds.maxZ) return true;
      return blocks.some(([x1, z1, x2, z2]) => x + r > x1 && x - r < x2 && z + r > z1 && z - r < z2);
    },
    update(elapsed) {
      character?.update(elapsed);
      if (!reducedMotion) accent.intensity = brightness + .44 * Math.sin(elapsed * .86);
    },
    setReducedMotion(enabled) {
      reducedMotion = enabled;
      character?.setReducedMotion(enabled);
      accent.intensity = brightness;
    }
  };
}
