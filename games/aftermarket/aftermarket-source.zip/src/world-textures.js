import * as THREE from 'three';

export function seeded(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

export function canvasTexture(width, height, paint, repeatX = 1, repeatY = 1) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  paint(canvas.getContext('2d'), width, height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  if (repeatX !== 1 || repeatY !== 1) {
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(repeatX, repeatY);
  }
  return texture;
}

const tau = Math.PI * 2;
const fractional = (value) => value - Math.floor(value);
const palettes = {
  street: [67, 75, 74], concrete: [117, 120, 112], tile: [75, 104, 99], plaster: [93, 88, 76],
  alley: [71, 77, 73], brick: [119, 80, 62], metal: [72, 88, 88], aggregate: [90, 96, 88],
};
const surfaceCache = new Map();

function masonry(x, y, columns, rows, joint, bevel) {
  const row = Math.floor(y * rows);
  const u = fractional(x * columns + (row % 2) * .5);
  const v = fractional(y * rows);
  const edge = Math.min(u, 1 - u, v, 1 - v);
  const face = THREE.MathUtils.clamp((edge - joint) / bevel, 0, 1);
  const tone = Math.sin((Math.floor(x * columns + (row % 2) * .5) % columns) * 31.71 + (row % rows) * 17.33);
  return face * (.84 + .13 * tone);
}

function surfaceRelief(name, x, y, cloud, grain) {
  switch (name) {
    case 'alley': return masonry(x, y, 6, 12, .044, .105) * .81 + cloud * .10 + grain * .08;
    case 'brick': return masonry(x, y, 4, 14, .046, .075) * .83 + cloud * .09 + grain * .13;
    case 'tile': return masonry(x, y, 5, 10, .024, .055) * .86 + cloud * .15 + grain * .018;
    case 'concrete': return masonry(x, y, 2, 4, .012, .035) * .56 + cloud * .16 + grain * .16;
    case 'metal': return .41 + .31 * Math.cos(tau * x * 12) + cloud * .13 + grain * .06;
    case 'plaster': return .43 + cloud * .25 + grain * .15;
    case 'aggregate': return .51 + cloud * .19 + grain * .26;
    default: {
      const seam = Math.min(1, Math.abs(Math.sin(tau * (x * 2 + .12 * Math.sin(tau * y) + .07 * Math.sin(4 * tau * y)))) * 27);
      return .34 + .09 * seam + cloud * .21 + grain * .30;
    }
  }
}

function paintSurface(ctx, w, h, name, bump) {
  const base = palettes[name];
  const random = seeded(889 + Object.keys(palettes).indexOf(name) * 131);
  const pixels = ctx.createImageData(w, h);
  const joints = name === 'alley' || name === 'tile' || name === 'brick' || name === 'concrete';
  const contrast = name === 'street' || name === 'aggregate' ? 31 : 17;
  for (let row = 0; row < h; row++) {
    const y = row / h;
    const nextY = (row === h - 1 ? 0 : row + 1) / h;
    const course = Math.sin(tau * y * 3);
    for (let col = 0; col < w; col++) {
      const x = col / w;
      const nextX = (col === w - 1 ? 0 : col + 1) / w;
      const i = 4 * (row * w + col);
      const grain = random();
      const cloud = .5 + .25 * Math.sin(tau * (x * 3 - course * .14)) * Math.cos(tau * y * 2) + .18 * Math.sin(tau * (x * 7 + y * 3));
      const relief = surfaceRelief(name, x, y, cloud, grain);
      if (bump) {
        pixels.data[i] = pixels.data[i + 1] = pixels.data[i + 2] = relief * 255;
      } else {
        const shoulder = surfaceRelief(name, nextX, nextY, cloud, grain);
        const shadow = (relief - shoulder) * 91;
        const fine = (grain - .5) * contrast;
        const drip = Math.sin(tau * (x * 19 + .14 * Math.sin(tau * y * 2))) * Math.sin(tau * (y + x * 5)) * 4;
        const shade = (cloud - .5) * 29 + fine + drip + shadow;
        const joint = joints ? Math.max(0, .62 - relief) * 56 : 0;
        const damp = Math.max(0, .43 - cloud) * 35;
        pixels.data[i] = base[0] + shade - joint - damp;
        pixels.data[i + 1] = base[1] + shade - joint - damp * .78;
        pixels.data[i + 2] = base[2] + shade - joint - damp * .65;
      }
      pixels.data[i + 3] = 255;
    }
  }
  ctx.putImageData(pixels, 0, 0);
  if (bump) return;
  if (name === 'metal' || name === 'plaster' || name === 'brick') {
    for (let i = 0; i < 76; i++) {
      const x = random() * w;
      const y = 8 + random() * (h - 64);
      const length = 6 + random() * 51;
      const trail = ctx.createLinearGradient(x, y, x, y + length);
      trail.addColorStop(0, i % 3 === 0 ? 'rgba(177,162,131,.12)' : 'rgba(15,20,16,.22)');
      trail.addColorStop(1, 'rgba(15,20,16,0)');
      ctx.fillStyle = trail;
      ctx.fillRect(x, y, .6 + random() * 2.2, length);
    }
  }
  if (name === 'street' || name === 'alley' || name === 'aggregate') {
    for (let i = 0; i < 230; i++) {
      const x = random() * w;
      const y = random() * h;
      ctx.fillStyle = i % 4 ? 'rgba(183,188,171,.15)' : 'rgba(7,12,10,.24)';
      ctx.fillRect(x, y, .6 + random() * 3.5, .5 + random() * 1.45);
    }
  }
}

function repeatedSurface(name, repeatX, repeatY, bump = false) {
  const key = `${name}/${bump}`;
  if (!surfaceCache.has(key)) {
    const texture = canvasTexture(512, 512, (ctx, w, h) => paintSurface(ctx, w, h, name, bump));
    if (bump) texture.colorSpace = THREE.NoColorSpace;
    surfaceCache.set(key, texture);
  }
  const texture = surfaceCache.get(key).clone();
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(repeatX, repeatY);
  return texture;
}

export function surfaceTexture(name, repeatX = 1, repeatY = 1) {
  return repeatedSurface(name, repeatX, repeatY);
}

export function surfaceBumpTexture(name, repeatX = 1, repeatY = 1) {
  return repeatedSurface(name, repeatX, repeatY, true);
}

export function glowTexture() {
  return canvasTexture(128, 128, (ctx, w, h) => {
    const gradient = ctx.createRadialGradient(w / 2, h / 2, 1, w / 2, h / 2, w / 2);
    gradient.addColorStop(0, 'rgba(255,255,255,0.88)');
    gradient.addColorStop(0.18, 'rgba(255,255,255,0.48)');
    gradient.addColorStop(0.46, 'rgba(255,255,255,0.13)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);
  });
}

export function reflectionTexture() {
  const random = seeded(9013);
  return canvasTexture(128, 256, (ctx, w, h) => {
    const gradient = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, h / 2);
    gradient.addColorStop(0, 'rgba(255,255,255,.49)');
    gradient.addColorStop(0.15, 'rgba(255,255,255,.31)');
    gradient.addColorStop(0.33, 'rgba(255,255,255,.04)');
    gradient.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 510; i++) {
      const y = 12 + random() * (h - 24);
      const centerStrength = Math.sin(y / h * Math.PI);
      const x = (0.18 + random() * 0.64) * w;
      const span = random() * (22 - Math.abs(x - w / 2) * 0.39);
      const alpha = random() * centerStrength * (1 - Math.abs(x - w / 2) / 46);
      ctx.fillStyle = `rgba(255,255,255,${alpha.toFixed(3)})`;
      ctx.fillRect(x, y, span, 0.6 + random() * 1.3);
    }
    ctx.globalCompositeOperation = 'destination-in';
    const horizontal = ctx.createLinearGradient(0, 0, w, 0);
    horizontal.addColorStop(0, 'rgba(255,255,255,0)');
    horizontal.addColorStop(0.25, 'rgba(255,255,255,0.66)');
    horizontal.addColorStop(0.52, 'rgba(255,255,255,1)');
    horizontal.addColorStop(0.78, 'rgba(255,255,255,0.58)');
    horizontal.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = horizontal;
    ctx.fillRect(0, 0, w, h);
  });
}

export function signTexture(title, subtitle, colors, variant = 'wide') {
  const vertical = variant === 'vertical';
  return canvasTexture(vertical ? 144 : 768, vertical ? 600 : 172, (ctx, w, h) => {
    const gradient = ctx.createLinearGradient(0, 0, w, h);
    gradient.addColorStop(0, colors.panel);
    gradient.addColorStop(1, '#101919');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = colors.trim;
    ctx.lineWidth = 3;
    ctx.strokeRect(7, 7, w - 14, h - 14);
    ctx.lineWidth = 1;
    ctx.strokeRect(15, 15, w - 30, h - 30);
    ctx.fillStyle = colors.text;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    if (vertical) {
      ctx.font = '700 62px Georgia, serif';
      const letters = Array.from(title);
      const spacing = Math.min(72, (h - 66) / letters.length);
      for (const [i, letter] of letters.entries()) {
        ctx.fillText(letter, w / 2, h / 2 + (i - (letters.length - 1) / 2) * spacing);
      }
      return;
    }
    ctx.font = '700 80px Georgia, serif';
    ctx.fillText(title, w / 2, subtitle ? 66 : h / 2 + 3, w - 65);
    if (subtitle) {
      ctx.fillStyle = colors.aux;
      ctx.font = '700 21px monospace';
      ctx.fillText(subtitle, w / 2, 133, w - 70);
    }
  });
}

export function posterTexture(words, background, ink) {
  return canvasTexture(256, 360, (ctx, w, h) => {
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = ink;
    ctx.lineWidth = 2;
    ctx.strokeRect(13, 13, w - 26, h - 26);
    ctx.fillStyle = ink;
    ctx.font = '800 42px Georgia, serif';
    ctx.textAlign = 'center';
    words.forEach((word, i) => ctx.fillText(word, w / 2, 115 + i * 53, w - 45));
    ctx.beginPath();
    ctx.moveTo(45, h - 70);
    ctx.lineTo(211, h - 70);
    ctx.stroke();
    ctx.font = '700 12px monospace';
    ctx.fillText('EXCHANGE DISTRICT', w / 2, h - 43);
    const random = seeded(403);
    for (let i = 0; i < 80; i++) {
      ctx.fillStyle = random() > 0.46 ? 'rgba(4,8,6,0.2)' : 'rgba(239,235,205,0.23)';
      ctx.fillRect(random() * w, random() * h, 1 + random() * 33, random() * 1.7);
    }
  });
}

export function windowTexture(role, variant) {
  const random = seeded(7207 + variant);
  return canvasTexture(256, 360, (ctx, w, h) => {
    const cool = role === 'bank';
    const colors = cool
      ? ['#657b6e', '#304d45', '#23423f', '#172d2a', '#88a698']
      : ['#ba9469', '#664a35', '#594132', '#392d26', '#c09764'];
    const back = ctx.createLinearGradient(0, 0, 0, h);
    back.addColorStop(0, colors[0]);
    back.addColorStop(0.25, colors[1]);
    back.addColorStop(1, colors[3]);
    ctx.fillStyle = back;
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = colors[4];
    ctx.globalAlpha = 0.22;
    for (let i = 0; i < 4; i++) ctx.fillRect(11 + i * 63, 27, 3, h - 30);
    ctx.globalAlpha = 1;

    if (variant % 3 < 2) {
      const canopy = variant === 0 ? 64 : 108;
      ctx.fillStyle = colors[1];
      ctx.fillRect(0, 5, w, canopy);
      ctx.fillStyle = colors[0];
      ctx.globalAlpha = 0.32;
      for (let y = 13; y < canopy; y += 6) ctx.fillRect(0, y, w, 1);
      ctx.globalAlpha = 1;
    }

    ctx.fillStyle = colors[3];
    ctx.fillRect(10, 243, 121, 14);
    ctx.fillRect(26, 253, 7, 94);
    ctx.fillRect(111, 253, 7, 94);
    ctx.fillRect(59, 190, 45, 31);
    ctx.fillRect(79, 221, 5, 20);
    ctx.fillRect(75, 239, 16, 4);
    for (const x of [166, 209]) {
      ctx.fillRect(x, 236, 30, 39);
      ctx.fillRect(x + 14, 264, 6, 60);
      ctx.fillRect(x + 3, 319, 27, 5);
    }

    const lampX = 150 + variant * 11;
    ctx.fillStyle = colors[3];
    ctx.fillRect(lampX - 4, 0, 3, 98);
    ctx.beginPath();
    ctx.moveTo(lampX - 21, 98);
    ctx.lineTo(lampX + 16, 98);
    ctx.lineTo(lampX + 35, 116);
    ctx.lineTo(lampX - 40, 116);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = colors[4];
    ctx.fillRect(lampX - 37, 115, 68, 3);
    const light = ctx.createRadialGradient(lampX, 120, 1, lampX, 120, 155);
    light.addColorStop(0, cool ? 'rgba(189,237,208,.27)' : 'rgba(254,212,145,.31)');
    light.addColorStop(1, 'rgba(255,241,204,0)');
    ctx.fillStyle = light;
    ctx.fillRect(0, 112, w, h - 112);

    ctx.fillStyle = cool ? 'rgba(183,213,209,.08)' : 'rgba(255,207,161,.07)';
    for (let i = 0; i < 5; i++) {
      const x = random() * w;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + 20, 0);
      ctx.lineTo(x - 55, h);
      ctx.lineTo(x - 62, h);
      ctx.fill();
    }
    for (let i = 0; i < 580; i++) {
      ctx.fillStyle = random() > 0.48 ? 'rgba(242,245,232,.09)' : 'rgba(9,19,14,.12)';
      ctx.fillRect(random() * w, random() * h, 0.4 + random() * 2.9, 1 + random() * 4);
    }
  });
}
