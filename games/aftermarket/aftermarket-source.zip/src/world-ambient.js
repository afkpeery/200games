import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { canvasTexture } from './world-textures.js';
import { contactFabricTexture } from './world-contacts.js';

const unitBlock = new THREE.BoxGeometry(1, 1, 1);
const blockMaterial = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.67 });
const windowMaterial = new THREE.MeshBasicMaterial({ vertexColors: true });
const blockTransform = new THREE.Object3D();

function blocks(parts, material = blockMaterial) {
  const geometries = parts.map(([paint, x, y, z, w, h, d, roll = 0]) => {
    const geometry = unitBlock.clone();
    blockTransform.position.set(x, y, z);
    blockTransform.rotation.set(0, 0, roll);
    blockTransform.scale.set(w, h, d);
    blockTransform.updateMatrix();
    geometry.applyMatrix4(blockTransform.matrix);
    const { count } = geometry.getAttribute('position');
    const colors = new Float32Array(count * 3);
    const color = new THREE.Color(paint);
    for (let i = 0; i < count; i++) color.toArray(colors, i * 3);
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    return geometry;
  });
  const mesh = new THREE.Mesh(mergeGeometries(geometries), material);
  for (const geometry of geometries) geometry.dispose();
  return mesh;
}

function tram(scene) {
  const train = new THREE.Group();
  train.name = 'Exchange tram';
  const siding = 0x58706a;
  const cap = 0x81928a;
  const trim = 0x82674a;
  const underbody = 0x162928;
  const shell = [];
  const windows = [];
  for (const center of [-2.36, 2.36]) {
    shell.push(
      [siding, center, .719, 0, 4.48, 1.11, 1.73],
      [cap, center, 1.27, 0, 4.26, .25, 1.56],
      [underbody, center, .24, 0, 4.16, .195, 1.55],
      [trim, center, .421, .868, 4.45, .070, .040],
      [underbody, center, .886, .86, 4.28, .561, .043]
    );
    for (let bay = 0; bay < 6; bay++) {
      const x = center - 1.73 + bay * .688;
      windows.push([
        bay % 3 === 1 ? 0xbda17b : 0xe2c18f, x, .888, .885, .481, .365, .02
      ]);
      shell.push([trim, x + .25, .890, .903, .028, .396, .018]);
      if (bay === 1 || bay === 4) {
        shell.push([underbody, x - .29, .711, .896, .018, .84, .022]);
      }
    }
  }
  shell.push([underbody, 0, .489, 0, .44, .611, 1.354]);
  for (const z of [-.51, .51]) {
    windows.push([0xe9c78a, 4.608, .463, z, .023, .127, .134]);
    windows.push([0xb85444, -4.608, .475, z, .025, .125, .106]);
  }
  train.add(blocks(shell), blocks(windows, windowMaterial));
  train.position.set(-1.5, 6.66, -19.39);
  scene.add(train);

  return (time) => {
    const cycle = (time + 4.10) % 19;
    train.visible = cycle <= 8.8;
    train.position.x = -18 + cycle * 4.35;
  };
}

function pedestrian(scene, preset, cloth) {
  const { name, from, to, coat, pants, skin, phase } = preset;
  const root = new THREE.Group();
  root.name = name;
  scene.add(root);

  const bag = 0x332b26;
  const top = new THREE.Group();
  top.add(blocks([
    [coat, 0, 1.11, 0, .36, .50, .205],
    [coat, 0, 1.34, 0, .38, .117, .224],
    [0x544c3f, 0, 1.382, .075, .234, .083, .124],
    [skin, 0, 1.516, .01, .172, .195, .171],
    [0x312f29, 0, 1.603, -.02, .195, .106, .191],
    [0x312f29, 0, 1.559, .069, .219, .039, .105],
    [bag, .143, 1.141, .128, .11, .303, .071, .26],
    [0x8b7658, 0, 1.144, .118, .030, .484, .020, .55],
  ], cloth));
  root.add(top);

  const arms = [-1, 1].map((side) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(side * .204, 1.333, 0);
    shoulder.add(blocks([
      [coat, side * .026, -.141, 0, .115, .31, .12, side * .13],
      [coat, side * .041, -.325, .055, .093, .122, .107, side * .09],
      [skin, side * .048, -.393, .064, .070, .087, .074],
    ], cloth));
    top.add(shoulder);
    return shoulder;
  });

  const calves = [-1, 1].map((side) => {
    const knee = new THREE.Group();
    knee.position.set(side * .099, .855, 0);
    knee.add(blocks([
      [pants, 0, -.345, 0, .139, .707, .143],
      [0x211f1f, 0, -.767, .039, .145, .128, .219],
    ], cloth));
    root.add(knee);
    return knee;
  });

  const dx = to[0] - from[0];
  const dz = to[1] - from[1];
  const yaw = Math.atan2(dx, dz);
  const walk = Math.hypot(dx, dz) / .91;
  const leg = walk + .85;
  const update = (time) => {
    const cycle = (time + phase) % (leg * 2);
    const back = cycle >= leg;
    const local = cycle % leg;
    const fraction = Math.min(1, local / walk);
    const distance = back ? 1 - fraction : fraction;
    const turn = THREE.MathUtils.smoothstep(local, walk, leg);
    const stride = Math.min(THREE.MathUtils.smoothstep(local, 0, .65), 1 - THREE.MathUtils.smoothstep(local, walk - .65, walk));
    const step = Math.sin(local * 8.3) * stride;
    root.position.set(from[0] + dx * distance, .104 + Math.abs(step) * .022, from[1] + dz * distance);
    root.rotation.y = yaw + (Number(back) + turn) * Math.PI;
    calves[0].rotation.x = step * .34;
    calves[1].rotation.x = -step * .34;
    arms[0].rotation.x = -step * .31;
    arms[1].rotation.x = step * .31;
    top.rotation.y = step * .054;
    top.rotation.z = step * .022;
  };
  update(0);
  return update;
}

function tickerDecal(scene) {
  const map = canvasTexture(320, 224, (ctx, width, height) => {
    ctx.fillStyle = '#253831';
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = '#a98458';
    ctx.lineWidth = 4;
    ctx.strokeRect(6, 6, width - 12, height - 12);
    ctx.strokeStyle = '#617367';
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.moveTo(14, 22 + i * 24);
      ctx.lineTo(width - 14, 22 + i * 24);
      ctx.stroke();
    }
    ctx.strokeStyle = '#cf9b60';
    ctx.lineWidth = 5;
    ctx.beginPath();
    const vertices = [[24, 130], [74, 102], [113, 114], [157, 72], [206, 89], [281, 43]];
    for (const [i, [x, y]] of vertices.entries()) {
      if (!i) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.fillStyle = '#f2d197';
    ctx.font = '800 44px Georgia, serif';
    ctx.fillText('TICKER', 21, 175);
    ctx.font = '700 17px monospace';
    ctx.fillText('YOUR MARKET GUIDE', 22, 201);
  });
  const backing = blocks([[0x263332, 0, 0, -.017, 1.02, .732, .049]]);
  const decal = new THREE.Mesh(
    new THREE.PlaneGeometry(.995, .707),
    new THREE.MeshBasicMaterial({ map })
  );
  decal.position.z = .009;
  const placard = new THREE.Group();
  placard.position.set(8.66, 1.73, 1.54);
  placard.rotation.y = -Math.PI / 2;
  placard.add(backing, decal);
  scene.add(placard);
}

const districtWalks = [
  { name: 'East sidewalk pedestrian', from: [7.56, -33.7], to: [7.56, -24.25], coat: 0x53634e, pants: 0x293e40, skin: 0x816451, phase: 1 },
  { name: 'Auction Row pedestrian', from: [-18.3, -17.8], to: [-18.3, -6.2], coat: 0x665141, pants: 0x373b36, skin: 0xab8360, phase: 7.5 },
  { name: 'Crownline pedestrian', from: [18.55, 8.7], to: [18.55, 16.5], coat: 0x67546d, pants: 0x363340, skin: 0xb68264, phase: 3.7 },
];

function clearWalk(preset, collides) {
  if (!collides) return true;
  const [fx, fz] = preset.from;
  const [tx, tz] = preset.to;
  const steps = Math.ceil(Math.hypot(tx - fx, tz - fz) / .4);
  if (steps < 2) return false;
  for (let i = 0; i <= steps; i++) {
    const progress = i / steps;
    if (collides(THREE.MathUtils.lerp(fx, tx, progress), THREE.MathUtils.lerp(fz, tz, progress), .22)) return false;
  }
  return true;
}

export function addAmbient(scene, { collides, pedestrianRoutes = [] } = {}) {
  const animateTram = tram(scene);
  const cloth = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .85, map: contactFabricTexture() });
  const walks = [...districtWalks, ...pedestrianRoutes]
    .filter((preset) => clearWalk(preset, collides))
    .map((preset, i) => pedestrian(scene, {
      coat: 0x4b5f56, pants: 0x353f3b, skin: 0x956c52, phase: i * 2.6, ...preset,
    }, cloth));
  tickerDecal(scene);

  return (elapsed) => {
    animateTram(elapsed);
    walks.forEach((walk) => walk(elapsed));
  };
}
