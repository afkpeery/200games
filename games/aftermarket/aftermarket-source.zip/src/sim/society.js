import { netWorth } from './economy.js'
import { FINAL_DAY } from './rules.js'

const INVITATION_WORTH = 24000
const TITLE = 'The Quiet Ledger'

const INVITATIONS = {
  tycoon: 'Your founders trust your signature. The Quiet Ledger asks what you would do with capital that has carried no name for a century.',
  redemption: 'The council read every entry in your public file. It wants to know which account you would open next.',
  kingpin: 'A sealed card arrives at the address you never published. The Quiet Ledger has reserved one seat for you.',
  broker: 'The same invitation reaches you from two sides of Meridian. Both bear one signature. The Quiet Ledger is waiting.'
}

const CHOICES = [
  {
    id: 'society:charter',
    label: 'Open the reserve to founders',
    detail: 'Put the reserve behind founder-owned ventures with published terms.',
    title: 'Civic Charter',
    description: 'You pledge the reserve to a public charter. When the first founders draw against it, every stake and fee appears in the windows of Meridian Bank.'
  },
  {
    id: 'society:patronage',
    label: 'Accept a seat on the board',
    detail: 'Keep the reserve private and choose which ventures receive its patronage.',
    title: 'Silent Partner',
    description: 'A brass chair waits behind a door you passed every night. You take the seat and direct the first private commitment toward a venture the banks turned away.'
  },
  {
    id: 'society:decline',
    label: 'Return the invitation',
    detail: 'Leave the reserve with the council and keep your firm independent.',
    title: 'The Independent',
    description: 'You slide the card back under the door. At the next market opening, your firm posts terms under its own name and the council’s chair sits empty.'
  }
]

function invitationFor(state) {
  if (state.day !== FINAL_DAY || !Object.hasOwn(INVITATIONS, state.ending?.id)) return null
  if (netWorth(state) < INVITATION_WORTH) return null
  return INVITATIONS[state.ending.id]
}

function completedChoice(state) {
  return CHOICES.find((choice) => choice.id === state.societyChoice)
}

export function getSociety(state) {
  const invitation = invitationFor(state)
  if (!invitation) return null
  const completed = completedChoice(state)
  if (completed) {
    const { id, title, description } = completed
    return {
      status: 'resolved',
      title: TITLE,
      line: 'The council has entered your decision into its archive.',
      actions: [],
      choice: { id, title, description }
    }
  }
  return {
    status: 'invited',
    title: TITLE,
    line: invitation,
    actions: CHOICES.map(({ id, label, detail }) => ({ id, label, detail }))
  }
}

export function chooseSociety(state, id, log) {
  if (!invitationFor(state)) return { ok: false, message: 'The Quiet Ledger has no invitation for this run.' }
  if (completedChoice(state)) return { ok: false, message: 'Your decision has already been entered into the archive.' }
  const choice = CHOICES.find((entry) => entry.id === id)
  if (!choice) return { ok: false, message: 'Choose an option from the invitation.' }

  // Store the branch alongside the original ending so previous saves and scores stay compatible.
  state.societyChoice = choice.id
  log(TITLE + ' · ' + choice.title, choice.description, 'society')
  return { ok: true, message: choice.description }
}
