import { money } from './economy.js'
import { randomFor, shuffled } from './random.js'

const propertyLots = [
  [
    { name: 'Exchange Newsstand', description: 'A curbside concession on the morning commuter route.', opening: 225, increment: 25, value: 350, income: 20 },
    { name: 'Canal Storage Bay', description: 'A secure storage unit rented by small merchants.', opening: 275, increment: 25, value: 415, income: 24 },
    { name: 'Foundry Kiosk', description: 'A counter leased to the Foundry’s late-shift café.', opening: 325, increment: 25, value: 490, income: 29 },
  ],
  [
    { name: 'Northline Dispatch Office', description: 'A compact office with a courier firm in residence.', opening: 550, increment: 50, value: 820, income: 42 },
    { name: 'Glass Row Workshop', description: 'A street-level workspace leased to a lighting maker.', opening: 650, increment: 50, value: 970, income: 48 },
    { name: 'Switchyard Garages', description: 'Two service bays on a short-term repair lease.', opening: 700, increment: 50, value: 1_040, income: 53 },
  ],
  [
    { name: 'Canal Printworks', description: 'A brick commercial unit rented to an independent printer.', opening: 950, increment: 75, value: 1_400, income: 65 },
    { name: 'Meridian Clinic Suite', description: 'A furnished office on a fixed-term clinic lease.', opening: 1_100, increment: 75, value: 1_625, income: 72 },
    { name: 'Charter Row Showroom', description: 'A corner storefront with a standing retail tenant.', opening: 1_250, increment: 75, value: 1_850, income: 80 },
  ],
  [
    { name: 'Harbor Cold Store', description: 'A leased cold-storage site on the freight route.', opening: 1_450, increment: 100, value: 2_150, income: 95 },
    { name: 'Meridian Studio Lofts', description: 'Several studios with staggered commercial leases.', opening: 1_650, increment: 100, value: 2_450, income: 110 },
    { name: 'Northline Office Annex', description: 'A small office annex fully leased to local firms.', opening: 1_900, increment: 100, value: 2_825, income: 125 },
  ],
]

const bidders = ['Aster Property Group', 'Sable Holdings', 'Keene & Co.', 'Folio Capital', 'North Pier Trust']

const catalog = [
  { id: 'charcoal-sofa', slot: 'sofa', name: 'Charcoal Sectional', description: 'A low, deep sectional in charcoal weave.', price: 360 },
  { id: 'cognac-sofa', slot: 'sofa', name: 'Cognac Sofa', description: 'Warm cognac upholstery with a squared profile.', price: 540 },
  { id: 'walnut-table', slot: 'table', name: 'Walnut Coffee Table', description: 'A dark walnut top with softened edges.', price: 180 },
  { id: 'glass-table', slot: 'table', name: 'Smoked Glass Table', description: 'Smoked glass on a thin, architectural base.', price: 290 },
  { id: 'arc-lamp', slot: 'lamp', name: 'Arc Floor Lamp', description: 'A curved steel floor lamp with a wide shade.', price: 95 },
  { id: 'brass-lamp', slot: 'lamp', name: 'Brushed Brass Lamp', description: 'A slender brass floor lamp with a warm glow.', price: 145 },
]

function lotFor(state) {
  const index = state.day - 1
  const phase = Math.floor(index / 3)
  const order = shuffled(propertyLots[phase], randomFor(state.seed, 'auction-lots', phase))
  return { ...order[index % 3], id: 'auction-lot-' + state.day }
}

function rivalsFor(state, lot) {
  const random = randomFor(state.seed, 'auction-bidders', state.day)
  return shuffled(bidders, random).slice(0, 2).map((name) => {
    const budget = lot.value * (0.78 + random() * 0.33)
    const increments = Math.max(1, Math.floor((budget - lot.opening) / lot.increment))
    return { name, limit: lot.opening + increments * lot.increment }
  })
}

export function getAuction(state) {
  const lot = lotFor(state)
  const saved = state.venues?.auction
  const auction = saved?.day === state.day ? saved : { status: 'open', leader: null, amount: lot.opening, bids: [] }
  const nextBid = auction.status === 'open' ? auction.amount + (auction.bids.length ? lot.increment : 0) : null
  return { ...auction, lot, nextBid, canBid: nextBid !== null && state.cash >= nextBid && !state.ending }
}

export function getFurniture(state) {
  return catalog.map((item) => ({
    ...item,
    installed: state.venues?.installed?.[item.slot] === item.id,
    owned: state.venues?.furniture?.includes(item.id) ?? false,
    affordable: state.cash >= item.price && !state.ending,
  }))
}

export function getFurnishingIds(state) {
  return Object.values(state.venues?.installed ?? {})
}

function saveAuction(state, status, leader, amount, bids) {
  state.venues ??= {}
  state.venues.auction = { day: state.day, status, leader, amount, bids }
}

function auctionAction(state, action, log) {
  const { lot, status, nextBid, bids, amount, leader } = getAuction(state)
  if (status !== 'open') return { ok: false, message: 'Today’s auction has closed. A new lot opens next market day.' }
  const rivals = rivalsFor(state, lot)
  if (action === 'pass') {
    rivals.sort((first, second) => second.limit - first.limit || Number(second.name === leader) - Number(first.name === leader))
    const [winner, runnerUp] = rivals
    const finalPrice = Math.max(amount, Math.min(winner.limit, runnerUp.limit + lot.increment))
    const result = winner.name + ' bought ' + lot.name + ' for ' + money(finalPrice) + '.'
    const closingBids = finalPrice > amount || !bids.length ? [...bids, { bidder: winner.name, amount: finalPrice }] : bids
    saveAuction(state, 'passed', winner.name, finalPrice, closingBids)
    log('Auction lot passed', result, 'auction')
    return { ok: true, message: result }
  }
  if (action !== 'bid') return { ok: false, message: 'Choose an available auction action.' }
  if (state.cash < nextBid) return { ok: false, message: 'The next bid requires ' + money(nextBid) + ' in cash.' }
  const playerBids = [...bids, { bidder: 'You', amount: nextBid }]
  const counter = nextBid + lot.increment
  const firstRival = (bids.length / 2) % rivals.length
  const challenger = [rivals[firstRival], rivals[1 - firstRival]].find((rival) => rival.limit >= counter)
  if (challenger) {
    saveAuction(state, 'open', challenger.name, counter, [...playerBids, { bidder: challenger.name, amount: counter }])
    return { ok: true, message: challenger.name + ' raised to ' + money(counter) + '.' }
  }

  state.cash -= nextBid
  state.assets.push({ id: lot.id, name: lot.name, value: lot.value, price: nextBid, income: lot.income, channel: 'Auction', purchasedDay: state.day, status: 'owned' })
  saveAuction(state, 'won', 'You', nextBid, playerBids)
  const result = lot.name + ' is yours for ' + money(nextBid) + '. It earns ' + money(lot.income) + ' per close starting tomorrow.'
  log('Auction won', result, 'auction')
  return { ok: true, message: result }
}

function furnitureAction(state, action, id, log) {
  const item = getFurniture(state).find((entry) => entry.id === id)
  if (!item || !['buy', 'install'].includes(action)) return { ok: false, message: 'Choose a piece from the showroom.' }
  if (action === 'buy' && item.owned) return { ok: false, message: 'You already own ' + item.name + '.' }
  if (action === 'buy' && !item.affordable) return { ok: false, message: 'This piece requires ' + money(item.price) + ' in cash.' }
  if (action === 'install' && !item.owned) return { ok: false, message: 'Purchase this piece before installing it.' }
  if (item.installed) return { ok: false, message: item.name + ' is already installed.' }

  state.venues ??= {}
  state.venues.furniture ??= []
  state.venues.installed ??= {}
  if (action === 'buy') {
    state.cash -= item.price
    state.venues.furniture.push(item.id)
    log('Penthouse furnished', item.name + ' purchased for ' + money(item.price) + '.', 'furniture')
  }
  state.venues.installed[item.slot] = item.id
  return { ok: true, message: item.name + ' is installed in your penthouse.' }
}

export function useVenue(state, id, log) {
  const [venue, action, item] = id.split(':')
  return venue === 'auction' ? auctionAction(state, action, log) : furnitureAction(state, action, item, log)
}

export function collectAuctionRent(state, log) {
  const income = state.assets.reduce((total, asset) => total + (asset.channel === 'Auction' && asset.purchasedDay < state.day ? asset.income : 0), 0)
  if (!income) return
  state.cash += income
  log('Auction property rent', money(income) + ' credited to your cash.', 'market')
}
