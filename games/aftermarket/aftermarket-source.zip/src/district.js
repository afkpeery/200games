export const CITY_BOUNDS = { minX: -52.628, maxX: 52.628, minZ: -96, maxZ: 64 };

export const CITY_ENTRANCES = {
  'auction-entry': {
    id: 'auction-entry', label: 'Exchange Auction House', color: '#f1bf7d', x: -21.6, z: 4.4,
    returnX: -21.6, returnZ: 5.6, returnYaw: Math.PI
  },
  'home-entry': {
    id: 'home-entry', label: 'Crownline Tower', color: '#c8b8ff', x: 21.1, z: 7.25,
    returnX: 21.1, returnZ: 8.5, returnYaw: Math.PI
  },
  'furniture-entry': {
    id: 'furniture-entry', label: 'Form & Grain', color: '#f4b395', x: 21.4, z: -27.8,
    returnX: 21.4, returnZ: -26.5, returnYaw: Math.PI
  },
  'foundry-entry': {
    id: 'foundry-entry', label: 'Foundry Incubator', color: '#ffc17a', x: -7.8, z: -0.6,
    returnX: -6.4, returnZ: -0.6, returnYaw: -Math.PI / 2
  },
  'bank-entry': {
    id: 'bank-entry', label: 'Meridian Bank Annex', color: '#98e9cd', x: 36, z: 19.2,
    returnX: 36, returnZ: 20.6, returnYaw: Math.PI
  },
  'night-window-entry': {
    id: 'night-window-entry', label: 'Night Window', color: '#ff8d84', x: -42, z: -61.1,
    returnX: -42, returnZ: -59.7, returnYaw: Math.PI
  },
  'dispatch-entry': {
    id: 'dispatch-entry', label: 'Freight Dispatch', color: '#f6a56d', x: 41, z: -24.8,
    returnX: 41, returnZ: -23.4, returnYaw: Math.PI
  },
  'exchange-entry': {
    id: 'exchange-entry', label: 'Meridian Exchange', color: '#e4bc76', x: 0, z: -40.4,
    returnX: 0, returnZ: -37.7, returnYaw: Math.PI
  }
};

export const CITY_VENUES = {
  'auction-entry': { x: -22.55, z: -0.45, width: 6.6, depth: 8, height: 10.8 },
  'home-entry': { x: 22.75, z: 2.55, width: 5.8, depth: 7.7, height: 27.8 },
  'furniture-entry': { x: 22.75, z: -32.65, width: 5.8, depth: 8, height: 7.5 },
  'bank-entry': { x: 36.55, z: 12.95, width: 10.8, depth: 10.8, height: 13.8 },
  'night-window-entry': { x: -42.7, z: -66.5, width: 9.2, depth: 9.1, height: 6.7 },
  'dispatch-entry': { x: 41.5, z: -31.7, width: 10.5, depth: 12.2, height: 8.7 }
};

// [side, Z, facade width, height, material family]
export const CITY_CORE_BLOCKS = [
  [-1, -1.2, 15.7, 12.1, 'foundry'],
  [1, -3.7, 18.3, 15.9, 'bank'],
  [-1, -14.4, 10.4, 16.4, 'foundry'],
  [1, -16.2, 7.8, 12.8, 'bank'],
  [-1, -27.8, 8.6, 9.5, 'foundry'],
  [1, -29.25, 11.1, 17.2, 'bank'],
  [-1, 13.7, 7.0, 14.2, 'bank'],
  [1, 13.5, 7.8, 12.0, 'foundry']
];

// [X, Z, width, depth, height, material index]
export const CITY_TOWERS = [
  [-23.65, -14.8, 5, 7.8, 25.5, 1],
  [23.67, -11.3, 4.8, 9.3, 25.8, 2],
  [-13.3, -42.3, 8.6, 6.6, 23.8, 3],
  [13.8, -42.7, 10.4, 8.9, 24.4, 0],
  [-25.5, -42.4, 8.2, 8.1, 33.2, 2],
  [26.7, -41.0, 5.6, 8.3, 34.2, 3],
  [-10.2, -52.8, 9.7, 8.1, 31.7, 1],
  [-1.4, -53.5, 6.4, 6.8, 29.2, 3],
  [5.6, -56.1, 8.8, 7.0, 39.9, 0],
  [22.55, -51.8, 6.4, 8.1, 31, 2],
  [30, -60, 10.8, 6.9, 37.2, 1]
];

// [X, Z, width, depth]
export const CITY_CONNECTORS = [
  [-18.35, -16, 3, 80], [18.4, -16, 3, 80],
  [0, 8.15, 46, 2.95], [0, -21.85, 42, 2.95], [0, -36.45, 38.5, 2.9],
  [0, -47.2, 40.8, 2.7], [0, 20.0, 46.5, 2.75]
];

export const CITY_NEIGHBORHOODS = [
  { name: 'North Terminal', x: 10, z: -80 },
  { name: 'North Service', x: -41, z: -57 },
  { name: 'Freight Yards', x: 41, z: -42 },
  { name: 'Exchange Core', x: 0, z: -14 },
  { name: 'Auction Row', x: -29, z: -2 },
  { name: 'Crownline', x: 36, z: 28 },
  { name: 'Merchant Mile', x: -37, z: 35 },
  { name: 'South Riverwalk', x: 3, z: 52 }
];

// [X, Z, width, depth, surface family]
export const CITY_EXPANSION_STREETS = [
  [-33.8, -16, 5.9, 153, 'avenue'], [27.2, 15.25, 4.55, 94.5, 'avenue'],
  [33.25, -56.1, 5.1, 72, 'avenue'], [48.9, -21.8, 3.0, 75.4, 'alley'],
  [0, -77.6, 99, 6.2, 'avenue'], [7.3, -61.8, 82.4, 4.5, 'alley'],
  [-44.1, -58.6, 19.4, 5.0, 'alley'], [21.2, -45.1, 25.3, 3.6, 'alley'],
  [-35.9, -21.85, 30.4, 3.6, 'alley'], [35.7, -21.85, 30.4, 3.6, 'alley'],
  [-36.4, 8.15, 29.2, 4.55, 'alley'], [0, 20.5, 99.4, 4.5, 'avenue'],
  [0, 36.95, 99.4, 5.0, 'avenue'], [0, 51.75, 101.6, 4.8, 'river'],
  [0, 41.7, 6.9, 41.5, 'avenue'], [-12.3, -76.1, 4.4, 38.0, 'alley']
];

// [X, Z, width, depth, height, facade family]
export const CITY_EXPANSION_BLOCKS = [
  [-44.6, -87.7, 11.8, 10.4, 12.8, 'industry'], [-23.3, -87.7, 11.6, 10.8, 19.3, 'brick'],
  [-5.6, -89.4, 5.6, 8.7, 14.8, 'slate'], [5.2, -88.5, 10.5, 10.2, 19.6, 'slate'],
  [20.8, -88.4, 13.5, 11.2, 16.9, 'industry'], [43.4, -86.8, 11.3, 9.8, 14.8, 'brick'],
  [-23.1, -69.7, 12.4, 7.1, 8.6, 'industry'], [-4.4, -70.0, 9.5, 7.9, 11.5, 'slate'],
  [11.0, -69.7, 10.3, 8.0, 12.9, 'industry'], [24.15, -69.5, 8.9, 8.4, 11.4, 'brick'],
  [42.5, -69.3, 10.7, 8.7, 12.7, 'industry'], [-44.0, -52.6, 11.7, 5.2, 7.4, 'industry'],
  [-24.2, -54.8, 10.7, 7.4, 10.4, 'brick'], [43.2, -51.9, 8.5, 10.2, 12.1, 'industry'],
  [-43.7, -39.4, 12.1, 12.7, 10.6, 'brick'], [-42.6, -28.5, 10.7, 6.8, 7.5, 'industry'],
  [-26.35, -28.7, 7.6, 7.9, 10.4, 'brick'], [40.9, -10.45, 11, 10.2, 13.5, 'slate'],
  [-43.6, -11.25, 10.4, 10.7, 11.8, 'slate'], [-43.4, 1.2, 11.8, 8.4, 12.3, 'brick'],
  [-26.5, -10.4, 4.6, 4.7, 7.4, 'industry'], [38.4, 0.95, 9.6, 5.9, 12.7, 'slate'],
  [-43.2, 15.4, 10.3, 5.9, 8.5, 'brick'], [-24.3, 13.8, 7.4, 4.35, 8.4, 'brick'],
  [46.25, 13.4, 5.6, 7.8, 9.9, 'slate'], [-43.7, 28.5, 11.7, 8.3, 12.0, 'brick'],
  [-24.0, 28.9, 12.7, 8.5, 12.3, 'brick'], [-10.7, 29.0, 5.4, 7.9, 8.6, 'industry'],
  [12.4, 28.8, 11.3, 8.5, 15.3, 'slate'], [39.35, 29.65, 12.8, 5.55, 14.2, 'slate'],
  [-43.9, 44.4, 10.9, 6.25, 8.5, 'slate'], [-22.6, 43.8, 8.8, 6.30, 7.9, 'brick'],
  [37.6, 44.4, 10.7, 6.9, 8.7, 'slate'], [47.15, 43.7, 5.9, 7.2, 7.6, 'brick']
];

function footprint(x, z, width, depth) {
  return [x - width / 2, z - depth / 2, x + width / 2, z + depth / 2];
}

export const CITY_MAP = {
  roads: [
    footprint(0, -12.5, 9.6, 73), ...CITY_CONNECTORS.map(road => footprint(...road)),
    ...CITY_EXPANSION_STREETS.map(road => footprint(...road))
  ],
  blocks: [
    ...CITY_CORE_BLOCKS.map(([side, z, width]) => footprint(side * 13, z, 7.9, width)),
    ...CITY_TOWERS.map(tower => footprint(...tower)),
    ...Object.values(CITY_VENUES).map(({ x, z, width, depth }) => footprint(x, z, width, depth)),
    ...CITY_EXPANSION_BLOCKS.map(block => footprint(...block)),
    footprint(0, -43.5, 19.5, 4.3)
  ]
};
