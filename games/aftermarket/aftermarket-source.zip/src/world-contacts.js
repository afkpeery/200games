import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { seeded } from './world-textures.js';

const geometry = {
  cloth: new RoundedBoxGeometry(1, 1, 1, 2, .21),
  box: new THREE.BoxGeometry(1, 1, 1),
  oval: new THREE.SphereGeometry(1, 12, 9),
  coin: new THREE.CylinderGeometry(1, 1, 1, 24),
};

const profiles = {
  founder: {
    name: 'Mara Voss', coat: 0x655b45, seam: 0x8c7861, shirt: 0xdb9a58, trousers: 0x3d3e37,
    skin: 0xa36446, hair: 0x362321, accent: 0xc68f53, width: .93, height: 1,
    style: 'swept', prop: 'folder', period: 9.8, stagger: 2.9,
    rest: { head: [.04, -.08, -.02], left: [-.22, .13, -1.03], right: [-.04, -.075, -.24] },
    work: { head: [.26, -.15, -.07], left: [-.64, .35, -1.18], right: [-.69, -.34, -.36] },
    gesture: { head: [-.055, .12, .04], right: [-.50, -.10, -1.05] },
  },
  banker: {
    name: 'Ellis Vale', coat: 0x344a46, seam: 0x57766b, shirt: 0xb5b99e, trousers: 0x2f3b3a,
    skin: 0xc18967, hair: 0x7d8379, accent: 0xbaa267, width: .96, height: 1.04,
    style: 'parted', prop: 'tablet', period: 8.8, stagger: 4.8,
    rest: { head: [.05, .05, 0], left: [-.28, .14, -.97], right: [-.065, -.04, -.23] },
    work: { head: [.31, -.11, -.04], left: [-.52, .39, -1.21], right: [-.54, -.45, -.45] },
    gesture: { head: [.05, -.16, .03], right: [-.57, -.15, -1.08] },
  },
  shark: {
    name: 'Ivo Rook', coat: 0x614945, seam: 0x8a6355, shirt: 0x36312e, trousers: 0x42403d,
    skin: 0xa87754, hair: 0x3c322b, accent: 0xbd7664, width: 1.10, height: 1.02,
    style: 'stubble', prop: 'coin', period: 9.1, stagger: 4.1,
    rest: { head: [.01, -.08, .035], left: [-.29, .09, -.95], right: [-.18, -.10, -.29] },
    work: { head: [.21, -.20, .09], left: [-.54, .21, -1.34], right: [-.22, -.12, -.38] },
    gesture: { head: [-.07, .13, -.035], right: [-.51, -.17, -.79] },
  },
  courier: {
    name: 'Pax Mercer', coat: 0xb45e37, seam: 0xe38a56, shirt: 0x536f67, trousers: 0x3e6c65,
    skin: 0x9b654b, hair: 0x322d30, accent: 0xf0c47f, width: .96, height: .98,
    style: 'cap', prop: 'clipboard', period: 8.5, stagger: 5.65,
    rest: { head: [.059, .11, 0], left: [-.33, .21, -.89], right: [-.08, -.07, -.23] },
    work: { head: [.24, -.13, -.035], left: [-.57, .30, -1.16], right: [-.55, -.39, -.49] },
    gesture: { head: [-.045, .15, -.035], right: [-.28, -.28, -1.39] },
  },
  council: {
    name: 'Council Convenor', coat: 0x324841, seam: 0x61766a, shirt: 0xc2ad7d, trousers: 0x303832,
    skin: 0xa17557, hair: 0x433931, accent: 0xbea06d, width: 1.02, height: 1.05,
    style: 'parted', prop: 'ledger', period: 11.6, stagger: 3.5,
    rest: { head: [.02, 0, 0], left: [-.28, .18, -.70], right: [-.12, -.07, -.28] },
    work: { head: [.20, -.12, -.025], left: [-.49, .24, -1.01], right: [-.25, -.10, -.38] },
    gesture: { head: [-.04, -.04, .025], right: [-.75, -.20, -.72] },
  },
};

let weave;
let grain;

function patternedTexture(fabric) {
  const size = 128;
  const random = seeded(fabric ? 39251 : 5124);
  const pixels = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      const threads = fabric ? ((x + y) % 4 < 2 ? -8 : 8) + ((x - y) % 16 === 0 ? -8 : 0) : 0;
      const variation = Math.sin((x + y) * Math.PI / 16) * 4 + random() * 24;
      const value = 222 + threads + variation;
      pixels[i] = value;
      pixels[i + 1] = value;
      pixels[i + 2] = value;
      pixels[i + 3] = 255;
    }
  }
  const texture = new THREE.DataTexture(pixels, size, size);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.generateMipmaps = true;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  return texture;
}

export function contactFabricTexture() {
  weave ??= patternedTexture(true);
  return weave;
}

function palettes(profile) {
  const matte = (color, roughness = .68) => new THREE.MeshStandardMaterial({ color, roughness });
  const fabric = (color, roughness = .86) => new THREE.MeshStandardMaterial({ color, map: contactFabricTexture(), roughness });
  const metal = (color) => new THREE.MeshStandardMaterial({ color, roughness: .43, metalness: .47 });
  grain ??= patternedTexture(false);
  return {
    coat: fabric(profile.coat), seam: fabric(profile.seam), shirt: fabric(profile.shirt), trousers: fabric(profile.trousers),
    skin: matte(profile.skin), shade: matte(new THREE.Color(profile.skin).multiplyScalar(.72)),
    hair: matte(profile.hair, .77), glint: matte(new THREE.Color(profile.hair).lerp(new THREE.Color(0xb39a79), .31)),
    boot: new THREE.MeshStandardMaterial({ color: 0x272529, map: grain, roughness: .55 }),
    bag: new THREE.MeshStandardMaterial({ color: 0x7c593c, map: grain, roughness: .67 }),
    edge: matte(0x322b29), brass: metal(profile.accent), gold: metal(0xc39158),
    paper: matte(0xe7d7b4, .91), ink: matte(0x7c8a81), eye: matte(0xe2cbac), pupil: matte(0x211e21),
    screen: new THREE.MeshStandardMaterial({ color: 0x335752, emissive: 0x34685c, emissiveIntensity: .58, roughness: .42 }),
  };
}

function joints() {
  const bodies = new Map();
  const transform = new THREE.Object3D();

  function part(parent, material, x, y, z, sx, sy, sz, roll = 0, pitch = 0, shape = 'cloth') {
    const source = geometry[shape];
    const meshGeometry = source.index ? source.toNonIndexed() : source.clone();
    transform.position.set(x, y, z);
    transform.scale.set(sx, sy, sz);
    transform.rotation.set(pitch, 0, roll);
    transform.updateMatrix();
    meshGeometry.applyMatrix4(transform.matrix);
    if (!bodies.has(parent)) bodies.set(parent, new Map());
    const batches = bodies.get(parent);
    if (!batches.has(material)) batches.set(material, []);
    batches.get(material).push(meshGeometry);
  }

  function finish() {
    for (const [parent, batches] of bodies) {
      for (const [material, parts] of batches) {
        const meshGeometry = parts.length === 1 ? parts[0] : mergeGeometries(parts);
        parent.add(new THREE.Mesh(meshGeometry, material));
        if (parts.length > 1) parts.forEach((part) => part.dispose());
      }
    }
  }

  return { part, finish };
}

function groupAt(parent, name, x, y, z = 0) {
  const group = new THREE.Group();
  group.name = name;
  group.position.set(x, y, z);
  parent.add(group);
  return group;
}

function dress(rig, profile, material, add) {
  const { coat, seam, trousers, shirt, boot, brass, edge, bag, paper } = material;
  const long = profile.prop === 'coin' || profile.prop === 'folder';
  const trunk = groupAt(rig, 'Torso', 0, .79);
  add(trunk, shirt, 0, .322, .048, .355, .512, .231);
  add(trunk, coat, 0, .28, -.071, .398, .522, .176);
  add(trunk, coat, 0, .487, -.035, .437, .139, .248);
  for (const side of [-1, 1]) {
    add(trunk, coat, side * .135, long ? .19 : .225, .040, .148, long ? .635 : .527, .279, side * .04);
    add(trunk, seam, side * .137, .111, .184, .111, .029, .018, side * .048);
    add(trunk, seam, side * .102, .416, .175, .069, .228, .028, -side * .30);
    add(trunk, coat, side * .112, .539, .117, .078, .088, .070, -side * .26);
    add(trunk, seam, side * .169, .12, .183, .007, .231, .008, side * .035);
    for (let i = 0; i < 3; i++) add(trunk, brass, side * .052, .087 + i * .075, .192, .012, .014, .009, 0, 0, 'oval');

    const name = side < 0 ? 'Left leg' : 'Right leg';
    const leg = groupAt(rig, name, side * .112, 0, side * .038);
    add(leg, trousers, 0, .442, 0, .174, .674, .188, side * .037);
    add(leg, seam, side * .060, .403, .084, .009, .363, .007, side * .038);
    add(leg, boot, 0, .097, .055, .178, .166, .261);
    add(leg, edge, 0, .027, .063, .181, .039, .276);
    add(leg, seam, 0, .13, .138, .112, .021, .074);
  }
  if (profile.prop === 'tablet' || profile.prop === 'ledger') {
    add(trunk, seam, 0, .402, .181, .036, .243, .022, .008);
    add(trunk, brass, -.126, .423, .197, .041, .018, .014, -.18);
  }
  if (profile.prop === 'coin') {
    add(trunk, seam, -.012, .51, .166, .227, .113, .125, -.068);
    add(trunk, seam, -.049, .401, .188, .066, .191, .035, -.207);
    for (let i = 0; i < 5; i++) add(trunk, shirt, -.049, .329 + i * .037, .207, .063, .009, .006, -.207);
  }
  if (profile.prop === 'clipboard') {
    add(trunk, edge, .026, .27, .193, .044, .572, .021, .63);
    add(trunk, bag, .195, .005, .128, .239, .263, .153, .11);
    add(trunk, seam, .195, .083, .207, .241, .075, .030, .11);
    add(trunk, brass, .195, .059, .226, .036, .049, .021, .11);
    add(trunk, paper, .121, .128, .167, .079, .089, .015, .11);
    add(trunk, brass, -.123, .34, .192, .066, .035, .011);
    add(trunk, brass, .143, .348, .192, .066, .035, .011);
  }
  return trunk;
}

function face(trunk, profile, material, add) {
  const { skin, shade, hair, glint, eye, pupil, boot, brass, edge } = material;
  const head = groupAt(trunk, 'Head', 0, .627, .006);
  add(head, skin, 0, -.061, .003, .064, .116, .060, 0, 0, 'oval');
  add(head, skin, 0, .082, .009, .111, .140, .105, 0, 0, 'oval');
  add(head, skin, 0, .021, .060, .086, .091, .066, 0, 0, 'oval');
  add(head, skin, .009, .076, .113, .025, .035, .025, 0, 0, 'oval');
  add(head, shade, 0, .022, .116, .063, .011, .013, -.053);
  add(head, hair, 0, .179, -.013, .111, .066, .112, -.095, 0, 'oval');
  add(head, hair, 0, .119, -.053, .108, .083, .069, 0, 0, 'oval');
  const eyes = [];
  for (const side of [-1, 1]) {
    add(head, skin, side * .106, .069, .004, .023, .041, .031, 0, 0, 'oval');
    add(head, shade, side * .118, .071, .016, .008, .021, .012, 0, 0, 'oval');
    add(head, hair, side * .047, .123, .110, .061, .011, .012, side * -.10);
    const eyeball = groupAt(head, side < 0 ? 'Left eye' : 'Right eye', side * .046, .098, .105);
    add(eyeball, eye, 0, 0, 0, .028, .013, .015, 0, 0, 'oval');
    add(eyeball, pupil, .003, 0, .011, .012, .011, .006, 0, 0, 'oval');
    add(eyeball, eye, -.002, .003, .015, .003, .003, .002, 0, 0, 'oval');
    eyes.push(eyeball);
  }
  if (profile.style === 'swept') {
    add(head, hair, -.050, .163, .055, .088, .051, .071, .29, 0, 'oval');
    add(head, glint, -.061, .179, .097, .057, .010, .013, .28, 0, 'oval');
    add(head, hair, .087, .119, -.006, .041, .090, .067, -.12, 0, 'oval');
    add(head, brass, -.115, .031, .036, .013, .017, .008, 0, 0, 'oval');
  } else if (profile.style === 'parted') {
    add(head, hair, .036, .172, .043, .083, .038, .074, -.19, 0, 'oval');
    add(head, glint, -.017, .191, .069, .062, .009, .033, -.19, 0, 'oval');
    add(head, glint, -.083, .134, .035, .031, .039, .044, .16, 0, 'oval');
  } else if (profile.style === 'stubble') {
    add(head, hair, 0, -.027, .052, .069, .040, .060, .05, 0, 'oval');
    add(head, hair, -.08, .033, .033, .034, .037, .065, -.24, 0, 'oval');
    add(head, hair, .08, .033, .033, .034, .037, .065, .24, 0, 'oval');
    add(head, hair, 0, .034, .119, .056, .014, .012, -.06, 0, 'oval');
  } else {
    add(head, edge, 0, .186, -.013, .229, .108, .233, -.05);
    add(head, boot, 0, .160, .084, .206, .022, .145, -.04, .08);
    add(head, brass, .045, .183, .103, .058, .027, .012, -.05);
  }
  if (profile.prop === 'tablet') {
    for (const side of [-1, 1]) {
      const gx = side * .048;
      for (const y of [.078, .116]) add(head, brass, gx, y, .129, .073, .008, .009);
      for (const dx of [-.035, .035]) add(head, brass, gx + dx, .097, .129, .008, .041, .009);
      add(head, edge, side * .100, .115, .071, .010, .012, .104, 0, .16);
    }
    add(head, brass, 0, .110, .135, .030, .008, .010);
  }
  return { head, eyes };
}

function arms(trunk, profile, material, add) {
  const { coat, seam, shirt, brass, skin, shade } = material;
  return [-1, 1].map((side) => {
    const direction = side < 0 ? 'Left' : 'Right';
    const shoulder = groupAt(trunk, `${direction} shoulder`, side * .222, .520);
    const elbow = groupAt(shoulder, `${direction} elbow`, 0, -.243);
    const wrist = groupAt(elbow, `${direction} wrist`, 0, -.204, .014);
    add(shoulder, coat, 0, -.103, 0, .137, .278, .162);
    add(shoulder, seam, side * .064, -.133, 0, .012, .146, .101);
    add(elbow, coat, 0, -.084, .003, .120, .217, .142);
    add(elbow, seam, 0, -.168, .004, .121, .047, .143);
    add(elbow, shirt, 0, -.198, .009, .094, .035, .108);
    add(elbow, brass, side * .057, -.165, .041, .013, .020, .015, 0, 0, 'oval');
    add(wrist, skin, 0, -.049, 0, .073, .109, .068);
    add(wrist, shade, -side * .031, -.033, .025, .029, .063, .033, -side * .22, 0, 'oval');
    if (profile.prop === 'clipboard') add(elbow, brass, 0, -.130, .005, .124, .028, .145);
    return { shoulder, elbow, wrist };
  });
}

function heldProp(wrist, profile, material, add) {
  const prop = groupAt(wrist, 'Held prop', -.013, -.086, .049);
  const { boot, bag, brass, gold, paper, ink, screen, edge } = material;
  switch (profile.prop) {
    case 'folder':
      add(prop, bag, 0, -.032, 0, .236, .282, .030);
      add(prop, paper, .032, -.019, .018, .153, .248, .013);
      add(prop, boot, -.037, -.031, .021, .174, .278, .014);
      add(prop, brass, -.032, -.019, .032, .045, .023, .009);
      break;
    case 'tablet':
      add(prop, boot, 0, -.039, 0, .249, .290, .041);
      add(prop, screen, 0, -.034, .023, .212, .236, .009);
      for (let i = 0; i < 6; i++) {
        add(prop, ink, -.057, .049 - i * .029, .030, .067, .006, .004);
        add(prop, paper, .062, .049 - i * .029, .030, .044, .005, .003);
      }
      break;
    case 'coin':
      prop.position.set(-.013, -.064, .041);
      add(prop, gold, 0, 0, 0, .031, .013, .031, 0, Math.PI / 2, 'coin');
      add(prop, brass, 0, 0, .007, .020, .003, .020, 0, Math.PI / 2, 'coin');
      break;
    case 'clipboard':
      add(prop, bag, 0, -.042, 0, .225, .287, .024);
      add(prop, paper, 0, -.033, .014, .187, .234, .009);
      add(prop, brass, 0, .084, .027, .073, .033, .022);
      for (let i = 0; i < 5; i++) add(prop, ink, -.014, .040 - i * .031, .021, .124 - i * .009, .006, .004);
      break;
    case 'ledger':
      add(prop, edge, 0, -.042, 0, .226, .294, .041);
      add(prop, paper, .013, -.039, .015, .197, .260, .028);
      add(prop, boot, 0, -.045, .033, .221, .282, .017);
      add(prop, brass, 0, -.048, .044, .061, .071, .009, .76);
      break;
  }
  return prop;
}

// A smooth, self-contained movement in a longer acting cycle.
function beat(time, start, duration, period) {
  const progress = ((time - start) % period + period) % period / duration;
  return progress < 1 ? Math.sin(progress * Math.PI) ** 2 : 0;
}

export function createMissionContact(scene, { id, x, z, y = 0, heading = 0 }, { reducedMotion = false } = {}) {
  const profile = profiles[id];
  const material = palettes(profile);
  const group = groupAt(scene, profile.name, x, y, z);
  group.rotation.y = heading;
  group.scale.set(profile.width, profile.height, profile.width);
  const { part, finish } = joints();
  const trunk = dress(group, profile, material, part);
  const { head, eyes } = face(trunk, profile, material, part);
  const [left, right] = arms(trunk, profile, material, part);
  const prop = heldProp(left.wrist, profile, material, part);
  finish();
  let paused = Boolean(reducedMotion);

  function aim(arm, pose, loose) {
    const [pitch, roll, bend] = pose;
    arm.shoulder.rotation.set(pitch, 0, roll);
    arm.elbow.rotation.x = bend;
    arm.wrist.rotation.y = loose;
  }

  function poseAt(elapsed, still = false) {
    const { period, stagger, rest, work, gesture } = profile;
    const reading = still ? 0 : beat(elapsed + stagger, 1.35, 3.6, period);
    const signaling = still ? 0 : beat(elapsed + stagger, 5.25, 2.35, period);
    const breath = still ? 0 : Math.sin(elapsed * 1.78 + stagger);
    const lookAround = still ? 0 : Math.sin(elapsed * .73 + stagger);
    const pose = (key) => rest[key].map((value, axis) => value + (work[key][axis] - value) * reading
      + ((gesture[key]?.[axis] ?? value) - value) * signaling);
    const [pitch, yaw, tilt] = pose('head');
    trunk.position.y = .79 + .006 * breath;
    trunk.rotation.set(.014 * reading, -.087 * reading + .058 * signaling, lookAround * .019);
    head.rotation.set(pitch + breath * .025, yaw + lookAround * .13, tilt);
    aim(left, pose('left'), -.1 + .16 * reading);
    aim(right, pose('right'), .1 - .32 * signaling);
    const scan = breath * .035 + reading * .18;
    prop.rotation.set(-.65 + scan, profile.prop === 'coin' ? (still ? .24 : reading * Math.sin(elapsed * 6) * 2.6) : .15, -.09);
    const blink = still ? 0 : beat(elapsed + stagger, .4, .16, 4.7);
    for (const eye of eyes) eye.scale.y = 1 - blink * .87;
  }

  poseAt(0, paused);
  return {
    group,
    update(elapsed) {
      if (!paused) poseAt(elapsed);
    },
    setReducedMotion(enabled) {
      paused = Boolean(enabled);
      if (paused) poseAt(0, true);
    },
  };
}
