const clamp = (number) => Math.max(0, Math.min(100, number))

export function adjustMeters(state, reputation, heat) {
  state.reputation = clamp(state.reputation + reputation)
  state.heat = clamp(state.heat + heat)
}

export function bankAccess(state) {
  if (state.reputation < 56 || state.heat > 26) {
    return 'Requires at least 56 reputation and 26 heat or lower.'
  }
  return ''
}

export function privateAccess(state) {
  if (state.reputation > 52 && state.heat < 15) {
    return 'Requires 52 reputation or lower, or at least 15 heat.'
  }
  return ''
}
