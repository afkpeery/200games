import { pick, randomFor, shuffled } from './random.js'
import { adjustMeters } from './meters.js'

export const DEAL_TYPES = [
  { name: 'Seed equity', stage: 'Seed', ask: 650, equity: 20, risk: 0.18, term: 3, growth: 0.17, exit: 1.42 },
  { name: 'Convertible note', stage: 'Pre-seed', ask: 900, equity: 14, risk: 0.12, term: 4, growth: 0.15, exit: 1.31 },
  { name: 'Bridge round', stage: 'Series A', ask: 760, equity: 18, risk: 0.26, term: 2, growth: 0.2, exit: 1.57 },
  { name: 'Revenue share', stage: 'Growth', ask: 640, equity: 16, risk: 0.1, term: 3, growth: 0.11, exit: 1.26 },
  { name: 'Buyout syndicate', stage: 'Expansion', ask: 1200, equity: 24, risk: 0.28, term: 4, growth: 0.18, exit: 1.62 }
]

const INDUSTRIES = [
  { name: 'urban logistics', brands: ['Signal Freight', 'Night Relay', 'Vanta Transit', 'Third Mile'] },
  { name: 'building retrofits', brands: ['Copper Grid', 'Vault Thermal', 'Foundry Air', 'Greysill'] },
  { name: 'retail analytics', brands: ['Pulse Ledger', 'Glass Metric', 'Index North', 'Beacon Till'] },
  { name: 'water recycling', brands: ['Undertow Works', 'Aster Reclaim', 'Rain Circuit', 'Lowline Water'] },
  { name: 'battery diagnostics', brands: ['Cinder Labs', 'Rivet Cell', 'Halogen Bench', 'Ion Harbor'] },
  { name: 'insurance software', brands: ['Folio Systems', 'Fair Margin', 'Harbour Adjust', 'Sure Basin'] },
  { name: 'materials recovery', brands: ['Second Alloy', 'Meridian Scrap', 'Loop Works', 'Ever Slag'] }
]

const STARTUPS = INDUSTRIES.flatMap((industry) => industry.brands.map((name) => ({
  name,
  industry: industry.name
})))

const FOUNDER_VOICES = [
  { personality: 'pragmatist', line: 'I can show you the numbers by hand. Tell me which assumption you dislike.' },
  { personality: 'operator', line: 'We delivered a pilot last week. Give us a long enough runway and I can staff the next one.' },
  { personality: 'visionary', line: 'There is a whole market between the big contracts and the jobs nobody bids on.' },
  { personality: 'skeptic', line: 'Only take this if you understand it. I have already lost one partner to panic.' }
]

export const money = (amount) => '$' + Math.round(amount).toLocaleString('en-US')

const rounded = (amount) => Math.round(amount / 25) * 25

export function pitchFor(state) {
  const random = randomFor(state.seed, 'pitch', state.day)
  const typeShift = Math.floor(randomFor(state.seed, 'types')() * DEAL_TYPES.length)
  const type = DEAL_TYPES[(state.day - 1 + typeShift) % DEAL_TYPES.length]
  const startupDeck = shuffled(STARTUPS, randomFor(state.seed, 'startups'))
  const startup = startupDeck[state.day - 1]
  const founder = pick(FOUNDER_VOICES, random)
  const risk = type.risk + (random() - 0.5) * 0.11
  const fraud = random() < 0.15
  const firstAsk = Math.min(type.ask, 700)
  const ask = state.day === 1 ? firstAsk : rounded(type.ask * (0.94 + random() * 0.25 + state.day * 0.075))
  const revealed = state.reviewedDay === state.day

  return {
    id: 'round-' + state.day,
    name: startup.name,
    industry: startup.industry,
    stage: type.stage,
    dealType: type.name,
    ask,
    equity: type.equity,
    risk: revealed ? fraud ? 'Inconsistent records' : risk > 0.22 ? 'Elevated risk' : 'Ordinary risk' : 'Unverified',
    diligence: revealed ? fraud ? 'Revenue records do not reconcile.' : 'Primary records reconcile.' : '',
    founder,
    model: { risk, fraud, term: type.term, growth: type.growth, exit: type.exit }
  }
}

export function netWorth(state) {
  const holdings = state.portfolio.reduce((sum, company) => sum + (company.status === 'active' ? company.value : 0), 0)
  const property = state.assets.reduce((sum, asset) => sum + asset.value, 0)
  const obligations = state.debts.reduce((sum, debt) => sum + debt.balance, 0)
  return state.cash + holdings + property - obligations
}

export function dealTerms(pitch, mode) {
  if (mode === 'hard') {
    return { cost: rounded(Math.max(450, pitch.ask * 0.78)), equity: pitch.equity + 12, reputation: -5, heat: 4, route: 'Hard terms' }
  }
  if (mode === 'offbook') {
    return { cost: rounded(Math.max(400, pitch.ask * 0.65)), equity: pitch.equity + 18, reputation: -12, heat: 21, route: 'Off-book' }
  }
  return { cost: pitch.ask, equity: pitch.equity, reputation: 7, heat: 0, route: 'Fair terms' }
}

export function openInvestment(state, pitch, terms) {
  state.cash -= terms.cost
  const model = { ...pitch.model }
  const premiums = (terms.equity - pitch.equity) / 100
  model.risk += Math.max(0, premiums / 2)
  model.exit += premiums * 2.1
  state.portfolio.unshift({
    id: pitch.id,
    name: pitch.name,
    industry: pitch.industry,
    stage: pitch.stage,
    dealType: pitch.dealType,
    invested: terms.cost,
    equity: terms.equity,
    value: terms.cost,
    status: 'active',
    openedDay: state.day,
    maturityDay: state.day + model.term,
    route: terms.route,
    model
  })
  state.fundedDay = state.day
  adjustMeters(state, terms.reputation, terms.heat)
}

export function resolveInvestments(state, market, log) {
  for (const company of state.portfolio) {
    if (company.status !== 'active') continue
    const random = randomFor(state.seed, 'round-outcome', company.id, state.day)
    const fluctuation = (random() - 0.42) * 0.22
    // Revalue the stake before resolving any exit at this close.
    company.value = Math.round(company.value * Math.max(0.35, 1 + company.model.growth + fluctuation + market.growth))
    if (company.maturityDay > state.day) {
      log(company.name + ' marked to market', money(company.value) + ' estimated stake value.', 'market')
      continue
    }
    const enforcement = company.model.fraud && market.id === 'audit' ? 0.38 : 0
    const risk = company.model.risk + (company.model.fraud ? 0.15 : 0) + market.risk + enforcement
    if (random() < risk) {
      company.status = 'failed'
      company.value = 0
      company.closedDay = state.day
      log(company.name + ' failed', company.model.fraud ? 'The board discovered inconsistent accounts. Your stake was written down.' : 'The company exhausted its runway. Your stake was written down.', 'loss')
      continue
    }
    const payout = Math.round(company.value * company.model.exit * market.exit)
    state.cash += payout
    company.status = 'exited'
    company.value = payout
    company.closedDay = state.day
    company.payout = payout
    const exitStyle = market.id === 'ipo' || random() > 0.76 ? ' listed' : ' was acquired'
    log(company.name + exitStyle, money(payout) + ' credited to your account.', 'exit')
  }
}

export function settleDebts(state, log) {
  for (const debt of state.debts) {
    if (debt.dueDay > state.day) continue
    if (state.cash >= debt.balance) {
      state.cash -= debt.balance
      log(debt.lender + ' loan settled', money(debt.balance) + ' paid from your cash.', 'credit')
      debt.balance = 0
      continue
    }
    const lateFee = Math.round(debt.balance * debt.lateRate)
    debt.balance += lateFee
    debt.dueDay += 1
    adjustMeters(state, debt.id === 'private' ? -3 : -7, debt.id === 'private' ? 8 : 2)
    log(debt.lender + ' loan overdue', money(lateFee) + ' fee applied. Next payment due Day ' + debt.dueDay + '.', 'loss')
  }
  state.debts = state.debts.filter((debt) => debt.balance > 0)
}
