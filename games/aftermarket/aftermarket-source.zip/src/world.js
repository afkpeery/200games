import * as THREE from 'three';
import {
  canvasTexture, glowTexture, posterTexture, reflectionTexture,
  seeded, signTexture, surfaceBumpTexture, surfaceTexture, windowTexture
} from './world-textures.js';
import { addAmbient } from './world-ambient.js';
import { addCityExpansion } from './world-expansion.js';
import {
  CITY_BOUNDS, CITY_CONNECTORS, CITY_CORE_BLOCKS, CITY_ENTRANCES,
  CITY_TOWERS, CITY_VENUES
} from './district.js';

const quarterTurn = Math.PI / 2;
const landmarkDefinitions = Object.values(CITY_ENTRANCES);

export function createWorld(scene, {
  surfaceMaps = {},
  reducedMotion = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false
} = {}) {
  const random = seeded(50731);
  const collisions = [];
  const batches = new Map();
  const glows = new Map();
  const loadedTextures = new THREE.TextureLoader();
  const object = new THREE.Object3D();
  const groundPlane = new THREE.PlaneGeometry(1, 1);
  const cube = new THREE.BoxGeometry(1, 1, 1);
  const roundGlow = glowTexture();
  const roadGlow = reflectionTexture();

  const solid = (color, roughness = 0.75, metalness = 0.02) =>
    new THREE.MeshStandardMaterial({ color, roughness, metalness });
  const luminous = (color, intensity = 0.75) =>
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: 0.32 });
  const surface = (name, repeatX, repeatY, options, bumpScale = 0.022) => {
    let map;
    if (surfaceMaps[name]) {
      map = loadedTextures.load(surfaceMaps[name]);
      map.colorSpace = THREE.SRGBColorSpace;
      map.wrapS = map.wrapT = THREE.RepeatWrapping;
      map.repeat.set(repeatX, repeatY);
      map.anisotropy = 8;
    } else {
      map = surfaceTexture(name, repeatX, repeatY);
    }
    const bumpMap = surfaceMaps[name] || !bumpScale ? null : surfaceBumpTexture(name, repeatX, repeatY);
    return new THREE.MeshStandardMaterial({ map, bumpMap, bumpScale, ...options });
  };

  const asphalt = surface('street', 3, 17, { roughness: 0.3, metalness: 0.27 });
  const paving = surface('concrete', 1, 13, { roughness: 0.55, metalness: 0.09 });
  const darkTile = surface('tile', 3, 2, { roughness: 0.63, metalness: 0.03 });
  const darkBrick = surface('plaster', 3, 2, { roughness: 0.79 });
  const stone = solid(0x566660);
  const grit = solid(0x3c3b32);
  const concrete = solid(0x727771);
  const edge = solid(0x192322, 0.56, 0.21);
  const metal = solid(0x253330, 0.38, 0.53);
  const blackMetal = solid(0x0f1c20, 0.35, 0.46);
  const brass = solid(0x8c7553, 0.36, 0.53);
  const pipe = solid(0x4d4f3e, 0.59, 0.34);
  const slate = solid(0x24322f, 0.45, 0.55);
  const warmPanel = luminous(0xe3a569, 0.58);
  const coldPanel = luminous(0x8fcfb4, 0.54);
  const redPanel = luminous(0xde6551, 1.4);
  const amberTube = luminous(0xffba6a, 3.15);
  const whiteTube = luminous(0xb4eadb, 1.85);
  const headLight = luminous(0xffdd96, 2.6);
  const shrubGeometry = new THREE.IcosahedronGeometry(1, 0);
  const shrubs = [solid(0x304941, 0.83), solid(0x3c5144, 0.92), solid(0x445848, 0.83)]
    .map(material => ({ material, instances: [] }));

  function box(x, y, z, width, height, depth, material, rotation = 0) {
    if (!batches.has(material)) batches.set(material, []);
    batches.get(material).push([x, y, z, width, height, depth, rotation]);
  }

  function obstruction(x, z, width, depth) {
    collisions.push([x - width / 2, x + width / 2, z - depth / 2, z + depth / 2]);
  }

  function barrier(x, y, z, width, height, depth, material) {
    box(x, y, z, width, height, depth, material);
    obstruction(x, z, width, depth);
  }

  function floor(x, z, width, depth, material, height = 0) {
    const mesh = new THREE.Mesh(groundPlane, material);
    mesh.rotation.x = -quarterTurn;
    mesh.scale.set(width, depth, 1);
    mesh.position.set(x, height, z);
    scene.add(mesh);
    return mesh;
  }

  function floorHaze(x, z, width, depth, color, opacity, height = 0.018) {
    return floor(x, z, width, depth, new THREE.MeshBasicMaterial({
      map: roadGlow, color, opacity, transparent: true, depthWrite: false,
      blending: THREE.AdditiveBlending, polygonOffset: true,
      polygonOffsetFactor: -1, polygonOffsetUnits: -1, toneMapped: false
    }), height);
  }

  function light(x, y, z, color, intensity, distance) {
    const point = new THREE.PointLight(color, intensity, distance, 2);
    point.position.set(x, y, z);
    scene.add(point);
    return point;
  }

  function glow(x, y, z, size, color, opacity) {
    const key = `${color}/${opacity}`;
    if (!glows.has(key)) {
      glows.set(key, new THREE.SpriteMaterial({
        map: roundGlow, color, opacity, transparent: true, blending: THREE.AdditiveBlending,
        depthWrite: false, toneMapped: false
      }));
    }
    const sprite = new THREE.Sprite(glows.get(key));
    sprite.position.set(x, y, z);
    sprite.scale.set(size, size, 1);
    scene.add(sprite);
  }

  function tubeBetween(x1, y1, z1, x2, y2, z2, radius, material) {
    const a = new THREE.Vector3(x1, y1, z1);
    const b = new THREE.Vector3(x2, y2, z2);
    const delta = b.sub(a);
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, delta.length(), 6), material);
    mesh.position.copy(a.addScaledVector(delta, 0.5));
    mesh.quaternion.setFromUnitVectors(THREE.Object3D.DEFAULT_UP, delta.normalize());
    scene.add(mesh);
  }

  const sunlight = new THREE.DirectionalLight(0xb5d4d9, 1.55);
  sunlight.position.set(1, 7, 4);
  scene.add(sunlight, new THREE.HemisphereLight(0xa7c1ca, 0x534739, 2.25));
  scene.fog = new THREE.FogExp2(0x26393c, 0.020);
  const sky = new THREE.Mesh(new THREE.SphereGeometry(102, 24, 12), new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false,
    uniforms: {
      lowColor: { value: new THREE.Color(0x6f6657) },
      horizon: { value: new THREE.Color(0x536e73) },
      highColor: { value: new THREE.Color(0x172b39) }
    },
    vertexShader: `
      varying vec3 vDirection;
      void main() {
        vDirection = position;
        gl_Position = projectionMatrix * vec4(mat3(viewMatrix) * position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 lowColor;
      uniform vec3 horizon;
      uniform vec3 highColor;
      varying vec3 vDirection;
      void main() {
        vec3 direction = normalize(vDirection);
        float height = direction.y;
        vec3 shade = mix(lowColor, horizon, smoothstep(-.12, .15, height));
        shade = mix(shade, highColor, smoothstep(.07, .69, height));
        float clouds = sin(direction.z * 22. + direction.x * 14. + height * 32.)
          * sin(direction.x * 39. - height * 9.);
        shade += .026 * clouds * smoothstep(0., .16, height) * (1. - smoothstep(.22, .54, height));
        gl_FragColor = vec4(shade, 1.);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `
  }));
  sky.frustumCulled = false;
  sky.renderOrder = -50;
  scene.add(sky);

  const citySubstrate = surface('aggregate', 60, 94, { color: 0x62685c, roughness: 0.87 }, 0);
  floor(0, -16, 125, 182, citySubstrate, -0.06);
  floor(0, -12.5, 9.6, 73, asphalt);
  for (const side of [-1, 1]) {
    floor(side * 7.3, -15, 5.6, 78, paving, 0.095);
    box(side * 4.78, 0.046, -15, 0.14, 0.1, 78, concrete);
    box(side * 4.5, 0.004, -15, 0.28, 0.012, 78, edge);

    for (let z = -45; z <= 20; z += 2.5) {
      box(side * 4.87, 0.102, z, 0.17, 0.009, 0.025, edge);
      if (z % 5 === 0) {
        box(side * 4.46, 0.014, z, 0.3, 0.018, 0.65, metal);
        for (let i = 0; i < 7; i++) {
          box(side * 4.46, 0.024, z - 0.26 + i * 0.085, 0.24, 0.009, 0.023, blackMetal);
        }
      }
    }
  }

  const trafficPaint = new THREE.MeshStandardMaterial({
    color: 0x9c8b62, roughness: 0.82, transparent: true, opacity: 0.76,
    alphaMap: canvasTexture(128, 128, (ctx, w, h) => {
      ctx.fillStyle = '#dddddd';
      ctx.fillRect(0, 0, w, h);
      const wear = seeded(938);
      for (let i = 0; i < 660; i++) {
        ctx.fillStyle = wear() > 0.5 ? '#111111' : '#777777';
        ctx.fillRect(wear() * w, wear() * h, 0.5 + wear() * 5, 1 + wear() * 3);
      }
    })
  });

  const stripePositions = [];
  for (let z = -45; z < 23; z += 4.2) {
    stripePositions.push([-0.09, z, 0.085, 2.2, 0.006], [0.09, z, 0.085, 2.2, 0.006]);
  }
  for (const z of [6.9, -14.4, -31.5]) {
    for (let i = -4; i <= 4; i++) {
      stripePositions.push([i * 0.93, z, 0.43, 2.02, 0.007]);
    }
    stripePositions.push(
      [2.35, z - 1.78, 4.15, 0.15, 0.007],
      [-2.35, z + 1.78, 4.15, 0.15, 0.007]
    );
  }
  const stripes = new THREE.InstancedMesh(groundPlane, trafficPaint, stripePositions.length);
  object.rotation.x = -quarterTurn;
  for (const [i, [x, z, width, depth, height]] of stripePositions.entries()) {
    object.position.set(x, height, z);
    object.scale.set(width, depth, 1);
    object.updateMatrix();
    stripes.setMatrixAt(i, object.matrix);
  }
  stripes.computeBoundingSphere();
  scene.add(stripes);

  for (let i = 0; i < 38; i++) {
    const x = (random() - 0.5) * 8.7;
    const z = -44 + random() * 66;
    floor(x, z, 0.25 + random() * 1.4, 0.8 + random() * 5,
      new THREE.MeshBasicMaterial({
        color: 0x141a1d, opacity: 0.12 + random() * 0.15,
        transparent: true, alphaMap: roundGlow, depthWrite: false
      }), 0.008);
  }
  for (const puddle of [
    [-2.5, 3.5, 3.8, 12.8, 0xe7a061, 0.55], [-0.7, -14.0, 3.3, 14.5, 0xc98b58, 0.55],
    [2.4, -2.8, 3.4, 17.2, 0x71baa4, 0.58], [3.0, 8.0, 3.3, 13.6, 0x87cdb3, 0.32],
    [-4.0, -20.3, 2.8, 14.3, 0xf2735c, 0.58], [2.3, -25.2, 4.5, 11.2, 0x61a9ae, 0.44],
    [-0.7, -34.3, 10, 11.3, 0xd0986e, 0.31], [-4.0, 12, 3.0, 13.5, 0x719f8c, 0.30]
  ]) floorHaze(...puddle);

  const warmSign = { text: '#f3bf87', aux: '#d1a174', trim: '#9c775b', panel: '#38261f' };
  const cleanSign = { text: '#b5f2d6', aux: '#79b8a4', trim: '#5b9986', panel: '#183832' };
  const redSign = { text: '#ffa094', aux: '#de8973', trim: '#8f5851', panel: '#432a2c' };
  const neutralSign = { text: '#e0e4c9', aux: '#b0c1aa', trim: '#76968b', panel: '#273b38' };

  function sign(x, y, z, width, height, title, subtitle, colors, rotation = 0, vertical = false) {
    const texture = signTexture(title, subtitle, colors, vertical ? 'vertical' : 'wide');
    box(x, y, z, width + 0.12, height + 0.12, 0.16, blackMetal, rotation);
    const mesh = new THREE.Mesh(groundPlane, new THREE.MeshBasicMaterial({ map: texture, toneMapped: false }));
    mesh.position.set(x + Math.sin(rotation) * 0.09, y, z + Math.cos(rotation) * 0.09);
    mesh.rotation.y = rotation;
    mesh.scale.set(width, height, 1);
    scene.add(mesh);
  }

  function poster(x, y, z, words, paper, ink, rotation) {
    const m = new THREE.Mesh(groundPlane, new THREE.MeshBasicMaterial({
      map: posterTexture(words, paper, ink), toneMapped: false
    }));
    m.position.set(x, y, z);
    m.rotation.y = rotation;
    m.scale.set(0.56, 0.82, 1);
    scene.add(m);
  }

  function storefrontGlass(role, variant) {
    const texture = windowTexture(role, variant);
    return new THREE.MeshStandardMaterial({
      color: 0xb6b3a9, map: texture,
      emissiveMap: texture, emissive: 0xffffff, emissiveIntensity: 0.36,
      roughness: 0.24, metalness: 0.28
    });
  }
  const glassWarm = [0, 1, 2].map(i => storefrontGlass('foundry', i));
  const glassCold = [0, 1, 2].map(i => storefrontGlass('bank', i));
  const upperWindow = [
    solid(0x1c2e34, 0.24, 0.43), solid(0x304649, 0.26, 0.47),
    luminous(0x917456, 0.23), luminous(0x768571, 0.19), solid(0x243639, 0.18, 0.47)
  ];

  function commercialBlock(side, z, width, height, role) {
    const face = side * 8.96;
    const near = side * 8.82;
    const depth = 7.9;
    const base = role === 'bank' ? darkTile : darkBrick;
    const casing = role === 'bank' ? stone : grit;
    const windowGlass = role === 'bank' ? glassCold : glassWarm;
    const interior = role === 'bank' ? coldPanel : warmPanel;
    obstruction(side * (9.05 + depth / 2), z, depth, width);

    box(side * (9.05 + depth / 2), height / 2, z, depth, height, width, base);
    box(side * 9.13, 0.4, z, 0.56, 0.62, width + 0.1, casing);
    box(side * 9.12, 3.7, z, 1.14, 0.24, width + 0.38, casing);
    box(side * 9.14, 3.86, z, 1.21, 0.08, width + 0.6, brass);
    box(side * 9.14, 6.0, z, 0.96, 0.21, width + 0.13, casing);
    box(side * 9.15, height - 0.21, z, 1.15, 0.39, width + 0.57, casing);
    box(side * (9.05 + depth / 2), height + 0.05, z, depth + 0.31, 0.17, width + 0.35, blackMetal);

    const bays = Math.floor(width / 2.33);
    const pitch = width / bays;
    for (let i = 0; i <= bays; i++) {
      const rowZ = z - width / 2 + i * pitch;
      box(near, 2.05, rowZ, 0.47, 3.0, role === 'bank' ? 0.33 : 0.24, casing);
      box(near - side * 0.06, 0.45, rowZ, 0.61, 0.44, 0.48, casing);
      box(near - side * 0.08, 3.39, rowZ, 0.58, 0.18, 0.50, casing);
      if (i === bays) continue;
      const bayZ = rowZ + pitch / 2;
      const bayWidth = pitch - 0.41;
      box(face, 2.08, bayZ, 0.12, 2.68, bayWidth, edge);
      box(face - side * 0.07, 2.06, bayZ, 0.045, 2.48, bayWidth - 0.15,
        windowGlass[i % windowGlass.length]);
      box(face - side * 0.095, 3.10, bayZ, 0.024, 0.12, bayWidth - 0.29, interior);
      box(face - side * 0.10, 2.45, bayZ, 0.032, 0.055, bayWidth, brass);
      box(face - side * 0.11, 1.22, bayZ, 0.039, 0.068, bayWidth, metal);
      box(face - side * 0.12, 2.0, bayZ, 0.04, 2.58, 0.067, metal);
      box(face - side * 0.13, 0.9, bayZ + (i % 2 ? 0.45 : -0.42), 0.033, 0.49, 0.63, edge);
      if (i % 3 === 0) box(face - side * 0.15, 2.12, bayZ - 0.31, 0.013, 0.49, 0.25, interior);

      for (let y = 4.8; y < height - 1; y += 2.8) {
        box(face, y, bayZ, 0.12, 1.83, bayWidth * 0.69, edge);
        box(face - side * 0.07, y, bayZ, 0.044, 1.66, bayWidth * 0.61,
          upperWindow[Math.floor(random() * upperWindow.length)]);
        box(face - side * 0.09, y + 0.4, bayZ, 0.05, 0.05, bayWidth * 0.62, casing);
        box(face - side * 0.11, y, bayZ, 0.04, 1.72, 0.048, casing);
        box(face - side * 0.14, y - 0.94, bayZ, 0.24, 0.15, bayWidth * 0.76, casing);
      }
    }

    for (let y = 4.65; y < height - 1; y += 2.8) {
      for (let i = 0; i < 3; i++) {
        const x = side * (10.4 + i * 2.2);
        const capZ = z + width / 2 + 0.02;
        box(x, y, capZ, 1.47, 1.82, 0.09, edge);
        box(x, y, capZ + 0.055, 1.33, 1.63, 0.015,
          upperWindow[Math.floor(random() * upperWindow.length)]);
        box(x, y, capZ + 0.073, 0.065, 1.63, 0.026, casing);
        box(x, y - 0.89, capZ + 0.10, 1.72, 0.12, 0.26, casing);
      }
    }
  }

  for (const block of CITY_CORE_BLOCKS) commercialBlock(...block);

  function canopy(side, z, width, color) {
    box(side * 7.75, 3.37, z, 2.50, 0.22, width, metal);
    box(side * 6.50, 3.36, z, 0.09, 0.24, width + 0.22, brass);
    for (let i = -1; i <= 1; i++) {
      const q = z + i * width * 0.31;
      box(side * 7.54, 3.22, q, 1.5, 0.036, 0.055, color);
      tubeBetween(side * 6.7, 3.5, q, side * 8.84, 4.35, q, 0.029, metal);
    }
  }

  canopy(-1, -0.6, 5.4, amberTube);
  canopy(1, -5.6, 6.9, whiteTube);
  canopy(-1, -23.8, 4.0, redPanel);
  sign(-6.9, 4.13, 2.03, 2.54, 0.59, 'FOUNDRY', 'INCUBATOR', warmSign);
  sign(7.87, 4.24, -2.05, 2.93, 0.63, 'MERIDIAN', 'CLIENTS AT EAST ANNEX', cleanSign);
  sign(-7.92, 3.97, -21.69, 2.36, 0.60, 'NIGHT WINDOW', 'MOVED TO NORTH SERVICE', redSign);
  sign(-8.72, 6.7, 4.7, 0.90, 4.59, 'FOUNDRY', '', warmSign, 0, true);
  sign(8.75, 7.05, 2.17, 1.02, 5.1, 'MERIDIAN', '', cleanSign, 0, true);
  sign(-8.78, 2.55, -2.67, 3.13, 0.52, 'FOUNDRY', '', warmSign, quarterTurn);
  sign(8.77, 2.55, -8.87, 2.9, 0.49, 'MERIDIAN', '', cleanSign, -quarterTurn);
  sign(-8.77, 2.45, -25.7, 2.33, 0.43, 'CASH ONLY', '', redSign, quarterTurn);

  light(-6.7, 3.10, -0.3, 0xffae69, 26, 11);
  light(6.7, 3.10, -5.6, 0x8af0cb, 30, 12);
  const alleyLight = light(-6.8, 3.05, -23.8, 0xff6353, 21, 10);
  floorHaze(-7.0, 0.2, 5.9, 8.8, 0xe5a45e, 0.53, 0.104);
  floorHaze(7.0, -5.0, 5.7, 9.3, 0x73ccaf, 0.52, 0.104);
  floorHaze(-6.8, -23.4, 4.1, 7.6, 0xdb654b, 0.72, 0.104);
  glow(-7.3, 3.34, -0.3, 2.1, 0xffbc7a, 0.26);
  glow(7.6, 3.38, -5.1, 2.15, 0x94f4ce, 0.30);
  glow(-7.0, 3.44, -23.0, 2.05, 0xff7c5c, 0.29);

  const foundryZ = CITY_ENTRANCES['foundry-entry'].z;
  box(-8.73, 1.57, foundryZ, 0.17, 2.91, 2.14, blackMetal);
  box(-8.61, 1.57, foundryZ, 0.09, 2.74, 1.90, glassWarm[1]);
  box(-8.54, 1.57, foundryZ, 0.08, 2.83, 0.065, brass);
  box(-8.51, 2.94, foundryZ, 0.065, 0.045, 1.90, amberTube);
  for (const z of [foundryZ - 0.25, foundryZ + 0.25]) box(-8.52, 1.35, z, 0.056, 0.35, 0.048, brass);
  sign(-8.47, 3.06, foundryZ, 1.19, 0.21, 'PUBLIC ENTRANCE', '', warmSign, quarterTurn);

  function serviceBackdrops() {
    poster(-8.69, 1.55, -17.6, ['AFTER', 'HOURS'], '#a78863', '#263731', quarterTurn);
    poster(-8.71, 1.49, -18.46, ['CLEAR', 'THE', 'BOOKS'], '#bac5a6', '#303b34', quarterTurn);
    poster(-8.7, 1.54, 3.83, ['NEXT', 'ROUND'], '#a7bdab', '#384944', quarterTurn);
    poster(8.72, 1.62, -12.18, ['KEEP', 'THE', 'CHANGE'], '#b7976d', '#302f29', -quarterTurn);

    for (const z of [-17.7, -22.35, -26.7, -27.3, 2.92]) {
      const y = z < -18 ? 1.95 : 1.5;
      box(-8.75, y, z, 0.22, 2.6, 0.072, pipe);
      box(-8.73, y - 0.82, z, 0.28, 0.12, 0.16, metal);
    }

    for (const z of [-18.2, -20.1, -27.5, 12.0]) {
      barrier(-8.05, 0.51, z, 0.78, 0.85, 1.08, slate);
      box(-8.05, 0.99, z, 0.92, 0.089, 1.17, edge);
      box(-7.61, 0.62, z, 0.026, 0.27, 0.61, metal);
      box(-7.59, 0.67, z, 0.019, 0.037, 0.34, brass);
    }
  }

  function lamp(side, z, color, lampMat) {
    const x = side * 5.17;
    barrier(x, 0.23, z, 0.35, 0.45, 0.36, metal);
    tubeBetween(x, 0.3, z, x, 5.63, z, 0.055, metal);
    tubeBetween(x, 5.63, z, x - side * 0.9, 5.72, z, 0.051, metal);
    box(x - side * 0.98, 5.68, z, 0.35, 0.12, 0.54, edge);
    box(x - side * 0.98, 5.60, z, 0.27, 0.035, 0.36, lampMat);
    light(x - side * 0.95, 5.46, z, color, 32, 13.5);
    glow(x - side * 0.98, 5.54, z + 0.055, 2.22, color, 0.24);
    floorHaze(x - side * 1.36, z + 0.4, 4.0, 11.5, color, 0.37);
  }

  lamp(-1, 5.4, 0xffb97a, amberTube);
  lamp(1, 0.0, 0xa8daca, whiteTube);
  lamp(-1, -11.5, 0xffba77, amberTube);
  lamp(1, -16.5, 0x9edcca, whiteTube);
  lamp(1, -30.5, 0xe1a571, amberTube);

  function planter(x, z, width, depth) {
    barrier(x, 0.30, z, width, 0.43, depth, concrete);
    box(x, 0.54, z, width * 1.04, 0.12, depth * 1.05, stone);
    box(x, 0.61, z, width * 0.89, 0.027, depth * 0.83, grit);
    for (let i = 0; i < 8; i++) {
      const px = x + (random() - 0.5) * width * 0.48;
      const py = 0.61 + random() * 0.27;
      const pz = z + (random() - 0.5) * depth * 0.64;
      const size = 0.17 + random() * 0.17;
      shrubs[i % shrubs.length].instances.push([px, py, pz, size, random() * 6.28]);
    }
  }

  planter(-7.46, 3.15, 0.77, 1.81);
  planter(7.63, -2.67, 0.87, 1.62);
  planter(7.60, -9.08, 0.87, 1.61);
  planter(-7.60, -9.85, 0.90, 1.98);
  planter(7.60, 9.6, 0.90, 1.91);
  serviceBackdrops();

  const benchWood = solid(0x725c44, 0.66);
  function bench(x, z) {
    obstruction(x, z, 0.53, 1.56);
    for (let i = 0; i < 5; i++) box(x - 0.21 + i * 0.11, 0.55, z, 0.084, 0.06, 1.58, benchWood);
    for (let i = 0; i < 3; i++) box(x + 0.24, 0.76 + i * 0.10, z, 0.055, 0.073, 1.57, benchWood);
    for (const offset of [-0.54, 0.55]) {
      box(x, 0.41, z + offset, 0.50, 0.26, 0.12, metal);
      box(x + 0.25, 0.74, z + offset, 0.046, 0.42, 0.045, metal);
    }
  }
  bench(7.55, 1.55);
  bench(7.34, -14.45);

  for (const [side, z] of [[-1, 7.9], [1, 6.15], [-1, -15.3], [1, -13.55], [1, -33.4]]) {
    for (let i = 0; i < 3; i++) {
      const x = side * (4.93 + i * 0.44);
      barrier(x, 0.375, z, 0.115, 0.56, 0.115, metal);
      box(x, 0.58, z, 0.132, 0.069, 0.131, brass);
    }
  }

  function profileShell(x, z, facing, rings, material) {
    const vertices = [];
    const indices = [];
    for (const [width, depth, y, offset] of rings) {
      const bevel = 0.13;
      const ring = [
        [-width + bevel, -depth], [width - bevel, -depth],
        [width, -depth + bevel], [width, depth - bevel],
        [width - bevel, depth], [-width + bevel, depth],
        [-width, depth - bevel], [-width, -depth + bevel]
      ];
      for (const [px, pz] of ring) vertices.push(x + px * facing, y, z + (pz + offset) * facing);
    }
    for (let level = 0; level < rings.length - 1; level++) {
      for (let i = 0; i < 8; i++) {
        const first = level * 8 + i;
        const second = level * 8 + (i + 1) % 8;
        indices.push(first, first + 8, second, second, first + 8, second + 8);
      }
    }
    const top = (rings.length - 1) * 8;
    for (let i = 1; i < 7; i++) indices.push(top, top + i + 1, top + i);
    const indexedGeometry = new THREE.BufferGeometry();
    indexedGeometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    indexedGeometry.setIndex(indices);
    const geometry = indexedGeometry.toNonIndexed();
    geometry.computeVertexNormals();
    indexedGeometry.dispose();
    scene.add(new THREE.Mesh(geometry, material));
  }

  function car(x, z, bodyMat, facing = 1) {
    const glass = solid(0x263d44, 0.18, 0.67);
    const rubber = solid(0x131d1d, 0.9);
    obstruction(x, z, 1.66, 3.77);
    profileShell(x, z, facing, [
      [0.72, 1.64, 0.29, 0], [0.81, 1.76, 0.48, 0],
      [0.83, 1.79, 0.60, 0], [0.76, 1.67, 0.79, 0]
    ], bodyMat);
    profileShell(x, z, facing, [[0.715, 1.085, 0.78, 0.02], [0.58, 0.68, 1.22, -0.11]], glass);
    profileShell(x, z, facing, [[0.59, 0.69, 1.219, -0.11], [0.55, 0.64, 1.285, -0.115]], bodyMat);
    box(x, 0.50, z + 1.76 * facing, 1.30, 0.11, 0.12, metal);
    box(x, 0.50, z - 1.75 * facing, 1.31, 0.09, 0.13, metal);
    box(x, 0.65, z + 1.765 * facing, 0.22, 0.11, 0.024, brass);
    box(x, 0.61, z - 1.78 * facing, 0.47, 0.12, 0.041, blackMetal);
    for (const side of [-1, 1]) {
      box(x + side * 0.51, 0.655, z + 1.767 * facing, 0.29, 0.084, 0.03, redPanel);
      box(x + side * 0.51, 0.65, z - 1.771 * facing, 0.29, 0.084, 0.03, headLight);
      box(x + side * 0.65, 1.01, z - 0.2 * facing, 0.03, 0.43, 0.077, bodyMat);
      box(x + side * 0.795, 0.70, z + 0.2 * facing, 0.024, 0.032, 0.16, brass);
      box(x + side * 0.795, 0.70, z - 0.67 * facing, 0.024, 0.032, 0.16, brass);
      box(x + side * 0.78, 0.88, z - 0.58 * facing, 0.18, 0.075, 0.15, bodyMat);
      for (const off of [-1.13, 1.13]) {
        tubeBetween(x + side * 0.72, 0.27, z + off, x + side * 0.84, 0.27, z + off, 0.28, rubber);
        tubeBetween(x + side * 0.84, 0.27, z + off, x + side * 0.855, 0.27, z + off, 0.14, metal);
        tubeBetween(x + side * 0.855, 0.27, z + off, x + side * 0.86, 0.27, z + off, 0.052, brass);
      }
    }
    glow(x - 0.5, 0.62, z + 1.79 * facing, 0.8, 0xde493c, 0.38);
    glow(x + 0.5, 0.62, z + 1.79 * facing, 0.8, 0xde493c, 0.38);
    floorHaze(x, z + 2 * facing, 2.6, 3.15, 0xe45444, 0.38);
  }

  car(3.74, -8.6, solid(0x344747, 0.37, 0.66), 1);
  car(-3.55, -9.65, solid(0x4f4d41, 0.34, 0.58), -1);
  car(3.77, -25.6, solid(0x55423b, 0.40, 0.54), 1);

  // The rail bridge gives the street a visible mid-distance landmark.
  box(0, 6.45, -19.18, 19.0, 0.39, 2.75, edge);
  box(0, 6.70, -18.87, 18.9, 0.049, 0.070, metal);
  box(0, 6.70, -19.92, 18.9, 0.049, 0.070, metal);
  box(0, 6.31, -17.82, 18.6, 0.17, 0.27, brass);
  box(0, 7.62, -17.93, 18.2, 0.13, 0.17, metal);
  box(0, 7.62, -20.48, 18.2, 0.13, 0.17, metal);
  for (let x = -8.6; x <= 8.6; x += 0.57) {
    box(x, 7.02, -17.91, 0.047, 1.13, 0.055, metal);
    box(x, 7.02, -20.46, 0.047, 1.13, 0.055, metal);
  }
  for (const side of [-1, 1]) {
    barrier(side * 8.0, 3.17, -19.18, 0.43, 6.15, 0.65, metal);
    tubeBetween(side * 8.0, 4.55, -18.2, side * 6.3, 6.35, -18.2, 0.087, metal);
    for (let i = 0; i < 2; i++) box(side * (4.8 + i * 1.55), 6.11, -18.4, 0.78, 0.05, 0.17, amberTube);
  }
  sign(0, 7.14, -17.70, 4.3, 0.88, 'EXCHANGE AVE', 'EXCHANGE DISTRICT  •  EASTBOUND', neutralSign);
  light(0, 5.5, -18.2, 0xe9a66c, 25, 16);
  floorHaze(0, -17.4, 8.6, 11, 0xd48c5e, 0.30);

  function cable(points, diameter) {
    const curve = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)));
    const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, 12, diameter, 5), blackMetal);
    scene.add(mesh);
  }
  cable([[-9.02, 10.1, 3.1], [-3.3, 8.7, 2.2], [3.4, 8.55, 0.9], [9.04, 9.6, -0.5]], 0.025);
  cable([[-9.02, 11.3, -4.0], [-3.0, 9.7, -4.8], [3.2, 9.4, -5.1], [9.04, 10.7, -5.8]], 0.021);
  cable([[-9.02, 7.95, -24.0], [0, 6.85, -25.1], [9.04, 7.9, -25.6]], 0.023);

  const windowsAtDistance = [
    solid(0x2e403f), solid(0x354848), solid(0x566154), luminous(0xa18a65, 0.44),
    luminous(0x879d88, 0.25), solid(0x415250), solid(0x26373c)
  ];
  const towerMaterials = [solid(0x394d4e), solid(0x465c58), solid(0x536264), solid(0x424e4e)];

  function tower(x, z, width, depth, height, index) {
    const base = towerMaterials[index % towerMaterials.length];
    const cap = z + depth / 2;
    obstruction(x, z, width, depth);
    box(x, height / 2 - 0.15, z, width, height, depth, base);
    box(x, height + 0.09, z, width + 0.55, 0.35, depth + 0.42, edge);
    box(x, height + 0.72, z, width * 0.65, 0.96, depth * 0.64, base);

    const columns = Math.floor(width / 1.6);
    const bay = width / (columns + 0.3);
    for (let i = 0; i < columns; i++) {
      const colX = x - width / 2 + bay * (i + 0.68);
      for (let y = 2.8; y < height - 0.62; y += 2.0) {
        const material = windowsAtDistance[Math.floor(random() * windowsAtDistance.length)];
        box(colX, y, cap + 0.025, bay * 0.62, 0.98, 0.05, material);
      }
      box(colX - bay * 0.44, height / 2, cap + 0.08, 0.12, height, 0.16, base);
    }

    if (index % 2 === 0) {
      tubeBetween(x, height + 0.5, z, x, height + 3.7, z, 0.055, edge);
      box(x, height + 3.59, z, 0.15, 0.13, 0.15, redPanel);
      glow(x, height + 3.62, z + 0.1, 0.88, 0xf36650, 0.27);
    }
  }

  for (const skyline of CITY_TOWERS) tower(...skyline);

  barrier(0, 2.1, -43.5, 19.5, 4.2, 4.3, darkTile);
  box(0, 4.35, -43.52, 20.1, 0.31, 4.65, metal);
  box(0, 3.54, -41.22, 14.7, 0.16, 0.15, brass);
  box(-6.5, 1.69, -41.23, 3.49, 2.73, 0.08, glassWarm[0]);
  box(6.5, 1.69, -41.23, 3.49, 2.73, 0.08, glassWarm[0]);
  box(0, 1.57, -41.19, 3.9, 2.95, 0.121, glassCold[1]);
  sign(0.0, 4.98, -41.21, 7.24, 1.34, 'THE EXCHANGE', 'CAPITAL MARKETS  •  EST. 1929', warmSign);
  box(0, 1.65, -41.11, 0.075, 2.92, 0.08, brass);
  for (const side of [-1, 1]) box(side * 0.29, 1.32, -41.09, 0.07, 0.44, 0.08, brass);
  sign(0, 3.16, -41.07, 2.16, 0.34, 'MAIN FOYER', 'PUBLIC ENTRANCE', warmSign);
  light(0, 3.5, -40.5, 0xfabc79, 38, 16);
  glow(0, 4.9, -41.02, 6.4, 0xe6a267, 0.17);

  const alleyPaving = surface('alley', 2, 19, { roughness: 0.45, metalness: 0.18 });
  const laneMark = solid(0x756953, 0.82);

  for (const [x, z, width, depth] of CITY_CONNECTORS) {
    if (depth > width) {
      floor(x, z, width + 0.55, depth, paving, 0.019);
      floor(x, z, width, depth, alleyPaving, 0.025);
      for (const side of [-1, 1]) box(x + side * width / 2, 0.044, z, 0.13, 0.10, depth, stone);
      continue;
    }
    for (const side of [-1, 1]) {
      const extent = width / 2;
      const end = 4.8;
      floor(side * (extent + end) / 2, z, extent - end, depth, alleyPaving, 0.027);
      for (const edgeZ of [-1, 1]) {
        box(side * (extent + end) / 2, 0.040, z + edgeZ * depth / 2, extent - end, 0.03, 0.10, stone);
      }
      for (let line = -2; line <= 2; line++) {
        box(side * 5.62, 0.105, z + line * 0.45, 0.79, 0.009, 0.22, laneMark);
      }
    }
  }

  const nightGlass = luminous(0x8a79af, 0.43);
  const violetTube = luminous(0xcbb1fc, 1.82);
  const violetSign = { text: '#e0d5ff', aux: '#a59abc', trim: '#86759c', panel: '#2e2a3e' };
  const grainSign = { text: '#ffd9be', aux: '#dba089', trim: '#936f63', panel: '#392c2b' };

  function venueFacade(id, style) {
    const { x, z, width, depth, height } = CITY_VENUES[id];
    const entrance = CITY_ENTRANCES[id];
    const face = z + depth / 2;
    const facadeCenter = x - 0.02;
    const door = entrance.x;
    const { wall, trim, glowMat, glass, signColors, title, subtitle, color } = style;
    barrier(x, height / 2, z, width, height, depth, wall);
    box(x, height + 0.17, z, width + 0.32, 0.32, depth + 0.30, trim);
    box(x, height + 0.50, z - 0.40, width * 0.75, 0.52, depth * 0.69, wall);
    floor(x, face + 1.02, width + 0.14, 2.32, paving, 0.096);
    box(x, 0.17, face + 0.045, width + 0.08, 0.3, 0.15, trim);
    box(x, 3.73, face + 0.06, width + 0.16, 0.20, 0.34, trim);
    box(door, 1.64, face + 0.08, 1.78, 2.86, 0.14, blackMetal);
    box(door, 1.64, face + 0.16, 1.63, 2.75, 0.11, glass);
    box(door, 1.65, face + 0.24, 0.075, 2.75, 0.08, trim);
    box(door, 2.99, face + 0.28, 1.71, 0.07, 0.07, glowMat);
    box(door, 3.24, face + 0.49, 2.16, 0.12, 1.13, metal);
    box(door, 3.16, face + 0.85, 1.86, 0.035, 0.05, glowMat);
    for (const side of [-1, 1]) {
      box(door + side * 0.91, 1.65, face + 0.19, 0.15, 3.08, 0.43, trim);
      box(door + side * 0.26, 1.36, face + 0.25, 0.049, 0.33, 0.075, brass);
      const end = x + side * (width / 2 - 0.12);
      box(end, 1.94, face + 0.16, 0.22, 3.63, 0.35, trim);
      box(end, 2.67, face + 0.36, 0.07, 0.45, 0.05, glowMat);
    }
    const display = door + Math.sign(x - door) * 2.02;
    box(display, 1.92, face + 0.085, 1.79, 2.15, 0.14, metal);
    box(display, 1.92, face + 0.168, 1.65, 1.96, 0.030, style.displayGlass);
    box(display, 1.03, face + 0.183, 1.68, 0.048, 0.075, trim);
    for (let y = 6.22; y < height - 0.71; y += style.windowPitch) {
      for (const step of [-1, 0, 1]) {
        const bayX = x + step * width * 0.268;
        box(bayX, y, face + 0.038, width * 0.178, 1.37, 0.10, glass);
        box(bayX, y - 0.72, face + 0.136, width * 0.195, 0.085, 0.24, trim);
      }
      box(x + Math.sign(x) * width / 2, y, z, 0.095, 1.37, depth * 0.67, glass);
      box(x - Math.sign(x) * width / 2, y, z, 0.095, 1.37, depth * 0.67, glass);
    }
    sign(facadeCenter, 4.37, face + 0.24, width * 0.84, 0.83, title, subtitle, signColors);
    light(door, 2.9, face + 1.3, color, 16, 7.8);
    floorHaze(door, face + 1.56, 3.3, 3.9, color, 0.44, 0.106);
    glow(door, 3.16, face + 0.87, 1.64, color, 0.25);
  }

  venueFacade('auction-entry', {
    wall: darkTile, trim: brass, glowMat: amberTube, glass: glassWarm[1], displayGlass: glassWarm[2],
    signColors: warmSign, title: 'EXCHANGE AUCTION', subtitle: 'PUBLIC AUCTION HOUSE', color: 0xf2bc78, windowPitch: 2.17
  });
  venueFacade('home-entry', {
    wall: towerMaterials[3], trim: stone, glowMat: violetTube, glass: nightGlass, displayGlass: glassCold[2],
    signColors: violetSign, title: 'CROWNLINE TOWER', subtitle: 'PENTHOUSE RESIDENCES', color: 0xc8b8ff, windowPitch: 2.11
  });
  venueFacade('furniture-entry', {
    wall: darkBrick, trim: metal, glowMat: amberTube, glass: glassCold[2], displayGlass: glassWarm[0],
    signColors: grainSign, title: 'FORM & GRAIN', subtitle: 'FURNITURE SHOWROOM', color: 0xf4b395, windowPitch: 2.25
  });

  const auction = CITY_VENUES['auction-entry'];
  const auctionFace = auction.z + auction.depth / 2;
  for (const offset of [-2.72, -0.94, 0.94, 2.72]) {
    box(auction.x + offset, 7.55, auctionFace + 0.12, 0.16, 4.25, 0.25, brass);
    box(auction.x + offset, 9.67, auctionFace + 0.20, 0.25, 0.10, 0.40, amberTube);
  }
  box(auction.x, 10.55, auction.z, 6.90, 0.35, 8.32, stone);
  box(auction.x, 11.50, auction.z, 4.30, 0.8, 5.90, darkTile);
  box(auction.x, 11.92, auction.z, 4.44, 0.08, 5.99, brass);
  sign(auction.x + auction.width / 2 + .15, 5.15, 0.22, 0.77, 3.79,
    'AUCTION', '', warmSign, quarterTurn, true);

  const crownline = CITY_VENUES['home-entry'];
  box(crownline.x, 28.16, crownline.z + 0.12, 5.04, 0.055, 6.8, violetTube);
  box(crownline.x, 29.04, crownline.z - 0.16, 4.13, 1.45, 4.8, nightGlass);
  box(crownline.x, 29.84, crownline.z - 0.16, 4.4, 0.18, 5.03, stone);
  for (const offset of [-1.97, 0, 1.97]) {
    box(crownline.x + offset, 29.0, crownline.z + 2.28, 0.07, 1.4, 0.11, edge);
  }
  sign(crownline.x - crownline.width / 2 - .12, 7.35, 3.32, 0.95, 5.42,
    'CROWNLINE', '', violetSign, -quarterTurn, true);

  const showroom = CITY_VENUES['furniture-entry'];
  const showroomFace = showroom.z + showroom.depth / 2;
  const displayX = CITY_ENTRANCES['furniture-entry'].x + 2.02;
  const displayFabric = solid(0x785c46, 0.86);
  box(displayX, 1.67, showroomFace + 0.24, 1.38, 0.30, 0.10, displayFabric);
  box(displayX, 1.43, showroomFace + 0.27, 1.38, 0.18, 0.15, displayFabric);
  for (const offset of [-0.61, 0.61]) {
    box(displayX + offset, 1.55, showroomFace + 0.29, 0.21, 0.26, 0.18, displayFabric);
    box(displayX + offset, 1.29, showroomFace + 0.29, 0.056, 0.13, 0.05, brass);
  }
  sign(showroom.x - showroom.width / 2 - .12, 2.66, -30.66, 2.77, .59,
    'FORM & GRAIN', 'FURNITURE SHOWROOM', grainSign, -quarterTurn);

  const officeStone = surface('concrete', 2, 4, { color: 0xc4d7cf, roughness: .65 });
  const serviceBrick = surface('brick', 3, 3, { color: 0xb6aaa1, roughness: .78 }, .035);
  const warehouse = surface('metal', 5, 3, { color: 0x929a89, roughness: .64, metalness: .26 }, .031);
  venueFacade('bank-entry', {
    wall: officeStone, trim: stone, glowMat: whiteTube, glass: glassCold[1], displayGlass: glassCold[0],
    signColors: cleanSign, title: 'MERIDIAN BANK', subtitle: 'EAST ANNEX / CLIENT ENTRANCE', color: 0x9ee4cb, windowPitch: 2.52
  });
  venueFacade('night-window-entry', {
    wall: serviceBrick, trim: metal, glowMat: redPanel, glass: glassWarm[1], displayGlass: glassWarm[2],
    signColors: redSign, title: 'NIGHT WINDOW', subtitle: 'NORTH SERVICE', color: 0xe98969, windowPitch: 2.26
  });
  venueFacade('dispatch-entry', {
    wall: warehouse, trim: slate, glowMat: amberTube, glass: glassWarm[2], displayGlass: glassCold[0],
    signColors: warmSign, title: 'FREIGHT DISPATCH', subtitle: 'PAX MERCER / MEZZANINE', color: 0xebaf79, windowPitch: 2.4
  });
  const bankFace = CITY_VENUES['bank-entry'].z + CITY_VENUES['bank-entry'].depth / 2;
  for (const x of [32.25, 34.1, 38.94, 40.85]) {
    box(x, 2.85, bankFace + .12, .30, 5.45, .32, officeStone);
    box(x, 5.55, bankFace + .20, .48, .17, .49, brass);
  }
  const nightFace = CITY_VENUES['night-window-entry'].z + CITY_VENUES['night-window-entry'].depth / 2;
  for (const x of [-45.45, -39.42]) {
    box(x, 1.41, nightFace + .23, 1.35, 2.12, .14, warehouse);
    box(x, 2.48, nightFace + .35, 1.53, .08, .25, metal);
    for (let y = .52; y < 2.5; y += .18) box(x, y, nightFace + .316, 1.39, .026, .043, slate);
  }
  const freightFace = CITY_VENUES['dispatch-entry'].z + CITY_VENUES['dispatch-entry'].depth / 2;
  for (const x of [38, 45.18]) {
    box(x, 1.53, freightFace + .128, 1.86, 2.62, .12, warehouse);
    box(x, .20, freightFace + .22, 2.22, .28, .26, blackMetal);
    for (const o of [-.76, .76]) box(x + o, 2.79, freightFace + .26, .08, .14, .055, amberTube);
  }

  sign(-17.38, 2.73, 8.03, 2.58, 0.59, 'AUCTION ROW', 'EXCHANGE AUCTION HOUSE', warmSign, quarterTurn);
  sign(17.28, 2.73, 8.46, 2.55, 0.59, 'CROWNLINE', 'RESIDENCES  •  BANK ANNEX', violetSign, -quarterTurn);
  sign(14.56, 3.01, -21.62, 2.68, 0.61, 'FREIGHT LANE', 'COURIER DISPATCH  •  SHOWROOM', neutralSign, -quarterTurn);
  sign(-12.42, 2.74, -37.22, 2.55, 0.58, 'NORTH SERVICE', 'NIGHT WINDOW', redSign, quarterTurn);

  for (const [x, z, width, depth] of [
    [-23.7, 9.52, 2.02, 0.9], [-23.8, -7.1, 2.42, 0.85], [24.75, 8.52, 1.8, 0.75],
    [23.85, -24.0, 1.55, 0.9], [24.02, -1.95, 1.4, 0.9], [18.75, -47.45, 0.9, 1.5]
  ]) planter(x, z, width, depth);
  bench(-22.75, 13.20);
  bench(24.95, -26.17);

  addCityExpansion({ box, barrier, floor, floorHaze, sign, planter, bench, surface, solid, luminous });

  const { minX, maxX, minZ, maxZ } = CITY_BOUNDS;
  for (const x of [minX, maxX]) {
    for (const y of [.45, .90]) box(x, y, (minZ + maxZ) / 2, .068, .065, maxZ - minZ, edge);
    for (let z = minZ + 2; z <= maxZ - 2; z += 3.8) box(x, .57, z, .11, 1.14, .11, metal);
  }
  for (const z of [minZ, maxZ]) {
    for (const y of [.45, .90]) box(0, y, z, maxX - minX, .065, .068, edge);
    for (let x = minX + 2; x <= maxX - 2; x += 3.8) box(x, .57, z, .11, 1.14, .11, metal);
  }

  function collides(x, z, radius = .3) {
    if (x < minX + radius || x > maxX - radius || z < minZ + radius || z > maxZ - radius) return true;
    return collisions.some(([left, right, far, near]) => x + radius > left && x - radius < right && z + radius > far && z - radius < near);
  }

  for (const [material, specs] of batches) {
    const group = new THREE.InstancedMesh(cube, material, specs.length);
    for (const [i, [x, y, z, w, h, d, rotation]] of specs.entries()) {
      object.position.set(x, y, z);
      object.rotation.set(0, rotation, 0);
      object.scale.set(w, h, d);
      object.updateMatrix();
      group.setMatrixAt(i, object.matrix);
    }
    group.computeBoundingSphere();
    scene.add(group);
  }
  for (const { material, instances } of shrubs) {
    const group = new THREE.InstancedMesh(shrubGeometry, material, instances.length);
    for (const [i, [x, y, z, size, rotation]] of instances.entries()) {
      object.position.set(x, y, z);
      object.rotation.set(0, rotation, 0);
      object.scale.set(size, size * 0.83, size);
      object.updateMatrix();
      group.setMatrixAt(i, object.matrix);
    }
    group.computeBoundingSphere();
    scene.add(group);
  }

  const pedestrianRoutes = [
    { name: 'Merchant Mile walker', from: [-32.5, 23.9], to: [-32.5, 34.7], coat: 0x655c47 },
    { name: 'Freight Yard walker', from: [32.8, -51.8], to: [32.8, -38.9], coat: 0x536b60 },
    { name: 'North Terminal walker', from: [-23.0, -76.3], to: [-9.6, -76.3], coat: 0x554d4d },
    { name: 'Riverwalk pedestrian', from: [9.3, 52.8], to: [22.4, 52.8], coat: 0x6b6454 },
  ];
  const animateAmbient = addAmbient(scene, { collides, pedestrianRoutes });
  const rain = makeRain(scene);
  let motionPaused = Boolean(reducedMotion);
  rain.visible = !motionPaused;
  animateAmbient(0);
  return {
    landmarks: landmarkDefinitions.map(entry => ({ ...entry })),
    collides,

    setReducedMotion(enabled) {
      motionPaused = Boolean(enabled);
      rain.visible = !motionPaused;
      if (motionPaused) alleyLight.intensity = 21;
    },

    update(elapsed) {
      if (motionPaused) return;
      alleyLight.intensity = 20 + Math.sin(elapsed * 1.8) * 1.85;
      rain.material.uniforms.elapsed.value = elapsed;
      animateAmbient(elapsed);
    }
  };
}

function makeRain(scene) {
  const count = 2300;
  const rng = seeded(281);
  const start = new Float32Array(count * 6);
  const end = new Float32Array(count * 2);
  for (let i = 0; i < count; i++) {
    const x = CITY_BOUNDS.minX - 2 + rng() * (CITY_BOUNDS.maxX - CITY_BOUNDS.minX + 4);
    const y = rng() * 12.5;
    const z = CITY_BOUNDS.minZ + rng() * (CITY_BOUNDS.maxZ - CITY_BOUNDS.minZ);
    start.set([x, y, z, x, y, z], i * 6);
    end.set([0, 0.14 + rng() * 0.20], i * 2);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(start, 3));
  geometry.setAttribute('tail', new THREE.BufferAttribute(end, 1));
  const material = new THREE.ShaderMaterial({
    uniforms: { elapsed: { value: 0 } },
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    vertexShader: `
      attribute float tail;
      uniform float elapsed;
      varying float alpha;
      void main() {
        vec3 p = position;
        p.y = mod(p.y - 11. * elapsed, 12.5) + .2;
        p.x += p.y * .11 - tail * .21;
        p.y -= tail;
        vec4 view = modelViewMatrix * vec4(p, 1.);
        alpha = .22 * (1. - min(tail * 2.3, .75)) * (1. - smoothstep(9., 32., -view.z));
        gl_Position = projectionMatrix * view;
      }
    `,
    fragmentShader: `
      varying float alpha;
      void main() {
        gl_FragColor = vec4(.53, .71, .72, alpha);
      }
    `
  });
  const lines = new THREE.LineSegments(geometry, material);
  lines.name = 'Rain';
  lines.frustumCulled = false;
  scene.add(lines);
  return lines;
}
