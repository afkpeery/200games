export const FINAL_DAY = 12
export const WORTH_TARGET = 12000
