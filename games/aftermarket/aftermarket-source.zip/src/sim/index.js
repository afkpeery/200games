import { money, netWorth, resolveInvestments, settleDebts } from './economy.js'
import { marketFor } from './events.js'
import { adjustMeters } from './meters.js'
import { getNPC, useContact } from './npc.js'
import { normalizeSeed } from './random.js'
import { FINAL_DAY, WORTH_TARGET } from './rules.js'
import { chooseSociety } from './society.js'
import { collectAuctionRent, useVenue } from './venues.js'

export { getNPC, netWorth, FINAL_DAY, WORTH_TARGET }
export { DEAL_TYPES } from './economy.js'
export { EVENTS } from './events.js'
export { getSociety } from './society.js'

const SAVE_KEY = 'aftermarket.save.v1'
const VERSION = 1

export function createGame(seed) {
  const state = {
    version: VERSION,
    seed: normalizeSeed(seed),
    day: 1,
    cash: 0,
    reputation: 50,
    heat: 0,
    portfolio: [],
    assets: [],
    debts: [],
    history: [],
    record: [],
    event: null,
    ending: null,
    quote: null,
    gigDay: 0,
    fundedDay: 0,
    reviewedDay: 0,
    serviceDay: {},
    objective: ''
  }
  state.objective = objectiveFor(state)
  makeLog(state)('Arrived in Meridian', 'Twelve market closes. Find a contact for your first paid gig.', 'arrival')
  return state
}

function makeLog(state) {
  return (title, detail, kind, onRecord = false) => {
    state.history.unshift({ day: state.day, title, detail, kind })
    if (state.history.length > 160) state.history.length = 160
    if (onRecord) state.record.unshift({ day: state.day, title, detail, kind: 'offbook' })
  }
}

function objectiveFor(state) {
  if (state.ending) return state.ending.title
  if (!state.gigDay && !state.cash) return 'Earn your first capital from a contact.'
  if (!state.portfolio.length) return 'Back your first venture with Mara Voss.'
  if (netWorth(state) >= WORTH_TARGET) return 'Hold ' + money(WORTH_TARGET) + ' through Day ' + FINAL_DAY + '.'
  return 'Reach ' + money(WORTH_TARGET) + ' net worth by Day ' + FINAL_DAY + '.'
}

function concludingOutcome(state) {
  const worth = netWorth(state)
  const contested = state.record.some((entry) => entry.kind === 'offbook')
  if (state.heat >= 100) return {
    id: 'exposed',
    title: 'Exposed',
    description: 'The district froze your operation when heat reached 100. Your file closed at ' + money(worth) + ' net worth.'
  }
  if (state.day < FINAL_DAY) return null
  if (worth < WORTH_TARGET) return {
    id: 'fallen',
    title: 'Fallen Empire',
    description: 'The final close recorded ' + money(worth) + ' net worth. Your firm fell short of the ' + money(WORTH_TARGET) + ' threshold.'
  }
  if (state.reputation >= 75 && state.heat < 35) {
    return contested ? {
      id: 'redemption',
      title: 'Second Act',
      description: 'Your old record followed you, but the district backed your return. You closed with ' + money(worth) + ' net worth.'
    } : {
      id: 'tycoon',
      title: 'Respected Tycoon',
      description: 'Your clients and backers saw the whole climb. You became a Meridian institution with ' + money(worth) + ' net worth.'
    }
  }
  if (state.reputation <= 43 && contested) return {
    id: 'kingpin',
    title: 'Feared Kingpin',
    description: 'The district learned to price in your next move. You held together an off-book empire worth ' + money(worth) + '.'
  }
  return {
    id: 'broker',
    title: 'Midnight Broker',
    description: 'You dealt across the district and kept your seat at both tables. Your final net worth was ' + money(worth) + '.'
  }
}

function finishIfNeeded(state, log, atClose) {
  if (!atClose && state.heat < 100) return
  state.ending = concludingOutcome(state)
  if (state.ending) log(state.ending.title, state.ending.description, 'ending')
}

function closeMarket(state, log) {
  const closedDay = state.day
  const market = marketFor(state, log)
  resolveInvestments(state, market, log)
  collectAuctionRent(state, log)
  settleDebts(state, log)
  finishIfNeeded(state, log, true)
  if (state.ending) return state.ending.description

  // The daily meter cools. The permanent record still informs later enforcement.
  const touchedHeat = state.record.some((entry) => entry.day === closedDay && entry.kind === 'offbook')
  adjustMeters(state, 0, touchedHeat ? -4 : -9)
  state.day += 1
  state.quote = null
  return 'Day ' + closedDay + ' closed. Day ' + state.day + ' is open.'
}

export function perform(state, action) {
  if (!action || typeof action.id !== 'string') return { ok: false, message: 'Choose an available action.' }
  if (action.id.startsWith('society:')) return chooseSociety(state, action.id, makeLog(state))
  if (state.ending) return { ok: false, message: 'This run is complete. Start a new run to continue.' }
  const log = makeLog(state)
  if (action.id === 'advance') {
    const message = closeMarket(state, log)
    state.objective = objectiveFor(state)
    return { ok: true, message }
  }
  const atVenue = action.id.startsWith('auction:') || action.id.startsWith('furniture:')
  const result = atVenue ? useVenue(state, action.id, log) : useContact(state, action.npc, action, log)
  if (result.ok) {
    finishIfNeeded(state, log, false)
    state.objective = objectiveFor(state)
  }
  return result
}

function isValidSave(state) {
  return state !== null && typeof state === 'object' && state.version === VERSION &&
    typeof state.seed === 'string' && state.seed.length > 0 && Number.isInteger(state.day) &&
    state.day >= 1 && state.day <= FINAL_DAY && Number.isFinite(state.cash) &&
    Number.isFinite(state.reputation) && Number.isFinite(state.heat) &&
    Array.isArray(state.portfolio) && Array.isArray(state.assets) && Array.isArray(state.debts) &&
    Array.isArray(state.history) && Array.isArray(state.record) && typeof state.serviceDay === 'object' &&
    state.serviceDay !== null && typeof state.objective === 'string'
}

export function loadGame() {
  try {
    const contents = globalThis.localStorage.getItem(SAVE_KEY)
    if (!contents) return null
    const state = JSON.parse(contents)
    return isValidSave(state) ? state : null
  } catch {
    return null
  }
}

export function saveGame(state) {
  try {
    globalThis.localStorage.setItem(SAVE_KEY, JSON.stringify(state))
    return true
  } catch {
    return false
  }
}

export function clearSave() {
  try {
    globalThis.localStorage.removeItem(SAVE_KEY)
    return true
  } catch {
    return false
  }
}
