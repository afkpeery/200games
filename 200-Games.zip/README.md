# 200 Games

low budget nasties

This static landing page has no build step. Run `python3 -m http.server 8000` in this directory and open `http://localhost:8000`.

To publish on GitHub Pages, put these files at the root of the default branch, then select **Deploy from a branch** under **Settings → Pages** and select that branch and **/ (root)**.
