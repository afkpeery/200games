# AFTERMARKET

AFTERMARKET is a first-person venture simulation set in a rain-soaked financial district. You arrive with $0, earn capital through gigs, then turn founder pitches into a portfolio. Reputation changes who trusts you with credit and purchases. Heat tracks enforcement exposure independently, and major off-book decisions stay on your record across changes in strategy.

## Play

Open the standalone `Aftermarket.html` in a desktop browser with WebGL 2. In a browser that blocks local HTML, serve its directory with `python3 -m http.server 4173` and open `http://localhost:4173/Aftermarket.html`. The standalone build contains its code, fonts, and original art and works without an internet connection. Local saves belong to the browser and the address you use to open the game.

| Control | Action |
| --- | --- |
| WASD | Walk |
| Shift | Run outdoors |
| Mouse or arrow keys | Look. Click and drag when mouse lock is unavailable. |
| E | Talk to a nearby contact or use a marked entrance |
| Tab or P | Open the venture phone |
| H | Open Ticker’s field guide |
| N | Close the market day |
| Escape | Pause or release the mouse |
| M | Toggle sound |

Enter the Foundry Incubator and take the stairs to Mara Voss in the Pitch Lab for your first paid gig. Read the founder’s pitch, run diligence, then accept a term sheet or type a counteroffer. Open the phone for your portfolio, contacts, market, and district map. Closing the market day changes valuations, settles maturing deals, and introduces fresh pitches. Bank and private lender options depend on your standing. Reach $12,000 net worth by the close of Day 12. Heat reaching 100 ends the run early. At the end, your standing and record help determine which outcome you earn.

Find Pax Mercer on the Freight Dispatch mezzanine, Ellis Vale in the upstairs Credit Office at Meridian Bank Annex, and Ivo Rook in the Private Office at Night Window. The ground floors have signed stairs or elevators. Select a destination in the Venture Phone’s Map tab to track its direction and distance. Ticker offers a tip based on your current run. Game Settings lets you change the reduced-motion preference for NPC animation and outdoor effects.

- **Exchange Auction House.** Enter and walk up to the podium to bid on the day’s rental property. Rival bidders can raise the price. Winning properties appear in the portfolio and earn rent on later market closes.
- **Crownline Tower.** Take the lobby elevator to your penthouse. Use the planning desk to review your portfolio, or take the elevator back to the lobby.
- **Form & Grain.** Visit the showroom counter to buy sofas, tables, and lamps. Purchased pieces are installed in the penthouse. Return to the store to switch between pieces you own.

The five deal structures are seed equity, convertible notes, bridge rounds, revenue shares, and buyout syndicates. Night Selloff, Listing Fever, and Regulatory Sweep occur at the closes of Days 3, 6, and 9 in a seeded order. Open settings, choose **New run**, and reuse the seed to reproduce the sequence of pitches and market events with a different set of choices.

<details>
<summary>Hidden ending</summary>

Close Day 12 with a successful ending and at least $24,000 in net worth to earn an invitation. Enter the Exchange and take the private lift from the lobby to the Quiet Ledger chamber. One council decision is saved alongside your original ending. A previously completed run that meets the same conditions can open the invitation from its closing report.

</details>

## Develop

Use Node.js 22.12 or later with npm. The production build is static.

```sh
npm ci
npm run dev
```

Open the development URL printed by Vite. To test a production build and create the standalone release, run these commands from the project root. The preview server runs until you stop it or move the packaging command to a second terminal.

```sh
npm run build
npm run preview
```

```sh
node scripts/package-offline.mjs dist "$PWD/Aftermarket.html"
```

To package the editable project on a machine with `zip`, include the entry point, configuration, package lock, source, and packaging tool.

```sh
zip -r ../aftermarket-source.zip README.md index.html package.json package-lock.json vite.config.js src scripts public/THIRD-PARTY-NOTICES.txt
```

For a hosted release, build with the download links enabled and place both archives alongside the game in `dist/`.

```sh
VITE_RELEASE_DOWNLOADS=1 npm run build
node scripts/package-offline.mjs dist "$PWD/dist/Aftermarket.html"
zip -j dist/aftermarket-offline.zip dist/Aftermarket.html README.md
zip -r dist/aftermarket-source.zip README.md index.html package.json package-lock.json vite.config.js src scripts public/THIRD-PARTY-NOTICES.txt
```

The files under `src/sim/` implement the economy, market events, seeded randomness, NPC decisions, save data, and the Quiet Ledger choices. `src/district.js` defines the layout, and `src/world.js` and `src/world-expansion.js` build the city. `src/world-textures.js` generates surface color and relief maps. `src/world-contacts.js` builds and animates mission characters. `src/world-missions.js` builds their floors. The other interior modules build the auction house, showroom, apartment building, and Exchange. `src/player.js` controls the camera and renderer, and `src/main.js` connects the interface to the simulation.

## Swap surface textures

The bundled materials are generated for the game. To replace asphalt, concrete, tile, or plaster with a texture you have rights to use, put it under `src/textures/`, then import it in `src/player.js` and pass it to `createWorld`.

```js
import asphaltUrl from './textures/wet-asphalt.webp?inline';

const world = createWorld(scene, {
  surfaceMaps: { street: asphaltUrl },
});
```

The keys are `street`, `concrete`, `tile`, `plaster`, `alley`, `brick`, `metal`, and `aggregate`. Unspecified materials keep their generated textures. Repeatable WebP images with even lighting work well. The `?inline` import keeps the replacement inside the standalone build. To swap a texture only for served builds, put it under `public/textures/` and pass a relative URL such as `./textures/wet-asphalt.webp`. Rebuild after changing materials.

## Scope and licenses

The single-player game covers Meridian and its interiors, including four two-level mission buildings. Typed negotiation runs through the game’s rules without an account or API key.

The world geometry, textures, signs, and interfaces are original to this build. The original Ticker portrait in `src/assets/ticker-mascot.webp` was generated with ImageGen and optimized to WebP. Three.js and Vite are MIT-licensed. Barlow Condensed, IBM Plex Mono, and Inter use the SIL Open Font License 1.1. `public/THIRD-PARTY-NOTICES.txt` is copied into the served build and embedded in the standalone HTML. Refresh the notices when the included dependency versions change.

## Verification

- `npm run build` produced a static HTML entry, one JavaScript module, and one stylesheet. `node scripts/package-offline.mjs dist "$PWD/Aftermarket.html"` combines them with the font and library notices.
- A Chromium 156 test using SwiftShader WebGL 2 loaded the standalone document, entered the district, checked the initial cash and meters, opened the portfolio with Tab, closed Day 1 with N, and confirmed Day 2 after reloading. The test supplied only the standalone HTML over a loopback browser route. It recorded zero secondary HTTP requests and zero uncaught page errors. The managed browser blocked direct `file://` navigation.
- A scripted simulation run with the `AFTERMARKET` seed verified a paid gig, a typed negotiation and signed offer, all five deal structures, all three market events, an exit, the Respected Tycoon ending, deterministic replay, and a save/load round trip.
