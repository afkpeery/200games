import * as THREE from 'three';
import { canvasTexture, seeded, signTexture, surfaceTexture } from './world-textures.js';

const rightAngle = Math.PI / 2;
const doorColor = '#9dc9bc';
const roomSpecs = {
  auction: {
    side: 8.6, front: 8.0, back: -12.0, height: 5.8, spawnZ: 5.8,
    colors: [0x543536, 0x261d20, 0xc9a179, 0xf0ba78],
    landmarks: [
      { id: 'auction-podium', label: 'Auctioneer', x: 0, z: -5.1, color: '#ffc387' },
      { id: 'auction-exit', label: 'Street Exit', x: 0, z: 7.2, color: doorColor }
    ]
  },
  furniture: {
    side: 10, front: 8.0, back: -11.3, height: 4.5, spawnZ: 5.8,
    colors: [0x6e4f3e, 0x282727, 0xc2a47d, 0xf9c17f],
    landmarks: [
      { id: 'furniture-counter', label: 'Shop Counter', x: 0, z: -6.7, color: '#ffd49a' },
      { id: 'furniture-exit', label: 'Street Exit', x: 0, z: 7.2, color: doorColor }
    ]
  },
  lobby: {
    side: 7.5, front: 8.2, back: -8.9, height: 5, spawnZ: 6.0,
    colors: [0x365655, 0x243436, 0x8caeb3, 0xe1c28c],
    landmarks: [
      { id: 'lobby-elevator', label: 'Elevator', x: 0, z: -7.6, color: '#eac588' },
      { id: 'lobby-exit', label: 'Street Exit', x: 0, z: 7.4, color: doorColor }
    ]
  },
  apartment: {
    side: 9.8, front: 8.0, back: -9.4, height: 4.4, spawnZ: 5.2,
    colors: [0x545258, 0x2e3438, 0x9aaec9, 0xf7c593],
    landmarks: [
      { id: 'apartment-elevator', label: 'Elevator to Lobby', x: 0, z: 7.2, color: '#eac588' },
      { id: 'apartment-desk', label: 'Venture Desk', x: -5.45, z: 3.45, color: '#add5cd' }
    ]
  }
};

function woodTexture() {
  const random = seeded(9413);
  return canvasTexture(512, 512, (ctx, w, h) => {
    const pixels = ctx.createImageData(w, h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const index = 4 * (y * w + x);
        const offset = y + 4 * Math.sin(x / 41) + 2 * Math.sin(x / 23 + y / 45);
        const grain = 9 * Math.sin(offset * .35) + 5 * Math.sin(offset * .87) + random() * 10;
        const board = Math.floor(y / 64) % 3 * 6 + (y % 64 < 2 ? -26 : 0);
        pixels.data[index] = 103 + grain + board;
        pixels.data[index + 1] = 74 + (grain + board) * .85;
        pixels.data[index + 2] = 54 + (grain + board) * .70;
        pixels.data[index + 3] = 255;
      }
    }
    ctx.putImageData(pixels, 0, 0);
  }, 2, 3);
}

function skylineTexture() {
  const random = seeded(8101);
  return canvasTexture(1280, 512, (ctx, w, h) => {
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#141e31');
    sky.addColorStop(.52, '#364853');
    sky.addColorStop(1, '#9c7164');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);
    const haze = ctx.createRadialGradient(w * .64, h * .58, 16, w * .64, h * .58, w * .4);
    haze.addColorStop(0, 'rgba(211,155,113,.36)');
    haze.addColorStop(1, 'rgba(211,155,113,0)');
    ctx.fillStyle = haze;
    ctx.fillRect(0, 0, w, h);
    for (let layer = 0; layer < 3; layer++) {
      for (let x = -28; x < w;) {
        const span = 25 + random() * 95;
        const roof = h * (.38 + layer * .07 + random() * .33);
        const bay = 7 + layer * 4;
        ctx.fillStyle = ['#39454e', '#293641', '#1a2a35'][layer];
        ctx.fillRect(x, roof, span, h - roof);
        ctx.fillRect(x + span * .27, roof - 8 - random() * 18, span * .27, 29);
        for (let y = roof + 16; y < h; y += bay) {
          for (let col = x + 5; col < x + span - 5; col += bay) {
            if (random() < .47) continue;
            ctx.fillStyle = ['#a89c71', '#b29d8c', '#678e9a'][Math.floor(random() * 3)];
            ctx.globalAlpha = .28 + random() * .63;
            ctx.fillRect(col, y, bay * .48, bay * .21);
          }
        }
        ctx.globalAlpha = 1;
        x += span + random() * 11;
      }
    }
    for (let i = 0; i < 400; i++) {
      const x = random() * w;
      const y = random() * h;
      const length = 4 + random() * 24;
      ctx.strokeStyle = i % 8 ? 'rgba(183,204,216,.10)' : 'rgba(183,204,216,.40)';
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x - length * .21, y + length);
      ctx.stroke();
    }
  });
}

export function createInterior(scene, id, { reducedMotion = false } = {}) {
  const room = roomSpecs[id];
  const [wallColor, darkColor, skyColor, lampColor] = room.colors;
  const { side, front, back, height } = room;
  const width = side * 2;
  const depth = front - back;
  const middle = (front + back) / 2;
  const block = new THREE.BoxGeometry(1, 1, 1);
  const rectangle = new THREE.PlaneGeometry(1, 1);
  const transform = new THREE.Object3D();
  const batches = new Map();
  const collisions = [];
  const furnishings = new Map();
  const mapFeatures = { blocks: [] };
  let activeBatches = batches;

  function solid(color, roughness = .67, metalness = .04) {
    return new THREE.MeshStandardMaterial({ color, roughness, metalness });
  }

  function emitter(color, intensity = 1.3) {
    return new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: .48 });
  }

  function box(x, y, z, w, h, d, material, yaw = 0) {
    if (!activeBatches.has(material)) activeBatches.set(material, []);
    activeBatches.get(material).push([x, y, z, w, h, d, yaw]);
  }

  function bake(source, target) {
    for (const [material, parts] of source) {
      const mesh = new THREE.InstancedMesh(block, material, parts.length);
      for (const [index, [x, y, z, w, h, d, yaw]] of parts.entries()) {
        transform.position.set(x, y, z);
        transform.scale.set(w, h, d);
        transform.rotation.set(0, yaw, 0);
        transform.updateMatrix();
        mesh.setMatrixAt(index, transform.matrix);
      }
      mesh.computeBoundingSphere();
      target.add(mesh);
    }
  }

  function panel(x, y, z, w, h, texture, yaw = 0, toneMapped = true) {
    const mesh = new THREE.Mesh(rectangle, new THREE.MeshBasicMaterial({ map: texture, toneMapped }));
    mesh.position.set(x, y, z);
    mesh.scale.set(w, h, 1);
    mesh.rotation.y = yaw;
    scene.add(mesh);
  }

  function plaque(text, subtext, x, y, z, w, yaw = 0) {
    const texture = signTexture(text, subtext, {
      panel: '#463e32', trim: '#9d8056', text: '#e8c994', aux: '#bca37a'
    });
    panel(x, y, z, w, w * .224, texture, yaw, false);
  }

  function obstacle(x, z, w, d) {
    const bounds = { minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 };
    collisions.push(bounds);
    mapFeatures.blocks.push([bounds.minX, bounds.minZ, bounds.maxX, bounds.maxZ]);
  }

  function light(x, y, z, color, intensity, distance) {
    const lamp = new THREE.PointLight(color, intensity, distance, 2);
    lamp.position.set(x, y, z);
    scene.add(lamp);
    return lamp;
  }

  const wall = solid(wallColor);
  const dark = solid(darkColor, .51);
  const trim = solid(0x907252, .38, .45);
  const iron = solid(0x222d31, .35, .62);
  const linen = solid(0xaf9278);
  const marble = new THREE.MeshStandardMaterial({
    color: id === 'lobby' ? 0x9fb4ae : 0xb9a99a,
    map: surfaceTexture('tile', 3, 4), roughness: .39, metalness: .17
  });
  const wood = new THREE.MeshStandardMaterial({ map: woodTexture(), roughness: .58 });
  const floor = id === 'lobby' || id === 'auction' ? marble : wood;
  const lamp = emitter(lampColor);
  const cold = emitter(skyColor, .65);
  const warm = solid(0x6a4136);
  const green = solid(0x446a58);
  const red = solid(0x733b40);
  const sand = solid(0x8e7053);
  const paper = solid(0xc1b39a);
  const leather = solid(0x9f5b36, .48);
  const upholstery = solid(0x3e4850);
  const glass = solid(0x303d46, .19, .6);
  const runner = solid(0x49373b, .93);
  const rugGreen = solid(0x36554f, .92);
  const rugTan = solid(0x8c725e, .92);
  scene.background = new THREE.Color(darkColor);
  scene.add(new THREE.HemisphereLight(skyColor, 0x44352e, 2.18));

  // Continuous shell with interior-facing architectural trim.
  box(0, -.12, middle, width, .24, depth, floor);
  box(0, height + .1, middle, width, .22, depth, dark);
  box(0, height / 2, front + .16, width + .5, height, .32, wall);
  box(0, height / 2, back - .16, width + .5, height, .32, wall);
  for (const direction of [-1, 1]) {
    const x = direction * side;
    box(x + direction * .17, height / 2, middle, .34, height, depth, wall);
    box(x - direction * .07, .31, middle, .14, .62, depth, dark);
    box(x - direction * .145, .64, middle, .05, .05, depth, trim);
    box(x - direction * .1, height - .31, middle, .21, .29, depth, dark);
    box(x - direction * .24, height - .46, middle, .065, .045, depth, trim);
  }
  for (const z of [front - .07, back + .07]) {
    box(0, .27, z, width, .54, .14, dark);
    box(0, height - .34, z, width, .27, .19, dark);
  }

  function sconce(x, z, y = 2.76) {
    box(x, y, z, .15, .73, .31, trim);
    box(x, y + .06, z, .21, .29, .36, lamp);
    box(x, y + .25, z, .26, .10, .44, iron);
    box(x, y - .13, z, .26, .10, .44, iron);
  }

  function roofLight(x, z, w) {
    box(x, height - .18, z, w + .35, .18, .30, iron);
    box(x, height - .286, z, w, .055, .18, lamp);
  }

  function door(x, z, yaw, title, subtext, elevator = false) {
    const inward = Math.cos(yaw);
    box(x, 1.42, z, 2.75, 2.86, .16, dark);
    const doorSurface = elevator ? iron : glass;
    for (const direction of [-1, 1]) {
      box(x + direction * .59, 1.31, z + inward * .10, 1.12, 2.59, .10, doorSurface);
      box(x + direction * 1.2, 1.48, z + inward * .18, .115, 2.98, .25, trim);
      if (!elevator) {
        box(x + direction * .59, 1.72, z + inward * .168, .77, 1.14, .045, dark);
        box(x + direction * .59, 1.72, z + inward * .195, .65, 1.02, .03, cold);
        box(x + direction * .19, 1.08, z + inward * .188, .045, .26, .09, trim);
      }
    }
    box(x, 2.92, z + inward * .18, 2.52, .12, .25, trim);
    if (elevator) {
      box(x + 1.61, 1.17, z + inward * .20, .19, .35, .12, iron);
      box(x + 1.61, 1.21, z + inward * .269, .08, .08, .046, lamp);
    }
    plaque(title, subtext, x, 3.28, z + inward * .205, 2.44, yaw);
  }

  function rug(x, z, w, d, material) {
    box(x, .016, z, w, .031, d, material);
    for (const direction of [-1, 1]) {
      box(x + direction * (w / 2 - .14), .037, z, .035, .013, d - .24, trim);
      box(x, .038, z + direction * (d / 2 - .13), w - .26, .013, .035, trim);
    }
  }

  function plant(x, z, size) {
    box(x, size * .19, z, size * .44, size * .38, size * .44, sand);
    box(x, size * .39, z, size * .49, size * .08, size * .49, dark);
    box(x, size * .65, z, .058, size * .63, .065, wood);
    for (const [i, [dx, dz]] of [[-.22, -.12], [.18, .16], [.23, -.20], [-.08, .25], [.05, .02]].entries()) {
      box(x + dx * size, size * (.74 + .073 * i), z + dz * size, size * .32, size * .125, size * .22, green, i * .81);
    }
  }

  function attendant(x, z, jacket) {
    const skin = solid(0xa8795e);
    const hair = solid(0x3e312b);
    box(x, 1.17, z, .43, .61, .25, jacket);
    box(x, 1.35, z + .144, .125, .26, .045, paper);
    box(x, 1.64, z + .038, .217, .24, .216, skin);
    box(x, 1.775, z - .013, .239, .09, .225, hair);
    box(x, 1.704, z - .088, .224, .097, .08, hair);
    for (const side of [-1, 1]) {
      box(x + side * .055, 1.667, z + .151, .024, .014, .013, dark);
      box(x + side * .261, 1.20, z, .11, .48, .11, jacket);
      box(x + side * .26, 1.02, z + .13, .097, .1, .30, skin);
    }
  }

  function furniture(sku, x, z) {
    if (sku === 'charcoal-sofa' || sku === 'cognac-sofa') {
      const charcoal = sku === 'charcoal-sofa';
      const color = charcoal ? upholstery : leather;
      const w = charcoal ? 2.9 : 2.55;
      box(x, .19, z, w, .17, .91, dark);
      box(x, .41, z, w, .33, 1, color);
      box(x, .74, z + .39, w, .6, .23, color);
      for (const direction of [-1, 1]) {
        box(x + direction * (w / 2 - .12), .61, z, .235, .47, 1.04, color);
        box(x + direction * .46, .614, z - .07, .89, .115, .69, color);
        box(x + direction * .54, .827, z + .229, 1.01, .33, .12, color);
        for (const feetZ of [-.37, .37]) {
          box(x + direction * (w / 2 - .15), .066, z + feetZ, .091, .14, .09, trim);
        }
      }
      const pillow = charcoal ? linen : rugGreen;
      box(x - w * .31, .817, z + .116, .39, .36, .18, pillow, -.19);
      box(x + w * .31, .817, z + .119, .38, .34, .18, pillow, .23);
      if (charcoal) {
        box(x + .99, .337, z - .65, .91, .4, 1.31, color);
        box(x + .99, .589, z - .685, .87, .10, 1.33, color);
      }
      return;
    }
    if (sku === 'walnut-table' || sku === 'glass-table') {
      const walnut = sku === 'walnut-table';
      box(x, .43, z, 1.85, .103, .99, walnut ? wood : glass);
      for (const direction of [-1, 1]) {
        box(x + direction * .72, .219, z, .079, .428, .79, walnut ? wood : trim);
        box(x, .391, z + direction * .45, 1.81, .054, .035, walnut ? dark : trim);
      }
      box(x + .28, .496, z + .16, .42, .041, .30, paper, .16);
      box(x + .285, .525, z + .159, .40, .02, .28, warm, .16);
      return;
    }
    const arc = sku === 'arc-lamp';
    box(x, .062, z, .48, .12, .40, arc ? iron : trim);
    box(x, .961, z, .042, 1.82, .044, arc ? iron : trim);
    if (arc) box(x + .24, 1.848, z, .51, .042, .047, iron);
    const shadeX = x + (arc ? .48 : 0);
    box(shadeX, 1.71, z, .37, .24, .37, arc ? linen : trim);
    box(shadeX, 1.58, z, .32, .044, .32, lamp);
    box(shadeX, 1.844, z, .23, .061, .23, arc ? linen : trim);
  }

  let accent;
  if (id === 'auction') {
    door(0, front - .16, Math.PI, 'EXIT', 'TO THE STREET');
    rug(0, -.3, 2.43, 13.4, runner);
    for (const direction of [-1, 1]) {
      for (const z of [-8.5, -4.6, -.7, 3.2, 6.7]) {
        box(direction * (side - .17), 2.28, z, .21, 4.55, .38, dark);
        sconce(direction * (side - .28), z);
      }
      for (const z of [.15, 2.35, 4.55]) {
        const x = direction * 4.15;
        box(x, .22, z, 3.31, .41, .77, wood);
        box(x, .48, z, 3.28, .16, .75, red);
        box(x, .72, z + .32, 3.28, .52, .125, red);
        box(x, .91, z + .35, 3.35, .06, .16, trim);
        obstacle(x, z, 3.34, .94);
      }
      plant(direction * 6.7, -8.7, 1.3);
      const x = direction * 5.25;
      box(x, .51, -5.8, 1.21, 1.02, 1.13, dark);
      box(x, 1.04, -5.8, 1.28, .12, 1.20, marble);
      box(x, 1.22, -5.8, .67, .23, .43, wood, direction * .22);
      box(x, 1.34, -5.8, .72, .035, .47, trim, direction * .22);
      obstacle(x, -5.8, 1.28, 1.2);
    }
    box(0, .17, -9.21, 12.2, .34, 5.2, dark);
    box(0, .36, -9.21, 12.2, .045, 5.2, wood);
    box(0, .31, -6.59, 12.18, .042, .06, trim);
    obstacle(0, -9.21, 12.2, 5.22);
    box(0, .62, -6.21, 1.44, 1.25, .91, wood);
    box(0, 1.23, -6.21, 1.58, .125, 1.01, trim);
    box(0, .73, -5.745, 1.06, .40, .043, dark);
    box(-.27, 1.323, -5.95, .36, .038, .08, iron);
    box(.17, 1.314, -6.05, .31, .022, .27, paper, -.08);
    obstacle(0, -6.18, 1.58, .91);
    attendant(0, -6.76, dark);
    plaque('EXCHANGE AUCTION HOUSE', 'LIVE LOTS  /  BIDDING FLOOR', 0, 3.75, back + .12, 8.6);
    roofLight(0, -4.3, 5.16);
    roofLight(0, 3.1, 4.25);
    accent = light(0, 3.66, -6.4, lampColor, 29, 11);
    light(0, 4.05, 4.2, skyColor, 24, 16);
  }

  if (id === 'furniture') {
    door(0, front - .16, Math.PI, 'EXIT', 'TO THE STREET');
    const displays = [
      { x: -5.1, z: .45, sofa: 'charcoal-sofa', table: 'walnut-table', lamp: 'arc-lamp',
        mat: rugGreen, title: 'THE LOFT', subtext: 'CHARCOAL  /  WALNUT  /  ARC' },
      { x: 5.1, z: .45, sofa: 'cognac-sofa', table: 'glass-table', lamp: 'brass-lamp',
        mat: rugTan, title: 'THE CLUB', subtext: 'COGNAC  /  SMOKED GLASS  /  BRASS' }
    ];
    for (const display of displays) {
      const { x, z, mat } = display;
      rug(x, z, 6.82, 6.6, mat);
      furniture(display.sofa, x, z + 1.52);
      furniture(display.table, x, z - .42);
      furniture(display.lamp, x + 2.15, z + 1.53);
      obstacle(x, z + 1.23, 3.05, 1.9);
      obstacle(x, z - .42, 1.85, .99);
      obstacle(x + 2.15, z + 1.53, .48, .40);
      box(x, .64, z - 2.56, 2.88, 1.27, .37, dark);
      plaque(display.title, display.subtext, x, .91, z - 2.356, 2.68);
      obstacle(x, z - 2.56, 2.88, .37);
      roofLight(x, z, 4.25);
      light(x, 3.78, z, lampColor, 20, 10);
    }
    for (const direction of [-1, 1]) {
      for (const z of [-6.4, 4.8]) {
        box(direction * (side - .44), .53, z, .68, 1.05, 3.1, wood);
        box(direction * (side - .43), 1.085, z, .72, .08, 3.22, trim);
        sconce(direction * (side - .20), z);
        obstacle(direction * (side - .44), z, .72, 3.22);
      }
      plant(direction * 5.0, -8.8, 1.58);
    }
    box(0, .57, -7.86, 4.55, 1.15, 1.24, wood);
    box(0, 1.17, -7.86, 4.68, .13, 1.38, iron);
    box(0, .74, -7.227, 3.82, .08, .039, lamp);
    box(1.14, 1.39, -7.72, .56, .305, .14, iron);
    box(-1.05, 1.255, -7.71, .56, .028, .39, paper);
    obstacle(0, -7.86, 4.68, 1.38);
    attendant(0, -8.79, green);
    plaque('FORM & GRAIN', 'FURNITURE SHOWROOM  /  CHECKOUT', 0, 3.20, back + .14, 7.97);
    accent = light(0, 3.74, -6.86, lampColor, 26, 11);
  }

  if (id === 'lobby') {
    door(0, front - .16, Math.PI, 'EXIT', 'TO THE STREET');
    door(0, back + .24, 0, 'ELEVATOR', 'PH  /  PRIVATE RESIDENCES', true);
    rug(0, -.23, 3.0, 13.2, rugGreen);
    for (const direction of [-1, 1]) {
      for (const z of [-5.8, -.6, 4.7]) {
        box(direction * 6.95, 2.34, z, .56, 4.67, .63, marble);
        box(direction * 6.95, 4.51, z, .72, .15, .77, trim);
        sconce(direction * 6.56, z);
        obstacle(direction * 6.95, z, .56, .63);
      }
      plant(direction * 3.45, -6.65, 1.54);
      obstacle(direction * 3.45, -6.65, .78, .78);
      box(direction * 4.7, .31, 2.45, 2.87, .53, 1.13, wood);
      box(direction * 4.7, .57, 2.45, 2.82, .17, 1.07, green);
      obstacle(direction * 4.7, 2.45, 2.89, 1.14);
      box(direction * 4.58, 2.07, back + .15, 4.5, 3.5, .20, dark);
      for (let i = 0; i < 12; i++) {
        box(direction * (2.79 + i * .312), 2.15, back + .285, .042, 3.57, .08, trim);
      }
    }
    for (const z of [-5.0, 0, 5.0]) {
      roofLight(0, z, 6.45);
    }
    const directoryZ = -.7;
    box(6.73, 1.68, directoryZ, .29, 2.67, 2.67, dark);
    plaque('CROWNLINE TOWER', 'PH  /  PRIVATE RESIDENCE', 6.55, 2.38, directoryZ, 2.46, -rightAngle);
    obstacle(6.73, directoryZ, .29, 2.67);
    accent = light(0, 3.5, -6.38, lampColor, 33, 12);
    light(0, 4.2, 2.83, skyColor, 32, 14);
  }

  if (id === 'apartment') {
    door(0, front - .16, Math.PI, 'ELEVATOR', 'G  /  STREET LOBBY', true);
    panel(0, 2.116, back + .102, 18.6, 4.12, skylineTexture(), 0, false);
    for (let x = -9.34; x <= 9.35; x += 3.11) {
      box(x, 2.14, back + .167, .115, 4.16, .14, iron);
    }
    for (const y of [.12, 1.05, 4.16]) {
      box(0, y, back + .174, 18.72, .092, .24, iron);
    }
    box(0, .13, back + .32, 18.8, .16, .54, trim);
    rug(-3.85, -2.52, 7.54, 6.9, rugGreen);
    rug(4.45, .13, 5.68, 4.46, rugTan);
    // The base apartment has built-in fixtures and open space for purchased pieces.
    box(7.8, .49, 3.07, 1.21, .98, 6.3, wood);
    box(7.8, 1.0, 3.07, 1.30, .11, 6.42, marble);
    for (const z of [.56, 1.72, 2.88, 4.04, 5.2]) {
      box(7.167, .57, z, .065, .68, 1.04, dark);
      box(7.124, .81, z, .05, .035, .31, trim);
    }
    obstacle(7.8, 3.07, 1.30, 6.42);
    box(5.45, .37, -2.61, 2.31, .57, 3.21, wood);
    box(5.45, .73, -2.59, 2.26, .32, 3.15, linen);
    box(5.45, .94, -3.79, 2.27, .11, .92, paper);
    box(5.45, .936, -1.98, 2.30, .08, 1.78, green);
    box(5.45, 1.0, -4.212, 2.37, 1.27, .16, dark);
    obstacle(5.45, -2.61, 2.40, 3.32);
    for (const x of [-8.15, 8.15]) {
      plant(x, -7.32, 1.47);
      obstacle(x, -7.32, .74, .74);
    }
    box(-5.45, .93, 5.12, 2.52, .11, 1.14, wood);
    box(-5.45, .63, 5.58, 2.5, .53, .22, dark);
    for (const x of [-6.57, -4.33]) {
      box(x, .48, 5.12, .17, .9, 1.06, wood);
    }
    box(-5.45, 1.20, 5.29, .87, .43, .105, iron);
    box(-5.45, 1.20, 5.229, .75, .32, .034, cold);
    plaque('VENTURE DESK', 'PORTFOLIO TERMINAL', -5.45, 1.23, 5.207, .69, Math.PI);
    box(-5.45, 1.002, 4.83, .72, .04, .29, iron);
    box(-4.56, 1.004, 4.88, .42, .042, .34, paper, .12);
    obstacle(-5.45, 5.12, 2.52, 1.14);
    roofLight(-5.45, 4.85, 2.91);
    const slots = {
      'charcoal-sofa': [-3.84, -1.03],
      'cognac-sofa': [-3.84, -1.03],
      'walnut-table': [-3.84, -3.10],
      'glass-table': [-3.84, -3.10],
      'arc-lamp': [-6.21, -1.35],
      'brass-lamp': [-6.21, -1.35]
    };
    for (const [sku, [x, z]] of Object.entries(slots)) {
      const group = new THREE.Group();
      const parts = new Map();
      group.name = 'furnishing-' + sku;
      group.visible = false;
      activeBatches = parts;
      furniture(sku, x, z);
      bake(parts, group);
      scene.add(group);
      const [width, depth, offset] = sku === 'charcoal-sofa' ? [2.9, 1.85, -.34]
        : sku === 'cognac-sofa' ? [2.55, 1.04, 0]
          : sku.endsWith('table') ? [1.85, .99, 0] : [.48, .40, 0];
      furnishings.set(sku, {
        group, bounds: { minX: x - width / 2, maxX: x + width / 2, minZ: z + offset - depth / 2, maxZ: z + offset + depth / 2 }
      });
    }
    activeBatches = batches;
    roofLight(-3.74, -1.84, 4.7);
    roofLight(5.1, 2.0, 5.04);
    accent = light(-4.08, 3.54, -.76, lampColor, 18, 10);
    light(2.65, 2.6, -7.46, 0x99c4e9, 22, 17);
    light(5.7, 3.43, 2.38, lampColor, 22, 11);
  }

  for (const landmark of room.landmarks) {
    const marker = new THREE.Mesh(new THREE.RingGeometry(.34, .388, 40), new THREE.MeshBasicMaterial({
      color: landmark.color, transparent: true, opacity: .75, toneMapped: false
    }));
    marker.position.set(landmark.x, .056, landmark.z);
    marker.rotation.x = -rightAngle;
    scene.add(marker);
  }
  bake(batches, scene);

  const brightness = accent.intensity;
  const spawn = new THREE.Vector3(0, 1.68, room.spawnZ);
  const returnSpawn = new THREE.Vector3(0, 1.68, -5.1);
  const bounds = { minX: -side, maxX: side, minZ: back, maxZ: front };
  const staticBlocks = mapFeatures.blocks.slice();
  let installed = [];
  function overlaps(x, z, radius, rectangles) {
    return rectangles.some(({ minX, maxX, minZ, maxZ }) =>
      x + radius > minX && x - radius < maxX && z + radius > minZ && z - radius < maxZ);
  }

  function setReducedMotion(enabled) {
    reducedMotion = enabled;
    accent.intensity = brightness;
  }

  return {
    landmarks: room.landmarks,
    bounds,
    mapFeatures,
    spawn,
    yaw: 0,
    returnSpawn,
    elevatorArrival: { x: returnSpawn.x, z: returnSpawn.z, yaw: Math.PI },
    collides(x, z, radius = .3) {
      if (x - radius < bounds.minX || x + radius > bounds.maxX || z - radius < bounds.minZ || z + radius > bounds.maxZ) return true;
      return overlaps(x, z, radius, collisions) || overlaps(x, z, radius, installed);
    },
    setFurniture(ids) {
      const selected = new Set(ids);
      installed = [];
      for (const [sku, { group, bounds }] of furnishings) {
        group.visible = selected.has(sku);
        if (group.visible) installed.push(bounds);
      }
      mapFeatures.blocks = staticBlocks.concat(installed.map(({ minX, minZ, maxX, maxZ }) => [minX, minZ, maxX, maxZ]));
    },
    update(elapsed) {
      if (!reducedMotion) accent.intensity = brightness + .61 * Math.sin(elapsed * .95);
    },
    setReducedMotion
  };
}
