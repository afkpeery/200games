import '@fontsource/barlow-condensed/latin-600.css';
import '@fontsource/barlow-condensed/latin-700.css';
import '@fontsource/ibm-plex-mono/latin-500.css';
import '@fontsource/inter/latin-400.css';
import '@fontsource/inter/latin-600.css';
import '@fontsource/inter/latin-700.css';
import './style.css';
import './terminal.css';
import './society.css';
import './district.css';
import tickerArt from './assets/ticker-mascot.webp?inline';
import { Vector3 } from 'three';
import { createPlayer } from './player.js';
import { CITY_ENTRANCES, CITY_NEIGHBORHOODS } from './district.js';
import { createGame, loadGame, saveGame, getNPC, getSociety, perform, netWorth, FINAL_DAY, WORTH_TARGET } from './sim/index.js';
import { getAuction, getFurniture, getFurnishingIds } from './sim/venues.js';

const $ = (id) => document.getElementById(id);
const money = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
const dollars = (value) => money.format(value);
const pad = (value) => String(value).padStart(2, '0');
const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const locationSeed = new URLSearchParams(window.location.search).get('seed');
const defaultSeed = 'MERIDIAN';
const saved = loadGame();
let state = locationSeed && createGame(locationSeed).seed !== saved?.seed ? createGame(locationSeed) : saved || createGame(defaultSeed);
let society = getSociety(state);
let afterHours = false;
let pendingChoice = null;
let playing = false;
let entered = false;
let dialog = '';
let contact = null;
let phoneTab = 'Portfolio';
let nearest = null;
let trackedId = null;
let previousControl = null;
let modalNote = '';
let modalError = false;
let muted = false;
let motionPreference = null;
let audio;
let toastTimer;
let player;
const stage = $('stage');
const modal = $('modal');
const layer = $('modal-layer');
const worldCanvas = $('world');
const mapCanvas = $('map');
const touch = matchMedia('(pointer: coarse)');
const motionMedia = matchMedia('(prefers-reduced-motion: reduce)');
const point = new Vector3();
const markers = new Map();
const access = { banker: ['bank-loan', 'buy-office'], shark: ['private-loan', 'buy-lockup'] };
const missions = [
  { contact: 'founder', building: 'Foundry Incubator', ground: 'foundry', floor: 'foundry-lab', title: 'Foundry Pitch Lab', route: 'foundry-stairs', travel: 'Take the stairs to the Pitch Lab', direction: 'Take the stairs to meet Mara Voss in the Pitch Lab.', work: 'Talk to Mara Voss about paid work and venture pitches.' },
  { contact: 'banker', building: 'Meridian Bank Annex', ground: 'bank', floor: 'bank-credit', title: 'Meridian Credit Office', route: 'bank-elevator', travel: 'Take the elevator to the Credit Office', direction: 'Take the elevator to see Ellis Vale in the Credit Office.', work: 'Talk to Ellis Vale about bank credit, property, and compliance.' },
  { contact: 'shark', building: 'Night Window', ground: 'night-window', floor: 'night-window-office', title: 'Night Window Private Office', route: 'night-window-stairs', travel: 'Take the stairs to the Private Office', direction: 'Take the stairs to see Ivo Rook in the Private Office.', work: 'Talk to Ivo Rook about off-book work and private financing.' },
  { contact: 'courier', building: 'Freight Dispatch', ground: 'dispatch', floor: 'dispatch-mezzanine', title: 'Freight Dispatch Mezzanine', route: 'dispatch-stairs', travel: 'Take the stairs to the Mezzanine', direction: 'Take the stairs to meet Pax Mercer on the mezzanine.', work: 'Talk to Pax Mercer for a market tip.' },
];
const formatName = Object.fromEntries(missions.map(({ contact, building }) => [contact, building]));
const contactNames = Object.fromEntries(Object.keys(formatName).map((id) => [id, getNPC(state, id).name]));
const gameTabs = ['Portfolio', 'Contacts', 'Loans', 'Market', 'Map'];
const rooms = {
  district: { name: 'Meridian', map: 'District map' },
  exchange: { name: 'Meridian Exchange', map: 'Exchange lobby', tip: 'Read the market wire in the lobby. The private lift requires an invitation.' },
  chamber: { name: 'The Quiet Ledger', map: 'Chamber map' },
  auction: { name: 'Exchange Auction House', map: 'Auction floor', tip: 'Approach the podium to bid on the current lot.' },
  furniture: { name: 'Form & Grain', map: 'Showroom map', tip: 'Visit the counter to buy furniture for your penthouse.' },
  lobby: { name: 'Crownline Tower', map: 'Lobby map', tip: 'Take the elevator to your apartment.' },
  apartment: { name: 'Crownline Penthouse', map: 'Penthouse map', tip: 'Your home base. Furniture installed at Form & Grain appears here.' },
};
const doors = {
  'exchange-entry': { room: 'exchange', label: 'Enter Meridian Exchange' },
  'exchange-exit': { exit: 'exchange-entry', label: 'Return to Exchange Avenue' },
  'auction-entry': { room: 'auction', label: 'Enter auction house' },
  'home-entry': { room: 'lobby', label: 'Enter Crownline Tower' },
  'furniture-entry': { room: 'furniture', label: 'Enter furniture store' },
  'auction-exit': { exit: 'auction-entry', label: 'Return to the street' },
  'furniture-exit': { exit: 'furniture-entry', label: 'Return to the street' },
  'lobby-exit': { exit: 'home-entry', label: 'Return to the street' },
  'lobby-elevator': { room: 'apartment', label: 'Take elevator to penthouse' },
  'apartment-elevator': { room: 'lobby', fromElevator: true, label: 'Take elevator to lobby' },
};
const interactionLabels = {
  'exchange-lift': 'Check the private lift', 'exchange-wire': 'Read the market wire', council: 'Approach the Council', 'chamber-exit': 'Return to Exchange lobby',
  'auction-podium': 'Bid at the auction', 'furniture-counter': 'Shop furniture', 'apartment-desk': 'Review portfolio',
};
const venueDescriptions = { 'auction-entry': 'Property auctions', 'home-entry': 'Penthouse home', 'furniture-entry': 'Furniture showroom', 'exchange-entry': 'Market wire' };
const missionContacts = {};
for (const mission of missions) {
  const { contact, building, ground, floor, title, route, travel, direction, work } = mission;
  const entry = `${ground}-entry`;
  rooms[ground] = { name: building, map: 'Ground floor', tip: direction };
  rooms[floor] = { name: title, map: 'Mission floor', tip: work };
  doors[entry] = { room: ground, label: `Enter ${building}` };
  doors[`${ground}-exit`] = { exit: entry, label: 'Return to the street' };
  doors[route] = { room: floor, label: travel };
  doors[`${floor}-return`] = { room: ground, fromElevator: true, label: 'Return to the ground floor' };
  missionContacts[entry] = contactNames[contact];
}
const roomId = () => player?.room || 'district';
const insideChamber = () => roomId() === 'chamber';

try {
  muted = localStorage.getItem('aftermarket.muted') === 'true';
  motionPreference = localStorage.getItem('aftermarket.motion');
} catch { /* settings are optional */ }

$('ticker-art').src = tickerArt;

function updateSoundLabel() {
  $('mute-button').textContent = muted ? 'Sound off' : 'Sound on';
  $('mute-button').setAttribute('aria-pressed', muted);
}

function beep(success = true) {
  if (muted) return;
  try {
    audio ||= new AudioContext();
    if (audio.state === 'suspended') audio.resume().catch(() => {});
    const now = audio.currentTime;
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(success ? 440 : 155, now);
    oscillator.frequency.exponentialRampToValueAtTime(success ? 660 : 95, now + .1);
    gain.gain.setValueAtTime(.0001, now);
    gain.gain.exponentialRampToValueAtTime(.035, now + .015);
    gain.gain.exponentialRampToValueAtTime(.0001, now + .15);
    oscillator.connect(gain).connect(audio.destination);
    oscillator.start(now);
    oscillator.stop(now + .16);
  } catch { /* gameplay also works without Web Audio */ }
}

function toggleSound() {
  muted = !muted;
  try { localStorage.setItem('aftermarket.muted', String(muted)); } catch { /* settings are optional */ }
  updateSoundLabel();
  if (!muted) beep();
  if (dialog === 'pause') renderDialog();
}

function motionIsReduced() {
  return motionPreference === 'reduced' || (motionPreference !== 'full' && motionMedia.matches);
}

function refreshMotion() {
  const reduced = motionIsReduced();
  document.documentElement.dataset.motion = reduced ? 'reduced' : 'full';
  player?.setReducedMotion?.(reduced);
}

function toggleMotion() {
  motionPreference = motionIsReduced() ? 'full' : 'reduced';
  try { localStorage.setItem('aftermarket.motion', motionPreference); } catch { /* settings are optional */ }
  refreshMotion();
  renderDialog();
  modal.querySelector('[data-command="motion"]')?.focus();
}

function status(message, error = false) {
  const toast = $('toast');
  toast.textContent = message;
  toast.dataset.error = error;
  toast.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.hidden = true; }, 4300);
}

function refreshHUD() {
  society = getSociety(state);
  const room = rooms[roomId()];
  $('day').textContent = `DAY ${pad(state.day)}`;
  $('market-state').textContent = state.ending ? 'MARKET CLOSED' : 'MARKET OPEN';
  $('cash').textContent = dollars(state.cash);
  $('worth').textContent = dollars(netWorth(state));
  for (const [id, value] of [['rep', state.reputation], ['heat', state.heat]]) {
    $(id).value = value;
    $(`${id}-value`).textContent = `${pad(value)} / 100`;
  }
  const opening = !state.gigDay && state.cash === 0;
  const funded = state.portfolio.length > 0;
  $('objective-title').textContent = state.ending?.title || (opening ? 'Raise your first capital' : funded ? 'Build your empire' : 'Back your first venture');
  $('objective-description').textContent = state.ending?.description || (opening ? 'Enter the Foundry Incubator and meet Mara Voss upstairs for a paid gig.' : funded ? state.objective : 'Return to Mara Voss in the Pitch Lab and negotiate your first term sheet.');
  $('objective-target').lastChild.textContent = state.ending ? ' RUN COMPLETE' : funded ? ` ${dollars(WORTH_TARGET)} AT DAY ${FINAL_DAY} CLOSE` : ' FOUNDRY INCUBATOR';
  if (afterHours) {
    const inExchange = roomId() === 'exchange';
    $('objective-title').textContent = society.choice?.title || (insideChamber() ? 'Approach the Council' : inExchange ? 'Take the private lift' : 'Find Meridian Exchange');
    if (society.choice) {
      $('objective-description').textContent = insideChamber() ? 'Your decision is recorded. Use the lift to return to the Exchange lobby.' : 'Read your epilogue anytime from the closing report in Game Settings.';
    } else {
      $('objective-description').textContent = insideChamber() ? 'The Council is waiting at the end of the aisle.' : inExchange ? 'The private lift at the back of the lobby leads to the chamber.' : 'Follow Exchange Avenue to Meridian Exchange. The private lift is inside.';
    }
    $('objective-target').lastChild.textContent = insideChamber() ? ' THE QUIET LEDGER' : ' EXCHANGE PRIVATE LIFT';
  } else if (!state.ending && room.tip) {
    $('objective-title').textContent = room.name;
    $('objective-description').textContent = room.tip;
    $('objective-target').lastChild.textContent = ' E TO INTERACT';
  }
  stage.dataset.room = roomId();
  stage.setAttribute('aria-label', `${room.name} game view`);
  worldCanvas.setAttribute('aria-label', `First-person view of ${room.name}`);
  $('district-label').textContent = room.name.toUpperCase();
  $('map-caption').textContent = roomId() === 'district' ? 'LOCAL MAP' : room.map.toUpperCase();
  $('map-button').textContent = room.map;
  $('entry-seed').textContent = state.seed;
  $('start-label').textContent = state.ending ? 'View outcome' : state.day > 1 || state.history.length > 1 ? 'Continue district' : 'Enter district';
}

function refreshControlState(lock = false) {
  playing = entered && !dialog && (!state.ending || afterHours);
  stage.dataset.playing = playing;
  player?.setPlaying(playing, lock);
  $('entry').hidden = Boolean(dialog || playing || !player);
  $('touch-controls').hidden = !touch.matches || !playing;
  $('interact').hidden = !playing || !nearest;
  $('navigation-target').hidden = !playing || !trackedId || roomId() !== 'district' || afterHours;
}

function enter(lock = true) {
  if (state.ending && !afterHours) return openDialog('ending');
  if (!player) return;
  entered = true;
  refreshControlState(lock);
  worldCanvas.focus({ preventScroll: true });
  beep();
}

function openDialog(mode, detail) {
  if (!dialog) previousControl = document.activeElement;
  dialog = mode;
  if (mode === 'contact') contact = detail;
  if (mode === 'phone' && detail) phoneTab = detail;
  pendingChoice = mode === 'vote' ? society?.actions.find((choice) => choice.id === detail) : null;
  modalNote = '';
  modalError = false;
  $('toast').hidden = true;
  refreshControlState();
  layer.hidden = false;
  renderDialog();
  modal.focus({ preventScroll: true });
}

function closeDialog(lock = false) {
  dialog = '';
  contact = null;
  pendingChoice = null;
  layer.hidden = true;
  refreshControlState(lock);
  const restore = !playing && previousControl && !previousControl.closest('[hidden]') ? previousControl : worldCanvas;
  restore?.focus({ preventScroll: true });
}

function dialogHeader(kicker, title) {
  return `<header class="modal-header"><div><div class="modal-kicker">${escapeHTML(kicker)}</div><h2 id="modal-title">${escapeHTML(title)}</h2></div><button type="button" class="close-button" data-command="close" aria-label="Close dialog">×</button></header>`;
}

function note() {
  return modalNote ? `<p class="modal-note" role="status" data-error="${modalError}">${escapeHTML(modalNote)}</p>` : '';
}

function describeAction(action) {
  const detail = [action.detail, action.reason].filter(Boolean).join(' · ');
  return `<button type="button" class="action" data-action="${escapeHTML(action.id)}" ${action.disabled ? 'disabled' : ''}><strong>${escapeHTML(action.label)}</strong><small>${escapeHTML(detail)}</small></button>`;
}

function renderContact() {
  const npc = getNPC(state, contact);
  if (contact === 'courier') {
    return `${dialogHeader(`${npc.role} · ${formatName[contact]}`, npc.name)}<div class="modal-body"><p class="courier-note">“${escapeHTML(npc.line)}”</p><button type="button" class="secondary" data-command="map">Open district map</button></div>`;
  }
  const pitch = npc.pitch;
  const pitchBlock = pitch ? `<div class="pitch"><strong>${escapeHTML(pitch.name)}</strong><span class="ask">${dollars(pitch.ask)} ASK</span><small>${escapeHTML(pitch.industry)} · ${escapeHTML(pitch.stage)} · ${escapeHTML(pitch.dealType)}</small><span class="pitch-tag">${escapeHTML(pitch.risk)}</span></div>` : '';
  const negotiation = pitch && state.fundedDay !== state.day && !state.ending ? `<form id="negotiate-form" class="negotiation"><label for="terms">Propose your own terms</label><div class="form-row"><input id="terms" name="terms" placeholder="$650 for 20%" maxlength="180" required autocomplete="off"><button type="submit" class="secondary">Propose</button></div></form>` : '';
  return `${dialogHeader(`${npc.role} · ${formatName[contact]}`, npc.name)}<div class="modal-body"><p>“${escapeHTML(npc.line)}”</p>${pitchBlock}<div class="action-list">${npc.actions.map(describeAction).join('')}</div>${negotiation}${note()}</div>`;
}

function recordCard(label, detail, status = '', statusID = status) {
  return `<article class="record-card"><header><strong>${escapeHTML(label)}</strong><span class="status" data-status="${escapeHTML(statusID)}">${escapeHTML(status)}</span></header><p>${escapeHTML(detail)}</p></article>`;
}

function showPortfolio() {
  const holdings = state.portfolio.slice().reverse().map((venture) => {
    const checkpoint = venture.status === 'active' ? ` · Resolves Day ${venture.maturityDay}` : '';
    return recordCard(venture.name, `${venture.industry} · ${venture.equity}% equity · ${dollars(venture.invested)} invested · ${dollars(venture.value)} ${venture.status === 'exited' ? 'payout' : 'value'}${checkpoint}`, venture.status);
  });
  const property = state.assets.map((asset) => {
    const rent = asset.channel === 'Auction' ? ` · ${dollars(asset.income)} rent per close` : '';
    return recordCard(asset.name, `${asset.channel} property · ${dollars(asset.value)} estimated value${rent}`, 'Owned');
  });
  return `<div class="phone-summary"><span>NET WORTH <b>${dollars(netWorth(state))}</b></span><span>VENTURES <b>${state.portfolio.length}</b></span><span>PROPERTIES <b>${state.assets.length}</b></span></div><div class="cards">${[...property, ...holdings].join('') || '<p>Your portfolio is empty. Earn cash from a contact and back a venture at the Foundry.</p>'}</div>`;
}

function showContacts() {
  if (roomId() !== 'district' || afterHours) {
    return `<div class="cards">${currentLandmarks().map((landmark) => recordCard(landmark.label, rooms[roomId()].name, nearest?.id === landmark.id ? 'Nearby' : '')).join('')}</div>`;
  }
  return `<div class="cards">${missions.map(({ contact, building, ground, title }) => {
    const npc = getNPC(state, contact);
    const { x, z } = CITY_ENTRANCES[`${ground}-entry`];
    const distance = player ? ` · ${Math.round(Math.hypot(x - player.camera.position.x, z - player.camera.position.z))} m away` : '';
    return recordCard(npc.name, `${npc.role} · ${building}${distance}`, title);
  }).join('')}</div>`;
}

function showLoans() {
  const offers = Object.entries(access).map(([id, actionIDs]) => {
    const npc = getNPC(state, id);
    return npc.actions.filter((action) => actionIDs.includes(action.id)).map((action) => recordCard(action.label, [action.detail, action.reason].filter(Boolean).join(' · '), action.disabled ? 'Locked' : 'Available', action.disabled ? 'active' : 'available')).join('');
  }).join('');
  const debt = state.debts.map((entry) => recordCard(entry.lender, `${dollars(entry.balance)} due on Day ${entry.dueDay}`, 'Outstanding', 'active')).join('');
  return `<p>Visit your lender in the district to borrow, repay a balance, or buy property.</p><div class="cards">${debt}${offers}</div>`;
}

function showMarket() {
  const report = state.event ? recordCard(state.event.name, state.event.description, `Day ${state.event.day}`) : '';
  const logs = state.history.slice(0, 10).map((item) => recordCard(item.title, item.detail, `Day ${item.day}`)).join('');
  const record = state.record.length ? `<h3>Permanent record</h3><div class="cards">${state.record.map((item) => recordCard(item.title, item.detail, `Day ${item.day}`, 'active')).join('')}</div>` : '';
  return `<div class="cards">${report}${logs}</div>${record}`;
}

function showMap() {
  const expanded = roomId() === 'district';
  const canTrack = expanded && !afterHours && !state.ending;
  const landmarks = currentLandmarks();
  function label(landmark) {
    const detail = missionContacts[landmark.id] || venueDescriptions[landmark.id];
    const text = `<i style="--contact-color:${landmark.color}" aria-hidden="true"></i><span><strong>${escapeHTML(landmark.label)}</strong>${detail ? `<small>${escapeHTML(detail)}</small>` : ''}</span>`;
    if (!canTrack) return `<div>${text}</div>`;
    return `<button type="button" data-track="${landmark.id}" aria-pressed="${trackedId === landmark.id}">${text}</button>`;
  }
  const labels = canTrack
    ? ` <h3>Mission buildings</h3>${landmarks.filter(({ id }) => missionContacts[id]).map(label).join('')}<h3>Other destinations</h3>${landmarks.filter(({ id }) => !missionContacts[id]).map(label).join('')}`
    : landmarks.map(label).join('');
  const map = `<canvas class="dialog-map" id="dialog-map" width="320" height="${expanded ? 400 : 300}" aria-label="${rooms[roomId()].name} map and player position"></canvas>`;
  return `<div class="map-layout">${map}<div class="map-legend">${canTrack ? '<p>Select a destination to track it.</p>' : ''}${labels}</div></div>`;
}

function renderPhone() {
  const content = { Portfolio: showPortfolio, Contacts: showContacts, Loans: showLoans, Market: showMarket, Map: showMap }[phoneTab]();
  const tabs = gameTabs.map((tab) => `<button type="button" data-tab="${tab}" aria-pressed="${phoneTab === tab}">${tab}</button>`).join('');
  return `${dialogHeader(`Day ${pad(state.day)} · ${state.seed}`, 'Venture phone')}<div class="phone-tabs" aria-label="Phone sections">${tabs}</div><div class="modal-body">${content}${note()}</div><div class="phone-footer"><small>${state.ending ? 'Run complete' : 'A close advances investments and the market.'}</small><button type="button" class="primary" data-action="advance" ${state.ending ? 'disabled' : ''}>Close market day <kbd>N</kbd></button></div>`;
}

function renderPause() {
  const releaseLinks = import.meta.env.VITE_RELEASE_DOWNLOADS === '1' && /^https?:$/.test(location.protocol) && !location.pathname.endsWith('Aftermarket.html') ? '<div class="downloads"><a href="./aftermarket-offline.zip" download>Offline game</a><a href="./aftermarket-source.zip" download>Editable source</a></div>' : '';
  const share = /^https?:$/.test(location.protocol) ? '<button type="button" class="secondary" data-command="share">Copy seed link</button>' : '';
  const playLabel = state.ending && !afterHours ? 'View outcome' : entered ? 'Resume' : 'Enter district';
  const report = afterHours ? '<button type="button" class="secondary" data-command="report">Closing report</button>' : '';
  const motionLabel = motionIsReduced() ? 'Enable motion' : 'Reduce motion';
  return `${dialogHeader(rooms[roomId()].name, entered ? 'Game paused' : 'Game settings')}<div class="modal-body"><p>Progress saves in this browser. A seed repeats the deal sequence and market events.</p><div class="inline-actions"><button type="button" class="primary" data-command="resume">${playLabel}</button>${report}<button type="button" class="secondary" data-command="sound">${muted ? 'Enable sound' : 'Mute sound'}</button><button type="button" class="secondary" data-command="motion">${motionLabel}</button><button type="button" class="secondary" data-command="reset">New run</button>${share}</div><p class="pause-info">SEED ${escapeHTML(state.seed)} · LOOK WITH MOUSE DRAG OR ARROW KEYS</p>${releaseLinks}${note()}</div>`;
}

function renderGuide() {
  let title = 'Find your first paid gig';
  let tip = 'Look for the amber Foundry sign on the left side of the avenue. Enter with E, then take the stairs to Mara Voss in the Pitch Lab.';
  if (afterHours) {
    title = insideChamber() ? society.choice ? 'Find the return lift' : 'Take your seat' : 'Find the private lift';
    tip = insideChamber()
      ? society.choice ? 'The return lift is beside the entrance. Turn around and follow the marker.' : 'Walk down the center aisle to the Council and press E.'
      : roomId() === 'exchange' ? 'Walk through the lobby to the gold-marked lift and press E.' : 'Head to the Exchange straight down the avenue. The private lift is inside the lobby.';
  } else if (state.ending) {
    title = 'Review your run';
    tip = 'Your phone keeps the final portfolio and the market history. Start a new run from Settings to try a different route.';
  } else if (rooms[roomId()].tip) {
    title = rooms[roomId()].name;
    tip = rooms[roomId()].tip;
  } else if (state.heat >= 45) {
    title = 'Keep an eye on Heat';
    tip = 'At 100 Heat the run ends. Talk to Ellis Vale at Meridian Bank about a compliance disclosure, or see Ivo Rook at the Night Window.';
  } else if (state.portfolio.length) {
    title = 'Check your maturity dates';
    tip = 'Check venture dates in your portfolio. For a second income stream, visit the Exchange Auction House and bid on a rental property.';
  } else if (state.gigDay || state.cash) {
    title = 'Read the term sheet';
    tip = 'Ask Mara about the next venture, review its books, or type a cash and equity offer of your own.';
  }
  return `${dialogHeader('Field guide', 'Ticker')}<div class="modal-body guide-profile"><img src="${tickerArt}" alt="Ticker, a raccoon in a trader vest"><div class="guide-copy"><h3>${title}</h3><p>${tip}</p><button type="button" class="secondary" data-command="map">Open map</button></div></div>`;
}

async function copySeed() {
  const url = new URL(location.href);
  url.searchParams.set('seed', state.seed);
  try {
    await navigator.clipboard.writeText(url.href);
    modalNote = 'Seed link copied.';
  } catch {
    modalNote = url.href;
  }
  if (dialog === 'pause') { renderDialog(); modal.focus(); }
}

function renderReset() {
  return `${dialogHeader('Start over', 'New run')}<div class="modal-body"><p>This replaces the current local save. Reuse the seed to replay the same market, or enter a different one.</p><form id="reset-form" class="negotiation"><label for="new-seed">Market seed</label><div class="form-row"><input name="seed" id="new-seed" required maxlength="32" value="${escapeHTML(state.seed)}"><button class="primary" type="submit">Start new run</button></div></form></div>`;
}

function renderEnding() {
  const outcome = state.ending;
  const wire = society ? `<aside class="society-wire">${ledgerSeal()}<div><h3>${society.choice ? escapeHTML(society.choice.title) : 'A sealed invitation'}</h3><p>${society.choice ? 'Your decision has been entered in the Ledger.' : 'There’s an envelope waiting under the closing report.'}</p></div><button class="society-button" type="button" data-command="${society.choice ? 'legacy' : 'invitation'}">${society.choice ? 'Read epilogue' : 'Open invitation'}</button></aside>` : '';
  return `${dialogHeader('Closing report', outcome.title)}<div class="modal-body"><p>${escapeHTML(outcome.description)}</p><div class="phone-summary"><span>NET WORTH <b>${dollars(netWorth(state))}</b></span><span>REPUTATION <b>${state.reputation}</b></span><span>HEAT <b>${state.heat}</b></span></div>${wire}<div class="inline-actions"><button class="${society ? 'secondary' : 'primary'}" type="button" data-command="reset">New run</button><button class="secondary" type="button" data-command="portfolio">Review portfolio</button></div></div>`;
}

function ledgerSeal() {
  return '<span class="ledger-seal" aria-hidden="true"><i></i><i></i><i></i></span>';
}

function renderInvitation() {
  return `${dialogHeader('Private correspondence', society.title)}<div class="modal-body"><div class="ledger-letter">${ledgerSeal()}<p>There is a seat in the city that never appears on an org chart. We noticed your final close. Enter Meridian Exchange and take the private lift from the lobby. The Council will receive you there.</p></div><div class="inline-actions"><button type="button" class="society-button" data-command="follow-invitation" ${player ? '' : 'disabled'}>Follow the invitation</button><button type="button" class="secondary" data-command="report">Closing report</button></div></div>`;
}

function renderCouncil() {
  if (society.choice) return renderLegacy();
  const choices = society.actions.map((choice) => `<button type="button" class="action" data-command="vote" data-choice="${escapeHTML(choice.id)}"><strong>${escapeHTML(choice.label)}</strong><small>${escapeHTML(choice.detail)}</small></button>`).join('');
  return `${dialogHeader('Private chamber', 'The Council')}<div class="modal-body"><div class="ledger-letter">${ledgerSeal()}<p>${escapeHTML(society.line)}</p></div><div class="action-list ledger-options">${choices}</div></div>`;
}

function renderVote() {
  const { id, label, detail } = pendingChoice;
  return `${dialogHeader('Decision for the record', label)}<div class="modal-body"><p>${escapeHTML(detail)}</p><p class="ledger-caveat">The Ledger records one final decision per run.</p><div class="inline-actions"><button type="button" class="society-button" data-action="${escapeHTML(id)}">Confirm decision</button><button type="button" class="secondary" data-command="council">Return to the Council</button></div>${note()}</div>`;
}

function renderLegacy() {
  const choice = society.choice;
  return `${dialogHeader('The Quiet Ledger · Epilogue', choice.title)}<div class="modal-body"><div class="ledger-letter">${ledgerSeal()}<p>${escapeHTML(choice.description)}</p></div><div class="inline-actions"><button type="button" class="society-button" data-command="${insideChamber() ? 'close' : 'report'}">${insideChamber() ? 'Return to chamber' : 'Closing report'}</button>${insideChamber() ? '' : `<button type="button" class="secondary" data-command="follow-invitation" ${player ? '' : 'disabled'}>Visit the Exchange</button>`}</div>${note()}</div>`;
}

function renderAuction() {
  const { lot, status, leader, amount, nextBid, canBid, bids } = getAuction(state);
  const open = status === 'open';
  const bidLabel = leader ? `Current bid · ${leader}` : 'Opening bid';
  const summary = `<div class="venue-summary"><span>${escapeHTML(bidLabel)}<b>${dollars(amount)}</b></span><span>Estimated value<b>${dollars(lot.value)}</b></span><span>Rent per close<b>${dollars(lot.income)}</b></span></div>`;
  const controls = open ? `<div class="inline-actions"><button type="button" class="primary" data-action="auction:bid" ${canBid ? '' : 'disabled'}>Bid ${dollars(nextBid)}</button><button type="button" class="secondary" data-action="auction:pass">Pass on this lot</button></div>` : `<p class="venue-result">${status === 'won' ? 'You won this lot. It’s listed in your portfolio.' : `${escapeHTML(leader)} won this lot.`}${state.day < FINAL_DAY ? ' A new lot opens on the next market day.' : ''}</p>`;
  const activity = bids.length ? `<ul class="bid-history" aria-label="Recent bids">${bids.slice(-4).reverse().map(({ bidder, amount: offer }) => `<li><span>${escapeHTML(bidder)}</span><strong>${dollars(offer)}</strong></li>`).join('')}</ul>` : '';
  return `${dialogHeader(`Exchange Auction House · Day ${pad(state.day)}`, lot.name)}<div class="modal-body"><p>${escapeHTML(lot.description)}</p>${summary}${open ? `<p class="venue-cash">Cash on hand <strong>${dollars(state.cash)}</strong>${canBid ? ' · You pay only if you win.' : ' · The next bid exceeds your cash.'}</p>` : ''}${controls}${note()}${activity}</div>`;
}

function renderFurniture() {
  const furniture = getFurniture(state).map((item) => {
    const action = item.owned ? 'install' : 'buy';
    const label = item.installed ? 'Installed' : item.owned ? 'Install' : `Buy · ${dollars(item.price)}`;
    return `<article class="showroom-item"><div><h3>${escapeHTML(item.name)}</h3><p>${escapeHTML(item.description)}</p></div><button type="button" class="secondary" data-action="furniture:${action}:${item.id}" aria-label="${escapeHTML(`${label} ${item.name}`)}" ${item.installed || (!item.owned && !item.affordable) ? 'disabled' : ''}>${escapeHTML(label)}</button></article>`;
  }).join('');
  return `${dialogHeader('Penthouse furnishings', 'Form & Grain')}<div class="modal-body"><p>Purchases appear in your Crownline penthouse. You can switch between pieces you own.</p><p class="venue-cash">Cash on hand <strong>${dollars(state.cash)}</strong></p><div class="showroom-grid">${furniture}</div>${note()}</div>`;
}

function renderDialog() {
  const render = { contact: renderContact, phone: renderPhone, pause: renderPause, reset: renderReset, ending: renderEnding, guide: renderGuide, invitation: renderInvitation, council: renderCouncil, vote: renderVote, legacy: renderLegacy, auction: renderAuction, furniture: renderFurniture }[dialog];
  if (!render) return;
  modal.dataset.mode = dialog;
  modal.dataset.contact = dialog === 'contact' ? contact : '';
  modal.innerHTML = render();
  if (dialog === 'phone' && phoneTab === 'Map' && player) drawMap($('dialog-map'), player.camera, currentYaw, currentLandmarks(), true);
}

function applyAction(id, text) {
  if (id === 'advance' && state.ending) return;
  const choosingLegacy = id.startsWith('society:');
  if (choosingLegacy && (!insideChamber() || pendingChoice?.id !== id)) return;
  const before = state.event;
  const result = perform(state, { id, npc: contact, text });
  let didSave = true;
  if (result.ok) {
    didSave = saveGame(state);
    if (id.startsWith('furniture:')) player?.setFurniture(getFurnishingIds(state));
    refreshHUD();
  }
  beep(result.ok);
  if (choosingLegacy) {
    if (result.ok) {
      openDialog('legacy');
      if (!didSave) {
        modalNote = 'Browser storage is unavailable.';
        renderDialog();
      }
      return;
    }
    modalNote = result.message;
    modalError = !result.ok;
    renderDialog();
    return;
  }
  if (state.ending) return openDialog('ending');
  const newEvent = state.event && state.event !== before ? ` ${state.event.name}. ${state.event.description}` : '';
  const message = `${result.message}${didSave ? '' : ' Browser storage is unavailable.'}${newEvent}`;
  if (dialog) {
    modalNote = message;
    modalError = !result.ok;
    if (newEvent && dialog === 'phone') phoneTab = 'Market';
    const focusedAction = document.activeElement?.dataset.action;
    renderDialog();
    const nextTarget = focusedAction && Array.from(modal.querySelectorAll('[data-action]')).find((button) => button.dataset.action === focusedAction && !button.disabled);
    (nextTarget || modal).focus({ preventScroll: true });
  } else {
    status(message, !result.ok);
  }
}

let currentYaw = 0;
let mapLastDraw = -Infinity;

function currentLandmarks(landmarks = player?.landmarks || []) {
  return afterHours && roomId() === 'district' ? [CITY_ENTRANCES['exchange-entry']] : landmarks;
}

function drawMap(canvas, camera, yaw, landmarks, large = false) {
  if (!canvas || !player) return;
  const ctx = canvas.getContext('2d');
  const { width, height } = canvas;
  const { minX, maxX, minZ, maxZ } = player.bounds;
  const city = roomId() === 'district';
  const local = city && !large;
  const scale = local ? height / 37 : Math.min((width - 28) / (maxX - minX), (height - 34) / (maxZ - minZ));
  const centerX = local ? camera.position.x : (minX + maxX) / 2;
  const centerZ = local ? camera.position.z : (minZ + maxZ) / 2;
  const x = (value) => width / 2 + (value - centerX) * scale;
  const y = (value) => height / 2 + (value - centerZ) * scale;
  const rect = ([left, front, right, back]) => ctx.fillRect(x(left), y(front), (right - left) * scale, (back - front) * scale);
  ctx.fillStyle = '#101a17';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = insideChamber() ? '#3a392b' : '#1b2d24';
  rect([minX, minZ, maxX, maxZ]);
  ctx.strokeStyle = '#87a38d1f';
  const grid = city ? 5 : 2;
  ctx.save();
  ctx.beginPath();
  ctx.rect(x(minX), y(minZ), (maxX - minX) * scale, (maxZ - minZ) * scale);
  ctx.clip();
  for (let col = Math.ceil(minX / grid) * grid; col < maxX; col += grid) {
    ctx.beginPath(); ctx.moveTo(x(col), y(minZ)); ctx.lineTo(x(col), y(maxZ)); ctx.stroke();
  }
  for (let row = Math.ceil(minZ / grid) * grid; row < maxZ; row += grid) {
    ctx.beginPath(); ctx.moveTo(x(minX), y(row)); ctx.lineTo(x(maxX), y(row)); ctx.stroke();
  }
  const { roads = [], blocks = [] } = player.mapFeatures || {};
  ctx.fillStyle = '#31483b';
  roads.forEach(rect);
  ctx.fillStyle = insideChamber() ? '#725f3c' : '#526657';
  blocks.forEach(rect);
  if (city && large) {
    ctx.font = '600 11px monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#18261f';
    ctx.fillStyle = '#b6ccb0';
    for (const neighborhood of CITY_NEIGHBORHOODS) {
      const name = neighborhood.name.toUpperCase();
      ctx.strokeText(name, x(neighborhood.x), y(neighborhood.z));
      ctx.fillText(name, x(neighborhood.x), y(neighborhood.z));
    }
  }
  ctx.restore();
  if (large) {
    ctx.strokeStyle = '#829c8290';
    ctx.strokeRect(x(minX), y(minZ), (maxX - minX) * scale, (maxZ - minZ) * scale);
    ctx.fillStyle = '#d4e3d4';
    ctx.font = '13px monospace';
    ctx.fillText('N ↑', 9, 17);
  }
  for (const landmark of landmarks) {
    const px = x(landmark.x);
    const py = y(landmark.z);
    if (city && landmark.id === (afterHours ? 'exchange-entry' : trackedId)) {
      ctx.strokeStyle = '#eaf4d4';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(px, py, 9, 0, 2 * Math.PI); ctx.stroke();
    }
    ctx.fillStyle = landmark.color;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(Math.PI / 4);
    ctx.fillRect(-4.4, -4.4, 8.8, 8.8);
    ctx.restore();
  }
  ctx.save();
  ctx.translate(x(camera.position.x), y(camera.position.z));
  ctx.rotate(-yaw);
  ctx.fillStyle = '#f3ffdf';
  ctx.strokeStyle = '#101a17';
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(0, -9); ctx.lineTo(6, 6); ctx.lineTo(0, 3); ctx.lineTo(-6, 6); ctx.closePath(); ctx.stroke(); ctx.fill();
  ctx.restore();
}

function showTracking(camera, yaw, tracked) {
  const target = $('navigation-target');
  target.hidden = !playing || !tracked;
  if (target.hidden) return;
  const dx = tracked.x - camera.position.x;
  const dz = tracked.z - camera.position.z;
  const angle = Math.atan2(dx, -dz) + yaw;
  target.firstChild.style.transform = `rotate(${angle}rad)`;
  const description = `${tracked.label} · ${Math.round(Math.hypot(dx, dz))} m`;
  if (target.lastChild.textContent !== description) target.lastChild.textContent = description;
}

function frame(camera, yaw, worldLandmarks) {
  const landmarks = currentLandmarks(worldLandmarks);
  const isDistrict = roomId() === 'district';
  const tracked = isDistrict && landmarks.find(({ id }) => id === (afterHours ? 'exchange-entry' : trackedId));
  currentYaw = yaw;
  nearest = null;
  let nearestDistance = 2.8;
  const height = stage.clientHeight;
  for (const [id, marker] of markers) {
    if (!landmarks.some((landmark) => landmark.id === id)) marker.hidden = true;
  }
  for (const landmark of landmarks) {
    const distance = Math.hypot(landmark.x - camera.position.x, landmark.z - camera.position.z);
    if (distance <= nearestDistance) { nearestDistance = distance; nearest = landmark; }
    let marker = markers.get(landmark.id);
    if (!marker) {
      marker = document.createElement('span');
      marker.className = 'waypoint';
      marker.style.setProperty('--contact-color', landmark.color);
      marker.append(landmark.label, document.createElement('small'));
      markers.set(landmark.id, marker);
      $('waypoints').append(marker);
    }
    const selected = tracked?.id === landmark.id;
    marker.dataset.tracked = selected;
    point.set(landmark.x, landmark.y ?? (isDistrict ? 2.5 : 2.08), landmark.z).project(camera);
    const visible = point.z > -1 && point.z < 1 && Math.abs(point.x) < .89 && Math.abs(point.y) < .84 && distance < (selected ? 84 : isDistrict ? 40 : 24);
    marker.hidden = !visible || (playing && distance < 2.8);
    if (!marker.hidden) {
      marker.style.setProperty('--waypoint-x', `${(point.x + 1) * 50}%`);
      marker.style.top = `${(1 - point.y) * height / 2}px`;
      const text = `${Math.round(distance)} m`;
      if (marker.lastChild.textContent !== text) marker.lastChild.textContent = text;
    }
  }
  $('interact').hidden = !playing || !nearest;
  if (playing && nearest) {
    $('interact-label').textContent = nearest.id === 'exchange-lift' && afterHours ? 'Take the private lift' : doors[nearest.id]?.label || interactionLabels[nearest.id] || `Talk to ${contactNames[nearest.id]}`;
  }
  if (performance.now() - mapLastDraw < 65) return;
  mapLastDraw = performance.now();
  showTracking(camera, yaw, tracked);
  const directions = ['N', 'NW', 'W', 'SW', 'S', 'SE', 'E', 'NE'];
  const quadrant = ((Math.round(yaw / (Math.PI / 4)) % 8) + 8) % 8;
  $('compass').textContent = directions[quadrant];
  drawMap(mapCanvas, camera, yaw, landmarks);
}

function interact() {
  if (!playing) return;
  if (!nearest) return status(rooms[roomId()].tip || (insideChamber() ? 'Move up to the Council or return lift.' : afterHours ? 'Follow the lift waypoint, then press E when you reach it.' : 'Walk up to a contact or marked entrance.'));
  const door = doors[nearest.id];
  if (door) {
    if (door.exit) player.leaveInterior(door.exit);
    else player.enterInterior(door.room, door.fromElevator);
    return refreshRoom();
  }
  if (nearest.id === 'exchange-lift') return afterHours ? changeRoom(true) : status('An invitation from the Quiet Ledger opens this lift.');
  if (nearest.id === 'chamber-exit') return changeRoom(false);
  if (nearest.id === 'council') return openDialog('council');
  if (nearest.id === 'exchange-wire') return openDialog('phone', 'Market');
  if (nearest.id === 'auction-podium') return openDialog('auction');
  if (nearest.id === 'furniture-counter') return openDialog('furniture');
  if (nearest.id === 'apartment-desk') return openDialog('phone', 'Portfolio');
  if (contactNames[nearest.id]) openDialog('contact', nearest.id);
}

function followInvitation() {
  if (!society || !player) return;
  if (!['district', 'exchange', 'chamber'].includes(roomId())) player.reset();
  afterHours = true;
  nearest = null;
  closeDialog();
  refreshHUD();
  enter();
}

function changeRoom(toChamber) {
  if (!afterHours || !society || !player) return;
  if (toChamber) player.enterChamber();
  else player.leaveChamber();
  refreshRoom();
  status(toChamber ? 'The Quiet Ledger. The return lift is behind you.' : 'Returned to the Exchange lobby.');
}

function refreshRoom() {
  nearest = null;
  $('interact').hidden = true;
  $('navigation-target').hidden = true;
  $('toast').hidden = true;
  mapLastDraw = -Infinity;
  refreshHUD();
  beep();
}

$('start-button').addEventListener('click', () => enter());
$('interact').addEventListener('click', interact);
$('ticker-button').addEventListener('click', () => openDialog('guide'));
$('phone-button').addEventListener('click', () => openDialog('phone', 'Portfolio'));
$('map-button').addEventListener('click', () => openDialog('phone', 'Map'));
$('settings-button').addEventListener('click', () => dialog === 'pause' ? closeDialog() : openDialog('pause'));
$('mute-button').addEventListener('click', toggleSound);
touch.addEventListener('change', () => refreshControlState());
motionMedia.addEventListener('change', () => {
  refreshMotion();
  if (dialog === 'pause') renderDialog();
});
layer.addEventListener('click', (event) => { if (event.target === layer) closeDialog(true); });

modal.addEventListener('click', (event) => {
  const button = event.target.closest('button');
  if (!button) return;
  if (button.dataset.track) {
    trackedId = trackedId === button.dataset.track ? null : button.dataset.track;
    mapLastDraw = -Infinity;
    if (entered && !state.ending) closeDialog(true);
    else {
      renderDialog();
      modal.querySelector(`[data-track="${button.dataset.track}"]`)?.focus();
    }
    return;
  }
  if (button.dataset.tab) {
    phoneTab = button.dataset.tab;
    modalNote = '';
    renderDialog();
    modal.querySelector('[aria-pressed="true"]')?.focus({ preventScroll: true });
  }
  if (button.dataset.action) applyAction(button.dataset.action);
  switch (button.dataset.command) {
    case 'close': closeDialog(true); break;
    case 'resume': closeDialog(); enter(); break;
    case 'sound': toggleSound(); modal.focus(); break;
    case 'motion': toggleMotion(); break;
    case 'reset': openDialog('reset'); $('new-seed').focus(); break;
    case 'share': copySeed(); break;
    case 'map': openDialog('phone', 'Map'); break;
    case 'portfolio': openDialog('phone', 'Portfolio'); break;
    case 'report': openDialog('ending'); break;
    case 'invitation': if (society) openDialog('invitation'); break;
    case 'legacy': if (society?.choice) openDialog('legacy'); break;
    case 'follow-invitation': followInvitation(); break;
    case 'council': if (insideChamber()) openDialog('council'); break;
    case 'vote':
      if (insideChamber() && society?.actions.some((choice) => choice.id === button.dataset.choice)) openDialog('vote', button.dataset.choice);
      break;
  }
});

modal.addEventListener('submit', (event) => {
  event.preventDefault();
  const fields = new FormData(event.target);
  if (event.target.id === 'negotiate-form') applyAction('negotiate', fields.get('terms'));
  if (event.target.id === 'reset-form') {
    state = createGame(fields.get('seed'));
    if (location.protocol !== 'file:') {
      const url = new URL(location.href);
      url.searchParams.set('seed', state.seed);
      history.replaceState(null, '', url);
    }
    const didSave = saveGame(state);
    entered = false;
    afterHours = false;
    trackedId = null;
    nearest = null;
    player?.reset();
    player?.setFurniture(getFurnishingIds(state));
    closeDialog();
    refreshHUD();
    if (!didSave) status('Browser storage is unavailable.', true);
  }
});

window.addEventListener('keydown', (event) => {
  const { code } = event;
  const typing = event.target instanceof HTMLInputElement;
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  if (code === 'Escape') {
    event.preventDefault();
    if (dialog) closeDialog();
    else openDialog('pause');
    return;
  }
  if (dialog && code === 'Tab') {
    const controls = Array.from(modal.querySelectorAll('button:not(:disabled), input, a[href]'));
    const first = controls[0];
    const last = controls.at(-1);
    if (event.shiftKey && (document.activeElement === first || document.activeElement === modal)) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    return;
  }
  if (typing || event.repeat) return;
  if (code === 'KeyM') return toggleSound();
  if (code === 'KeyH' && (!dialog || dialog === 'guide')) {
    if (dialog === 'guide') closeDialog(true);
    else openDialog('guide');
    return;
  }
  if (!dialog && playing && player?.setKey(code, true)) { event.preventDefault(); return; }
  if (code === 'KeyP' || (code === 'Tab' && playing && !event.shiftKey && document.activeElement === worldCanvas)) {
    event.preventDefault();
    if (dialog === 'phone') closeDialog();
    else openDialog('phone');
  } else if (code === 'KeyE' && !dialog) {
    interact();
  } else if (code === 'KeyN' && (dialog === 'phone' || playing)) {
    applyAction('advance');
  }
});
window.addEventListener('keyup', (event) => player?.setKey(event.code, false));
for (const button of $('touch-controls').querySelectorAll('button')) {
  button.addEventListener('pointerdown', (event) => {
    button.setPointerCapture(event.pointerId);
    event.preventDefault();
    player?.setKey(button.dataset.key, true);
  });
  for (const action of ['pointerup', 'pointercancel', 'lostpointercapture']) {
    button.addEventListener(action, () => player?.setKey(button.dataset.key, false));
  }
}

try {
  player = createPlayer(worldCanvas, frame, () => { if (!dialog && playing) openDialog('pause'); }, motionIsReduced());
  player.setFurniture(getFurnishingIds(state));
} catch (error) {
  console.error('Could not initialize the district.', error);
  $('fallback').hidden = false;
}
refreshHUD();
refreshControlState();
updateSoundLabel();
refreshMotion();
