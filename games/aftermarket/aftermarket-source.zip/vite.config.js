import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: { assetsInlineLimit: 80000, cssCodeSplit: false, modulePreload: false, chunkSizeWarningLimit: 1000 },
});
