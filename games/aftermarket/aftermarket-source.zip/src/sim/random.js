// Derive independent random streams so viewing a pitch never changes an outcome.
export function randomFor(seed, ...labels) {
  let hash = 2166136261
  for (const character of JSON.stringify([seed, ...labels])) {
    hash = Math.imul(hash ^ character.codePointAt(0), 16777619)
  }
  return () => {
    hash = (hash + 0x6d2b79f5) | 0
    let bits = Math.imul(hash ^ (hash >>> 15), hash | 1)
    bits = (bits + Math.imul(bits ^ (bits >>> 7), bits | 61)) ^ bits
    return ((bits ^ (bits >>> 14)) >>> 0) / 4294967296
  }
}

export function pick(items, random) {
  return items[Math.floor(random() * items.length)]
}

export function shuffled(items, random) {
  const order = [...items]
  for (let index = order.length - 1; index > 0; index--) {
    const other = Math.floor(random() * (index + 1))
    const current = order[index]
    order[index] = order[other]
    order[other] = current
  }
  return order
}

export function normalizeSeed(seed) {
  const value = String(seed ?? '').trim().slice(0, 48)
  if (value) return value
  const bytes = new Uint32Array(1)
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes)
  else bytes[0] = Date.now()
  return bytes[0].toString(36).padStart(6, '0').toUpperCase()
}
