import * as THREE from 'three';
import { createWorld } from './world.js';
import { createChamber } from './world-chamber.js';
import { createInterior } from './world-interiors.js';
import { createMissionInterior } from './world-missions.js';
import { createExchange } from './world-exchange.js';
import { CITY_BOUNDS, CITY_ENTRANCES, CITY_MAP } from './district.js';

const spawn = new THREE.Vector3(0, 1.68, 11);
const chamberSpawn = new THREE.Vector3(0, 1.68, 8);
const chamberBounds = { minX: -6.9, maxX: 6.9, minZ: -14.85, maxZ: 10.77 };
const movementKeys = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ShiftLeft', 'ShiftRight', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown']);

export function createPlayer(canvas, onFrame, onUnlock, reducedMotion = false) {
  const cityScene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(69, 1, .07, 180);
  camera.rotation.order = 'YXZ';
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.32;
  const targetRatio = Math.min(window.devicePixelRatio || 1, 1.5);
  let pixelRatio = targetRatio;
  renderer.setPixelRatio(pixelRatio);
  const district = { id: 'district', scene: cityScene, world: createWorld(cityScene, { reducedMotion }) };
  let active = district;
  let chamber;
  const interiors = new Map();
  let furnishings = [];
  const keys = new Set();
  let yaw = 0;
  let pitch = 0;
  let playing = false;
  let lastTime = 0;
  let elapsed = 0;
  let frames = 0;
  let frameWindow = 0;
  let drag = null;
  let pointerWasLocked = false;
  let ignoreUnlock = false;

  function place(position, heading = 0) {
    keys.clear();
    camera.position.copy(position);
    yaw = heading;
    pitch = .04;
    camera.rotation.set(pitch, yaw, 0);
  }

  function reset() {
    active = district;
    place(spawn);
  }

  function enterChamber() {
    if (!chamber) {
      const scene = new THREE.Scene();
      chamber = { id: 'chamber', scene, world: createChamber(scene, { reducedMotion }) };
    }
    active = chamber;
    place(chamberSpawn);
  }

  function leaveChamber() {
    enterInterior('exchange', true);
  }

  function enterInterior(id, fromElevator = false) {
    if (!interiors.has(id)) {
      const scene = new THREE.Scene();
      const settings = { reducedMotion };
      const world = id === 'exchange' ? createExchange(scene, settings) : createMissionInterior(scene, id, settings) || createInterior(scene, id, settings);
      interiors.set(id, { id, scene, world });
    }
    active = interiors.get(id);
    if (id === 'apartment') active.world.setFurniture(furnishings);
    const arrival = fromElevator ? active.world.elevatorArrival : null;
    const position = arrival ? new THREE.Vector3(arrival.x, 1.68, arrival.z) : active.world.spawn;
    place(position, arrival?.yaw ?? active.world.yaw);
  }

  function leaveInterior(entryId) {
    const { returnX, returnZ, returnYaw } = CITY_ENTRANCES[entryId];
    active = district;
    place(new THREE.Vector3(returnX, 1.68, returnZ), returnYaw);
  }

  function setFurniture(ids) {
    furnishings = ids;
    interiors.get('apartment')?.world.setFurniture(ids);
  }

  function setReducedMotion(enabled) {
    reducedMotion = enabled;
    district.world.setReducedMotion(enabled);
    chamber?.world.setReducedMotion(enabled);
    for (const interior of interiors.values()) interior.world.setReducedMotion(enabled);
  }

  function look(dx, dy) {
    yaw -= dx * .0026;
    pitch = THREE.MathUtils.clamp(pitch - dy * .0026, -1.22, 1.2);
    camera.rotation.set(pitch, yaw, 0);
  }

  function resize() {
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.fov = width / height < .9 ? 77 : 69;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
  }

  function capture() {
    if (!canvas.requestPointerLock || matchMedia('(pointer: coarse)').matches) return;
    try {
      const result = canvas.requestPointerLock();
      if (result?.catch) result.catch(() => {});
    } catch {
      // Drag and arrow keys remain available when pointer lock is denied.
    }
  }

  function setPlaying(next, lock = false) {
    if (!next && document.pointerLockElement === canvas) {
      ignoreUnlock = true;
      document.exitPointerLock();
    }
    playing = next;
    keys.clear();
    if (next && lock) capture();
  }

  function setKey(code, down) {
    if (!movementKeys.has(code)) return false;
    if (down && playing) keys.add(code);
    else keys.delete(code);
    return true;
  }

  document.addEventListener('pointerlockchange', () => {
    const locked = document.pointerLockElement === canvas;
    if (!locked && pointerWasLocked) {
      if (!ignoreUnlock && playing) onUnlock();
      ignoreUnlock = false;
    }
    pointerWasLocked = locked;
  });
  document.addEventListener('mousemove', (event) => {
    if (playing && document.pointerLockElement === canvas) look(event.movementX, event.movementY);
  });
  window.addEventListener('blur', () => keys.clear());
  canvas.addEventListener('pointerdown', (event) => {
    if (!playing || document.pointerLockElement === canvas) return;
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY, moved: false };
    canvas.setPointerCapture(event.pointerId);
  });
  canvas.addEventListener('pointermove', (event) => {
    if (!playing || drag?.id !== event.pointerId || document.pointerLockElement === canvas) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    drag.moved ||= Math.abs(dx) + Math.abs(dy) > 2;
    drag.x = event.clientX;
    drag.y = event.clientY;
    look(dx, dy);
  });
  canvas.addEventListener('pointerup', (event) => {
    if (drag?.id === event.pointerId && !drag.moved && event.pointerType === 'mouse' && playing) capture();
    drag = null;
  });
  canvas.addEventListener('pointercancel', () => { drag = null; });

  function step(seconds) {
    const forward = Number(keys.has('KeyW')) - Number(keys.has('KeyS'));
    const strafe = Number(keys.has('KeyD')) - Number(keys.has('KeyA'));
    const turn = Number(keys.has('ArrowRight')) - Number(keys.has('ArrowLeft'));
    const tilt = Number(keys.has('ArrowDown')) - Number(keys.has('ArrowUp'));
    if (turn || tilt) look(turn * seconds * 620, tilt * seconds * 460);
    if (!forward && !strafe) return;
    const sprinting = keys.has('ShiftLeft') || keys.has('ShiftRight');
    const pace = active === district ? sprinting ? 7.7 : 4.65 : 3.55;
    const speed = pace * seconds / Math.hypot(forward, strafe);
    const dx = (Math.cos(yaw) * strafe - Math.sin(yaw) * forward) * speed;
    const dz = (-Math.sin(yaw) * strafe - Math.cos(yaw) * forward) * speed;
    const position = camera.position;
    if (!active.world.collides(position.x + dx, position.z)) position.x += dx;
    if (!active.world.collides(position.x, position.z + dz)) position.z += dz;
  }

  function draw(time) {
    const duration = lastTime ? (time - lastTime) / 1000 : 0;
    lastTime = time;
    const seconds = Math.min(.32, duration);
    if (playing && seconds) {
      // Keep each collision step short on slower graphics hardware.
      const steps = Math.ceil(seconds / .035);
      for (let i = 0; i < steps; i++) step(seconds / steps);
    }
    elapsed += seconds;
    if (duration > 0 && !document.hidden && pixelRatio > .58) {
      frames++;
      frameWindow += Math.min(.5, duration);
      if (frames >= 6) {
        if (frameWindow / frames > .055) {
          pixelRatio = Math.max(.58, pixelRatio * .77);
          renderer.setPixelRatio(pixelRatio);
        }
        frames = 0;
        frameWindow = 0;
      }
    }
    camera.updateMatrixWorld();
    active.world.update(elapsed);
    onFrame(camera, yaw, active.world.landmarks);
    renderer.render(active.scene, camera);
    requestAnimationFrame(draw);
  }

  reset();
  resize();
  new ResizeObserver(resize).observe(canvas);
  requestAnimationFrame(draw);
  return {
    setPlaying, setKey, reset, camera, setReducedMotion, enterChamber, leaveChamber,
    enterInterior, leaveInterior, setFurniture,
    get room() { return active.id; },
    get bounds() { return active === district ? CITY_BOUNDS : active === chamber ? chamberBounds : active.world.bounds; },
    get mapFeatures() {
      if (active === district) return CITY_MAP;
      if (active === chamber) return { blocks: [[-2, -11.2, 2, -4.1]] };
      return active.world.mapFeatures;
    },
    get landmarks() { return active.world.landmarks; },
  };
}
