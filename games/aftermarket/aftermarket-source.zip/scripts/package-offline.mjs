import { mkdir, readFile, realpath, writeFile } from 'node:fs/promises';
import { dirname, extname, isAbsolute, relative, resolve, sep } from 'node:path';

const assetOrigin = new URL('https://aftermarket.local/');
const mediaTypes = {
  '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.ico': 'image/x-icon',
};

const [distArg, outputPath] = process.argv.slice(2);
if (process.argv.length !== 4 || !distArg || !outputPath || !isAbsolute(outputPath) || extname(outputPath) !== '.html') {
  console.error('Usage: node scripts/package-offline.mjs <dist-directory> </absolute/path/Aftermarket.html>');
  process.exit(1);
}

const dist = await realpath(distArg);

function dataUrl(mediaType, bytes) {
  return `data:${mediaType};base64,${Buffer.from(bytes).toString('base64')}`;
}

async function readAsset(reference, parent = assetOrigin) {
  const url = new URL(reference, parent);
  if (url.origin !== assetOrigin.origin || url.search || url.hash) {
    throw new Error(`Cannot embed a nonlocal asset: ${reference}`);
  }

  const pathname = decodeURIComponent(url.pathname);
  const file = await realpath(resolve(dist, `.${pathname}`));
  const fromDist = relative(dist, file);
  if (!fromDist || fromDist === '..' || fromDist.startsWith(`..${sep}`) || isAbsolute(fromDist)) {
    throw new Error(`Asset must reside inside the build directory: ${reference}`);
  }

  const mediaType = mediaTypes[extname(file).toLowerCase()];
  if (!mediaType) throw new Error(`Unknown asset type: ${reference}`);
  return { url, mediaType, bytes: await readFile(file) };
}

function attribute(tag, name) {
  const match = tag.match(new RegExp(`\\s${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`, 'i'));
  return match?.[1] ?? match?.[2] ?? match?.[3];
}

async function inlineStyles(reference) {
  const { url, bytes } = await readAsset(reference);
  let css = bytes.toString('utf8');
  if (/@import\b/i.test(css)) throw new Error('Bundle CSS imports before packaging.');

  const links = [...css.matchAll(/url\(\s*(?:(["'])(.*?)\1|([^"'()]*))\s*\)/gi)];
  const replacement = new Map();
  for (const [match, , quoted, unquoted] of links) {
    const path = (quoted ?? unquoted).trim();
    if (!path || /^(?:data:|#)/i.test(path) || replacement.has(match)) continue;
    const asset = await readAsset(path, url);
    replacement.set(match, `url("${dataUrl(asset.mediaType, asset.bytes)}")`);
  }
  for (const [from, to] of replacement) css = css.replaceAll(from, to);
  return dataUrl('text/css', css);
}

let html = await readFile(resolve(dist, 'index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*>\s*<\/script\s*>/gi)].map(([tag]) => tag);
const entries = scripts.filter(tag => attribute(tag, 'src'));
if (entries.length !== 1 || attribute(entries[0], 'type') !== 'module') {
  throw new Error('The build must contain one JavaScript module entry.');
}

const links = [...html.matchAll(/<link\b[^>]*>/gi)];
for (const [tag] of links) {
  const href = attribute(tag, 'href');
  const relation = attribute(tag, 'rel')?.toLowerCase();
  if (!href || href.startsWith('data:')) continue;

  if (relation === 'stylesheet') {
    const media = attribute(tag, 'media');
    const mediaAttribute = media ? ` media="${media.replaceAll('"', '&quot;')}"` : '';
    html = html.replace(tag, `<link rel="stylesheet" href="${await inlineStyles(href)}"${mediaAttribute}>`);
  } else if (relation === 'icon') {
    const icon = await readAsset(href);
    html = html.replace(tag, `<link rel="icon" href="${dataUrl(icon.mediaType, icon.bytes)}">`);
  } else {
    throw new Error(`Cannot embed link with rel="${relation}": ${href}`);
  }
}
if (!links.some(([tag]) => attribute(tag, 'rel')?.toLowerCase() === 'icon')) {
  html = html.replace('</head>', '<link rel="icon" href="data:,">\n</head>');
}

const entry = await readAsset(attribute(entries[0], 'src'));
if (entry.mediaType !== 'text/javascript') throw new Error('The module entry must be JavaScript.');
// A data URL preserves JS source literally, even when a string contains an HTML end tag.
html = html.replace(entries[0], `<script type="module" src="${dataUrl(entry.mediaType, entry.bytes)}"></script>`);

const notices = (await readFile(resolve(dist, 'THIRD-PARTY-NOTICES.txt'), 'utf8')).trim().replace(/<\//g, '&lt;/');
html = html.replace('</body>', () => `<script type="text/plain" id="third-party-notices">\n${notices}\n</script>\n</body>`);

await mkdir(dirname(outputPath), { recursive: true });
await writeFile(outputPath, html);
console.log(`Packaged ${outputPath} (${(Buffer.byteLength(html) / 1024).toFixed(0)} KB)`);
