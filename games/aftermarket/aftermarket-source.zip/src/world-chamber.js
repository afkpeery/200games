import * as THREE from 'three';
import { createMissionContact } from './world-contacts.js';
import { canvasTexture, glowTexture, reflectionTexture, seeded, signTexture } from './world-textures.js';

const quarterTurn = Math.PI / 2;
const landmarks = [
  { id: 'council', label: 'The Council', x: 0, z: -2.65, color: '#e3bf80' },
  { id: 'chamber-exit', label: 'Return to Exchange', x: -4.70, z: 9.90, color: '#b4c7b8' }
];

function stoneTexture() {
  const random = seeded(4208);
  return canvasTexture(512, 512, (ctx, size) => {
    const grains = ctx.createImageData(size, size);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const i = (y * size + x) * 4;
        const cloud = Math.sin(x * .022 + Math.cos(y * .029) * 2)
          + .77 * Math.sin((x - y) * .047) + .3 * Math.sin(y * .121 + x * .023);
        const vein = Math.max(0, Math.sin((x + y * .72) * .057 + cloud * 1.7) - .985) * 540;
        const grain = (random() - .5) * 11 + cloud * 6.3 + vein;
        grains.data[i] = 52 + grain;
        grains.data[i + 1] = 68 + grain;
        grains.data[i + 2] = 61 + grain;
        grains.data[i + 3] = 255;
      }
    }
    ctx.putImageData(grains, 0, 0);
    ctx.fillStyle = '#263a34';
    ctx.strokeStyle = '#6e7d6d';
    ctx.lineWidth = 2;
    for (const y of [0, 256]) {
      ctx.fillRect(0, y, size, 4);
      ctx.fillRect(y, 0, 4, size);
      for (const x of [0, 256]) ctx.strokeRect(x + 5, y + 5, 246, 246);
    }
  }, 3, 5);
}

function walnutTexture() {
  const random = seeded(2817);
  return canvasTexture(768, 384, (ctx, w, h) => {
    const grains = ctx.createImageData(w, h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const bend = y + 11 * Math.sin(x * .014 + y * .024) + 3 * Math.sin(x * .027);
        const grain = Math.sin(bend * .171) * 8 + Math.sin(bend * .85) * 4.8
          + random() * 11 + Math.sin(y * .031) * 6;
        grains.data[i] = 69 + grain;
        grains.data[i + 1] = 50 + grain * .77;
        grains.data[i + 2] = 39 + grain * .58;
        grains.data[i + 3] = 255;
      }
    }
    ctx.putImageData(grains, 0, 0);
  });
}

function skylineTexture(seed) {
  const random = seeded(seed);
  return canvasTexture(1280, 560, (ctx, w, h) => {
    const air = ctx.createLinearGradient(0, 0, 0, h);
    air.addColorStop(0, '#172a3b');
    air.addColorStop(.56, '#334c54');
    air.addColorStop(1, '#6c7062');
    ctx.fillStyle = air;
    ctx.fillRect(0, 0, w, h);
    for (let layer = 0; layer < 3; layer++) {
      for (let x = -25; x < w + 20;) {
        const width = 23 + random() * (layer === 2 ? 99 : 68);
        const top = 122 + layer * 37 + random() * 250;
        ctx.fillStyle = ['#394f56', '#2b4147', '#1e343b'][layer];
        ctx.fillRect(x, top, width, h - top);
        ctx.fillRect(x + width * .18, top - 4 - random() * 17, width * .55, 21);
        const lit = ['#ada684', '#76928d', '#d0b583', '#517176'];
        const bay = [7, 9, 12][layer];
        for (let y = top + 13; y < h; y += bay) {
          for (let col = x + 5; col < x + width - 4; col += bay) {
            if (random() > .37) continue;
            ctx.fillStyle = lit[Math.floor(random() * lit.length)];
            ctx.globalAlpha = .21 + random() * .58;
            ctx.fillRect(col, y, bay * .37, bay * .25);
          }
        }
        ctx.globalAlpha = 1;
        if (random() > .75) {
          ctx.fillStyle = '#885e53';
          ctx.fillRect(x + width * .45, top - 20, 3, 3);
        }
        x += width + 2 + random() * 15;
      }
    }
    for (let i = 0; i < 640; i++) {
      const x = random() * w;
      const y = random() * h;
      ctx.strokeStyle = i % 5 ? 'rgba(148,180,184,.15)' : 'rgba(164,194,198,.42)';
      ctx.lineWidth = .45 + random() * 1.3;
      ctx.beginPath();
      ctx.moveTo(x, y);
      const length = 2 + random() * 30;
      ctx.lineTo(x - length * .28, y + length);
      ctx.stroke();
    }
  });
}

function fabricTexture() {
  const random = seeded(218);
  return canvasTexture(192, 192, (ctx, w, h) => {
    ctx.fillStyle = '#243e37';
    ctx.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 2) {
      for (let x = 0; x < w; x += 2) {
        ctx.fillStyle = random() > .46 ? 'rgba(199,177,126,.09)' : 'rgba(1,6,4,.18)';
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }, 2, 7);
}

function roundRectangle(halfWidth, halfDepth, radius) {
  const path = new THREE.Shape();
  path.moveTo(-halfWidth + radius, -halfDepth);
  path.lineTo(halfWidth - radius, -halfDepth);
  path.quadraticCurveTo(halfWidth, -halfDepth, halfWidth, -halfDepth + radius);
  path.lineTo(halfWidth, halfDepth - radius);
  path.quadraticCurveTo(halfWidth, halfDepth, halfWidth - radius, halfDepth);
  path.lineTo(-halfWidth + radius, halfDepth);
  path.quadraticCurveTo(-halfWidth, halfDepth, -halfWidth, halfDepth - radius);
  path.lineTo(-halfWidth, -halfDepth + radius);
  path.quadraticCurveTo(-halfWidth, -halfDepth, -halfWidth + radius, -halfDepth);
  return path;
}

export function createChamber(scene, { reducedMotion = false } = {}) {
  const palette = (color, roughness = .69, metalness = .03) =>
    new THREE.MeshStandardMaterial({ color, roughness, metalness });
  const source = (color, intensity = 1.3) => new THREE.MeshStandardMaterial({
    color, emissive: color, emissiveIntensity: intensity, roughness: .44
  });
  const rock = new THREE.MeshStandardMaterial({ map: stoneTexture(), roughness: .34, metalness: .18 });
  const darkWood = new THREE.MeshStandardMaterial({ map: walnutTexture(), roughness: .41, metalness: .06 });
  const tableWood = darkWood.clone();
  tableWood.color.setHex(0xbe947b);
  tableWood.roughness = .24;
  const carpet = new THREE.MeshStandardMaterial({ map: fabricTexture(), roughness: 1 });
  const navy = palette(0x172421);
  const deepJade = palette(0x263c34);
  const greenStone = palette(0x344e43, .36, .12);
  const warmBrass = palette(0x8c724b, .31, .49);
  const paleBrass = palette(0xb29666, .36, .33);
  const brassGlow = source(0xe6ba71, .75);
  const warmGlow = source(0xffcf89, 2.2);
  const coolGlow = source(0x8eb7ad, 1.01);
  const iron = palette(0x242b2b, .27, .55);
  const oxblood = palette(0x553c31, .67);
  const leather = palette(0x345048, .54);
  const paper = palette(0xab996f, .94);
  const reflectiveGlass = palette(0x577c6e, .24, .52);
  const blackGlass = palette(0x253c34, .28, .53);
  const unitBlock = new THREE.BoxGeometry(1, 1, 1);
  const unitPlane = new THREE.PlaneGeometry(1, 1);
  const shadow = reflectionTexture();
  const bloomMap = glowTexture();
  const transform = new THREE.Object3D();
  const groups = new Map();
  const obstacles = [];

  function box(x, y, z, width, height, depth, material, yaw = 0, roll = 0) {
    if (!groups.has(material)) groups.set(material, []);
    groups.get(material).push([x, y, z, width, height, depth, yaw, roll]);
  }

  function obstacle(x, z, width, depth) {
    obstacles.push([x - width / 2, z - depth / 2, x + width / 2, z + depth / 2]);
  }

  function panel(x, y, z, width, height, material, yaw = 0, pitch = 0) {
    const tile = new THREE.Mesh(unitPlane, material);
    tile.position.set(x, y, z);
    tile.rotation.set(pitch, yaw, 0, 'YXZ');
    tile.scale.set(width, height, 1);
    scene.add(tile);
    return tile;
  }

  function areaLight(x, y, z, color, brightness, radius) {
    const light = new THREE.PointLight(color, brightness, radius, 2);
    light.position.set(x, y, z);
    scene.add(light);
    return light;
  }

  function ornamentGlow(x, y, z, size, tint, alpha) {
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: bloomMap, color: tint, opacity: alpha, blending: THREE.AdditiveBlending,
      depthWrite: false, toneMapped: false
    }));
    halo.position.set(x, y, z);
    halo.scale.set(size, size, 1);
    scene.add(halo);
  }

  function reflectingPool(x, z, width, length, color, opacity) {
    panel(x, .019, z, width, length, new THREE.MeshBasicMaterial({
      map: shadow, color, opacity, transparent: true, blending: THREE.AdditiveBlending,
      depthWrite: false, toneMapped: false
    }), 0, -quarterTurn);
  }

  scene.background = new THREE.Color(0x172320);
  scene.fog = new THREE.Fog(0x253730, 23, 45);
  const keyLight = new THREE.DirectionalLight(0xb9c9ad, 1.20);
  keyLight.position.set(1, 4, 3);
  scene.add(new THREE.HemisphereLight(0xc1ceac, 0x534333, 1.78), keyLight);
  areaLight(0, 4.2, 4.9, 0xf8d69d, 67, 13);
  areaLight(0, 4.1, -4.8, 0xf6bd76, 69, 14);
  areaLight(-5.6, 3.3, -6.5, 0x81cbb9, 37, 10);
  areaLight(5.6, 3.2, -9.8, 0x79c5b5, 40, 13);
  const warmFocus = areaLight(0, 3.92, -13.9, 0xeac183, 46, 12);

  panel(0, 0, -2.03, 14.5, 26.5, rock, 0, -quarterTurn);
  panel(0, .017, 2.83, 3.58, 12.96, carpet, 0, -quarterTurn);
  panel(0, .016, -7.76, 7.65, 9.72, carpet, 0, -quarterTurn);
  for (const side of [-1, 1]) {
    box(side * 1.75, .025, 2.83, .031, .018, 12.78, paleBrass);
    box(side * 1.63, .025, 2.83, .018, .017, 12.90, warmBrass);
    box(side * 3.78, .024, -7.76, .038, .017, 9.69, paleBrass);
    box(side * 3.64, .024, -7.76, .024, .017, 9.56, warmBrass);
  }
  box(0, .026, 9.21, 3.25, .016, .022, warmBrass);
  box(0, .026, -3.47, 3.24, .016, .021, warmBrass);
  box(0, .024, -12.57, 7.49, .018, .026, warmBrass);
  reflectingPool(-5.98, -9.1, 3.7, 14.3, 0x6fafa1, .33);
  reflectingPool(5.94, -7.0, 3.7, 13.0, 0x79bbad, .36);
  reflectingPool(-2.83, 3.5, 2.2, 10.2, 0xd6aa74, .37);
  reflectingPool(2.97, 2.0, 2.1, 9.6, 0xd6aa74, .38);

  // A high coffer over the central aisle and a continuous brass reveal around it.
  box(0, 5.94, -2.03, 14.6, .31, 27.0, navy);
  for (const side of [-1, 1]) {
    box(side * 5.65, 5.48, -2.03, 3.20, .64, 27.05, navy);
    box(side * 4.02, 5.31, -2.8, .16, .14, 23.9, warmBrass);
    box(side * 3.91, 5.61, -2.9, .096, .090, 23.7, brassGlow);
    box(side * 3.96, 5.19, -2.8, .11, .068, 23.9, deepJade);
    box(side * 1.87, 5.74, -2.7, .057, .09, 24.3, warmBrass);
  }
  for (const z of [-12.9, -9.15, -5.38, -1.61, 2.15, 5.91, 9.68]) {
    box(0, 5.73, z, 7.98, .18, .18, deepJade);
    box(0, 5.61, z, 7.93, .044, .072, warmBrass);
  }

  const windowsA = new THREE.MeshBasicMaterial({
    map: skylineTexture(7259), color: 0xadcbc7, fog: false
  });
  const windowsB = new THREE.MeshBasicMaterial({
    map: skylineTexture(1971), color: 0x9ab6ae, fog: false
  });

  function sideBay(side, z, window) {
    const outside = side * 7.39;
    const facing = -side * quarterTurn;
    const trimX = side * 7.05;
    if (window) {
      panel(outside, 3.34, z, 3.36, 3.68, side < 0 ? windowsA : windowsB, facing);
      box(trimX, 1.49, z, .43, .16, 3.42, greenStone);
      box(trimX, 5.16, z, .36, .13, 3.43, warmBrass);
      box(trimX, 3.61, z, .22, .07, 3.38, iron);
      for (const off of [-.54, .54]) box(trimX, 3.32, z + off, .22, 3.6, .066, iron);
    } else {
      box(outside, 3.35, z, .52, 3.78, 3.44, deepJade);
      box(side * 7.12, 3.28, z, .034, 2.86, 2.69, greenStone);
      for (const off of [-1.13, 1.13]) {
        box(side * 7.10, 3.28, z + off, .026, 2.51, .028, warmBrass);
      }
      for (const y of [2.06, 4.50]) box(side * 7.10, y, z, .026, .030, 2.29, warmBrass);
    }
    box(side * 7.13, .66, z, .58, 1.31, 3.59, darkWood);
    box(side * 6.82, .72, z, .057, .94, 2.92, deepJade);
    box(side * 6.79, .79, z, .036, .031, 2.80, warmBrass);
    box(side * 6.95, .20, z, .38, .16, 3.57, iron);
  }

  const bays = [-13.0, -9.55, -6.10, -2.65, .80, 4.25, 7.70, 10.37];
  for (const side of [-1, 1]) {
    for (const [i, z] of bays.entries()) {
      sideBay(side, z, i < 4 && i !== 1);
      if (i < bays.length - 1) {
        const pillarZ = z + 1.72;
        box(side * 7.12, 2.82, pillarZ, .72, 5.66, .31, darkWood);
        box(side * 6.75, 2.80, pillarZ, .06, 4.30, .107, warmBrass);
        box(side * 6.72, .54, pillarZ, .18, .81, .34, navy);
        box(side * 6.76, 4.83, pillarZ, .18, .30, .34, deepJade);
      }
    }
  }

  // The face of the chamber is framed by two banks of rain-streaked windows.
  for (const side of [-1, 1]) {
    const x = side * 4.42;
    panel(x, 3.47, -15.40, 4.70, 3.88, side < 0 ? windowsB : windowsA);
    box(x, .70, -15.16, 4.67, 1.40, .49, darkWood);
    box(x, 1.45, -15.01, 4.71, .17, .54, greenStone);
    box(x, 5.35, -15.06, 4.71, .14, .49, warmBrass);
    box(x, 3.70, -15.03, 4.66, .087, .31, iron);
    for (const offset of [-1.28, 0, 1.28]) box(x + offset, 3.42, -15.03, .079, 3.79, .27, iron);
    box(side * 2.03, 2.86, -14.96, .30, 5.73, .53, darkWood);
    box(side * 1.88, 2.87, -14.67, .074, 4.98, .061, warmBrass);
    box(side * 6.85, 2.87, -14.96, .34, 5.73, .59, darkWood);
  }
  box(0, 2.89, -15.13, 3.98, 5.79, .53, navy);
  box(0, 3.43, -14.85, 3.38, 3.47, .11, greenStone);
  box(0, 1.36, -14.79, 3.42, .067, .21, paleBrass);
  box(0, 5.32, -14.80, 3.42, .067, .14, warmBrass);
  for (const x of [-1.7, 1.7]) box(x, 3.42, -14.79, .048, 3.42, .12, warmBrass);

  const crest = new THREE.Mesh(new THREE.TorusGeometry(1.127, .031, 9, 66), brassGlow);
  crest.position.set(0, 3.67, -14.70);
  scene.add(crest);
  const disk = new THREE.Mesh(new THREE.CircleGeometry(1.099, 54), navy);
  disk.position.set(0, 3.67, -14.73);
  scene.add(disk);
  for (const [i, h] of [.76, 1.11, 1.42].entries()) {
    const x = (i - 1) * .335;
    box(x, 3.07 + h / 2, -14.68, .077, h, .047, brassGlow);
    box(x - .054, 3.07 + h, -14.67, .178, .044, .05, brassGlow);
  }
  ornamentGlow(0, 3.66, -14.58, 4.59, 0xe3b279, .10);
  const crestName = signTexture('THE QUIET LEDGER', '', {
    text: '#e5c795', aux: '#ceb98c', trim: '#89734c', panel: '#22332b'
  });
  panel(0, 1.93, -14.75, 2.76, .47, new THREE.MeshBasicMaterial({ map: crestName, toneMapped: false }));

  function sconce(side, z) {
    const x = side * 6.65;
    box(x, 2.97, z, .28, .86, .41, warmBrass);
    box(x - side * .115, 2.97, z, .075, .62, .22, iron);
    box(x - side * .165, 2.97, z, .09, .53, .14, warmGlow);
    for (const y of [2.69, 3.25]) box(x - side * .15, y, z, .15, .049, .24, paleBrass);
    ornamentGlow(x - side * .20, 2.97, z, 1.52, 0xf1c690, .21);
  }
  for (const side of [-1, 1]) for (const z of [-11.28, -4.38, 2.54, 9.38]) sconce(side, z);

  function pendant(z) {
    for (const side of [-1, 1]) {
      box(side * 1.08, 5.04, z, .045, 1.30, .051, warmBrass);
      box(side * 1.28, 4.36, z, .047, .18, .65, warmBrass);
      box(side * 1.15, 4.29, z, .22, .085, .56, warmGlow);
    }
    for (const off of [-.315, .315]) {
      box(0, 4.39, z + off, 2.58, .13, .047, paleBrass);
      box(0, 4.30, z + off, 2.03, .069, .042, warmGlow);
    }
    box(0, 4.36, z, 2.58, .072, .06, warmBrass);
    ornamentGlow(0, 4.24, z, 3.68, 0xf3c58b, .13);
  }
  for (const z of [-1.35, -5.71, -9.97]) pendant(z);

  const tableZ = -7.95;
  function slab(width, length, y, depth, material, bevel = .031) {
    const shape = roundRectangle(width / 2, length / 2, .47);
    const geometry = new THREE.ExtrudeGeometry(shape, {
      depth, bevelEnabled: bevel > 0, bevelSegments: 2, bevelSize: bevel,
      bevelThickness: bevel, curveSegments: 6, steps: 1
    });
    const tabletop = new THREE.Mesh(geometry, material);
    tabletop.rotation.x = -quarterTurn;
    tabletop.position.set(0, y, tableZ);
    scene.add(tabletop);
  }
  slab(4.04, 8.08, .86, .08, navy);
  slab(4.13, 8.15, .932, .027, paleBrass, .016);
  slab(4.04, 8.06, .978, .042, tableWood);
  slab(2.93, 6.95, 1.056, .003, blackGlass, 0);
  obstacle(0, tableZ, 4.13, 8.15);
  for (const z of [-6.14, -9.87]) {
    box(0, .44, z, 2.59, .82, .50, darkWood);
    box(0, .17, z, 2.73, .14, .68, iron);
    box(0, .23, z, 2.61, .044, .59, warmBrass);
  }
  const tableStreak = new THREE.MeshBasicMaterial({
    map: shadow, color: 0xd7a366, opacity: .16, transparent: true,
    blending: THREE.AdditiveBlending, depthWrite: false
  });
  panel(.47, 1.061, -7.67, 2.75, 6.3, tableStreak, 0, -quarterTurn);

  const shades = [palette(0x292c2a), palette(0x383138), palette(0x24322c)];
  const faces = [palette(0x98745b), palette(0x785743), palette(0xad8462)];
  const hair = palette(0x2a2929);

  function chair(x, z, rotation, seated, index) {
    function part(dx, y, dz, w, h, d, material, roll = 0) {
      const sine = Math.sin(rotation);
      const cosine = Math.cos(rotation);
      box(x + dx * cosine + dz * sine, y, z - dx * sine + dz * cosine,
        w, h, d, material, rotation, roll);
    }
    part(0, .13, 0, .68, .075, .65, iron);
    part(0, .31, 0, .117, .40, .12, warmBrass);
    part(0, .55, 0, .68, .14, .64, iron);
    part(0, .643, .03, .60, .10, .57, leather);
    part(0, 1.011, -.28, .61, .75, .15, darkWood);
    part(0, 1.011, -.19, .54, .67, .07, leather);
    part(0, 1.36, -.26, .62, .035, .14, warmBrass);
    for (const side of [-1, 1]) {
      part(side * .31, .795, .03, .057, .36, .066, iron);
      part(side * .31, .918, .03, .069, .064, .45, darkWood);
    }
    if (seated) {
      const suit = shades[index];
      part(0, .889, .123, .408, .48, .30, suit);
      part(0, 1.12, .31, .119, .153, .033, paper);
      part(0, 1.245, .13, .104, .14, .10, faces[index]);
      part(0, 1.401, .132, .218, .231, .204, faces[index]);
      part(0, 1.424, .03, .225, .211, .068, hair);
      part(0, 1.521, .135, .229, .079, .227, hair);
      for (const side of [-1, 1]) {
        part(side * .203, .985, .21, .105, .313, .118, suit, side * .13);
        part(side * .218, .946, .347, .089, .12, .222, suit);
        part(side * .218, .962, .468, .087, .070, .082, faces[index]);
      }
    }
    obstacle(x, z, .88, .79);
  }

  const chairs = [-4.98, -6.49, -8.0, -9.52, -11.02];
  for (const side of [-1, 1]) {
    for (const [i, z] of chairs.entries()) {
      const member = (i === 2 && side === -1) || (i === 3 && side === 1);
      chair(side * 2.57, z, -side * quarterTurn, member, side < 0 ? 0 : 1);
      box(side * 1.25, 1.068, z, .485, .027, .365, i % 2 ? leather : oxblood, side * .10);
      if (i % 2 === 0) {
        box(side * 1.22, 1.088, z - .017, .369, .013, .291, paper, side * .107);
        box(side * .97, 1.102, z + .046, .082, .014, .201, warmBrass, side * .26);
      }
      box(side * 1.36, 1.106, z + .327, .091, .11, .092, reflectiveGlass);
    }
  }
  chair(0, -12.73, 0, true, 2);
  for (const z of [-5.68, -10.59]) {
    box(0, 1.07, z, .45, .04, .38, warmBrass);
    box(0, 1.26, z, .045, .36, .055, paleBrass);
    box(0, 1.433, z, .59, .116, .221, warmBrass);
    box(0, 1.363, z, .49, .051, .171, warmGlow);
    ornamentGlow(0, 1.397, z + .06, .91, 0xeec286, .155);
  }

  function shelf(x, z) {
    const width = 2.43;
    box(x, .599, z, .67, 1.21, width, darkWood);
    box(x, 1.23, z, .78, .104, width + .11, greenStone);
    for (const off of [-.92, -.32, .34, .93]) {
      box(x, .60, z + off, .72, .67, .52, navy);
      box(x - Math.sign(x) * .374, .62, z + off, .027, .036, .183, paleBrass);
    }
    obstacle(x, z, .77, width + .11);
  }
  shelf(-6.56, 1.33);
  shelf(6.56, 3.10);

  // The return door remains reachable even if the player enters and turns around immediately.
  box(0, 2.83, 11.22, 14.52, 5.66, .49, navy);
  box(-4.70, 1.72, 10.93, 1.79, 3.29, .10, darkWood);
  box(-4.70, 3.43, 10.87, 2.09, .14, .26, paleBrass);
  for (const side of [-1, 1]) {
    box(-4.70 + side * .95, 1.714, 10.84, .108, 3.41, .32, warmBrass);
    box(-4.70 + side * .123, 1.43, 10.82, .051, .41, .064, paleBrass);
    box(-4.70 + side * .42, 2.41, 10.842, .61, 1.18, .037, greenStone);
  }
  const doorSign = signTexture('EXCHANGE', 'DISTRICT ACCESS', {
    text: '#c7d6bf', aux: '#a6b299', trim: '#8f9b80', panel: '#273a33'
  });
  panel(-4.70, 3.75, 10.89, 1.75, .38,
    new THREE.MeshBasicMaterial({ map: doorSign, toneMapped: false }), Math.PI);
  box(-4.70, 3.972, 10.77, .52, .043, .09, coolGlow);
  ornamentGlow(-4.70, 3.96, 10.68, 1.30, 0x74ae9f, .17);
  for (const x of [-2.75, .0, 2.75, 5.49]) {
    box(x, 2.54, 10.93, 2.21, 3.76, .09, deepJade);
    box(x, 4.49, 10.84, 2.26, .061, .125, warmBrass);
    box(x, .58, 10.88, 2.26, .16, .13, darkWood);
  }

  const convenor = createMissionContact(scene, { ...landmarks[0], y: .033, heading: .14 }, { reducedMotion });
  for (const landmark of landmarks) {
    const ring = new THREE.Mesh(new THREE.RingGeometry(.437, .455, 40),
      new THREE.MeshBasicMaterial({
        color: landmark.color, transparent: true, opacity: .72, toneMapped: false
      }));
    ring.position.set(landmark.x, .038, landmark.z);
    ring.rotation.x = -quarterTurn;
    scene.add(ring);
  }

  for (const [material, parts] of groups) {
    const batch = new THREE.InstancedMesh(unitBlock, material, parts.length);
    for (const [i, [x, y, z, w, h, d, yaw, roll]] of parts.entries()) {
      transform.position.set(x, y, z);
      transform.rotation.set(0, yaw, roll, 'YXZ');
      transform.scale.set(w, h, d);
      transform.updateMatrix();
      batch.setMatrixAt(i, transform.matrix);
    }
    batch.computeBoundingSphere();
    scene.add(batch);
  }

  let paused = Boolean(reducedMotion);
  return {
    landmarks: landmarks.map(landmark => ({ ...landmark })),

    collides(x, z, radius = .3) {
      if (Math.abs(x) + radius > 6.90 || z + radius > 10.77 || z - radius < -14.85) return true;
      if (Math.hypot(x - landmarks[0].x, z - landmarks[0].z) < radius + .27) return true;
      return obstacles.some(([left, far, right, near]) =>
        x + radius > left && x - radius < right && z + radius > far && z - radius < near);
    },

    update(elapsed) {
      if (paused) return;
      convenor.update(elapsed);
      warmFocus.intensity = 46 + 1.40 * Math.sin(elapsed * .78);
    },

    setReducedMotion(enabled) {
      paused = Boolean(enabled);
      convenor.setReducedMotion(enabled);
    }
  };
}
